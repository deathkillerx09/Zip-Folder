from __future__ import annotations

import asyncio
import json
import logging
import os
import threading
import time
from datetime import datetime, timezone

from .core import add_activity, timestamp
from .database import Database
from .empire import (
    STAGE_ASSIGNMENTS,
    _assign,
    advance_revival,
    create_revival_mission,
    reward_profitable_contributors,
    transition_business,
)
from .market_simulation import run_synthetic_customer_simulation
from .finance import _verified_totals, finance_summary
from .ollama import OllamaClient, OllamaError, select_chat_model
from .resources import resource_snapshot
from .empire import pause_unprofitable_business


logger = logging.getLogger(__name__)
ACTIVE_STAGES = {"research", "development", "simulation", "ready_for_approval", "live_business", "growing", "stable", "declining", "revival"}
SUCCESS_STAGES = {"live_business", "growing", "stable"}
QUEUE_LIMIT_PER_EMPLOYEE = 3


STARTER_EMPLOYEE_TASKS = {
    "town-manager": ("Prepare the town's first operations plan", "Review the current team, identify the first three internal priorities, and write a concise coordination plan. Do not claim work is already complete."),
    "researcher": ("Map customer problems worth solving", "List practical customer problems across software, education, household services, and creator tools. Separate known facts from hypotheses."),
    "strategist": ("Create a free-first business evaluation framework", "Define a simple way to compare ideas by customer problem, feasibility, competition, effort, and risks. Do not invent market evidence."),
    "builder": ("Audit the product prototype workflow", "Review the existing product-building capabilities and propose the smallest safe prototype workflow using free tools only."),
    "marketer": ("Draft an ethical launch checklist", "Create a checklist for clear product positioning, honest claims, accessible content, and owner-approved promotion. Do not send or publish anything."),
    "finance-analyst": ("Prepare a zero-spend unit economics template", "Create a simple cost, price, fees, refund, and break-even worksheet. All numbers must be labelled examples unless backed by records."),
    "operations": ("Design a repeatable quality review", "Create a checklist for product reliability, support load, privacy, security, and operational costs. Do not purchase services."),
    "community-manager": ("Draft a customer feedback framework", "Design respectful feedback questions and a way to group customer needs. Do not contact real people or invent responses."),
}


def seed_initial_team_tasks(database: Database) -> int:
    """Give every seeded employee one genuine starter assignment, once per database."""
    created = 0
    now = timestamp()
    with database.connect() as connection:
        for employee_id, (title, description) in STARTER_EMPLOYEE_TASKS.items():
            if connection.execute("SELECT 1 FROM employees WHERE id = ?", (employee_id,)).fetchone() is None:
                continue
            cursor = connection.execute(
                """INSERT OR IGNORE INTO tasks
                   (title, description, employee_id, status, created_at, updated_at,
                    task_kind, mission_type, dedupe_key)
                   VALUES (?, ?, ?, 'pending', ?, ?, 'autonomous', 'town_onboarding', ?)""",
                (title, description, employee_id, now, now, f"town-onboarding:{employee_id}:v1"),
            )
            created += max(0, cursor.rowcount)
        if created:
            add_activity(connection, f"Mayor assigned {created} first-shift starter task(s) across the town.")
    return created


def recover_unfinished_tasks(database: Database) -> int:
    now = timestamp()
    with database.connect() as connection:
        count = connection.execute(
            "SELECT COUNT(*) FROM tasks WHERE status = 'in_progress'"
        ).fetchone()[0]
        if count:
            connection.execute(
                """
                UPDATE tasks SET status = 'pending', updated_at = ?
                WHERE status = 'in_progress'
                """,
                (now,),
            )
            connection.execute("UPDATE employees SET status = 'available' WHERE status = 'working'")
            add_activity(connection, f"Recovered {count} unfinished task(s) after service restart.")
        return count


def _queued_count(connection, employee_id: str) -> int:
    return connection.execute(
        """
        SELECT COUNT(*) FROM tasks WHERE employee_id = ? AND status IN ('pending', 'in_progress')
        """,
        (employee_id,),
    ).fetchone()[0]


def _parse_idea_batch(content: str) -> list[dict]:
    """Extract a JSON array of idea records from a local model response."""
    start = content.find("[")
    end = content.rfind("]")
    if start < 0 or end <= start:
        return []
    try:
        payload = json.loads(content[start:end + 1])
    except json.JSONDecodeError:
        return []
    if not isinstance(payload, list):
        return []
    cleaned = []
    seen = set()
    for item in payload:
        if not isinstance(item, dict):
            continue
        title = " ".join(str(item.get("title", "")).split())[:160]
        description = " ".join(str(item.get("description", "")).split())[:3000]
        if not title or title.casefold() in seen:
            continue
        seen.add(title.casefold())
        category = " ".join(str(item.get("category", "General")).split())[:80]
        problem = " ".join(str(item.get("problem", "")).split())[:500]
        customer = " ".join(str(item.get("target_customers", "")).split())[:500]
        mvp = " ".join(str(item.get("mvp", "")).split())[:500]
        details = [description]
        if category:
            details.append(f"Category: {category}")
        if problem:
            details.append(f"Problem: {problem}")
        if customer:
            details.append(f"Potential customers: {customer}")
        if mvp:
            details.append(f"Smallest testable version: {mvp}")
        cleaned.append({"title": title, "description": "\n".join(details)[:3000]})
        batch_limit = max(1, min(20, int(os.getenv("AI_MONEY_TOWN_IDEA_BATCH_SIZE", "10"))))
        if len(cleaned) >= batch_limit:
            break
    return cleaned


def maybe_generate_ideas(
    database: Database,
    ollama: OllamaClient,
    model_lock: threading.BoundedSemaphore,
    interactive_chat_waiting: threading.Event | None = None,
    now: datetime | None = None,
) -> dict | None:
    """Generate compact idea batches on a cadence targeting 50 candidates per hour."""
    if interactive_chat_waiting is not None and interactive_chat_waiting.is_set():
        return None
    now = now or datetime.now(timezone.utc)
    now_iso = now.isoformat()
    target_per_hour = max(1, int(os.getenv("AI_MONEY_TOWN_IDEA_TARGET_PER_HOUR", "50")))
    batch_size = max(1, min(20, int(os.getenv("AI_MONEY_TOWN_IDEA_BATCH_SIZE", "10"))))
    default_interval = max(300, round(3600 * batch_size / target_per_hour))
    interval = max(300, int(os.getenv("AI_MONEY_TOWN_IDEA_INTERVAL_SECONDS", str(default_interval))))
    with database.connect() as connection:
        previous = connection.execute(
            "SELECT created_at FROM management_reports WHERE report_type = 'idea_generation' ORDER BY id DESC LIMIT 1"
        ).fetchone()
        if previous:
            try:
                previous_time = datetime.fromisoformat(previous["created_at"])
                if previous_time.tzinfo is None:
                    previous_time = previous_time.replace(tzinfo=timezone.utc)
                if (now - previous_time).total_seconds() < interval:
                    return None
            except (TypeError, ValueError):
                logger.warning("Could not parse the last idea-generation timestamp; retrying the hourly job.")
    if not model_lock.acquire(blocking=False):
        return None
    try:
        if interactive_chat_waiting is not None and interactive_chat_waiting.is_set():
            return None
        status = ollama.status()
        if not status.get("connected") or not status.get("models"):
            return None
        model = select_chat_model(
            status["models"], os.getenv("OLLAMA_IDEA_MODEL") or os.getenv("OLLAMA_WORKER_MODEL")
        )
        if not model:
            return None
        with database.connect() as connection:
            existing_titles = [row[0].casefold() for row in connection.execute("SELECT title FROM business_ideas")]
        prompt = (
            f"Generate exactly {batch_size} genuinely different, practical, original small-business ideas. "
            "Mix categories: simple software, digital products, useful services, education, creator tools, "
            "local problem-solving, and simple physical-product concepts. Avoid copying named companies, "
            "creators, copyrighted works, or patented product designs. Prefer ideas that can begin with "
            "free tools and $0 owner investment. Do not promise income. Avoid repeating these existing titles: "
            + json.dumps(existing_titles[-80:])
            + ". Return ONLY a valid JSON array, no markdown. Each item must contain title, description, "
            "category, problem, target_customers, and mvp. Keep each field under 10 words so the full "
            "batch is short and quick to generate."
        )
        original_timeout = getattr(ollama, "timeout", None)
        if original_timeout is not None:
            ollama.timeout = min(float(original_timeout), 60.0)
        try:
            content = ollama.chat(
                model,
                [
                    {"role": "system", "content": "You are a careful startup ideation researcher. Output valid compact JSON only."},
                    {"role": "user", "content": prompt},
                ],
                options={"num_predict": 440, "num_ctx": 1024, "temperature": 0.62},
            )
        except OllamaError as error:
            logger.warning("Hourly idea generation paused: %s", error)
            return None
        finally:
            if original_timeout is not None:
                ollama.timeout = original_timeout
        ideas = _parse_idea_batch(content)
        if not ideas:
            logger.warning("Local model did not return a valid JSON idea batch; will retry next scheduler cycle.")
            return None
        employee_order = ["researcher", "strategist", "builder", "marketer", "community-manager", "operations", "finance-analyst"]
        created_ids = []
        with database.connect() as connection:
            current_titles = {row[0].casefold() for row in connection.execute("SELECT title FROM business_ideas")}
            for idea in ideas:
                if idea["title"].casefold() in current_titles:
                    continue
                created_at = timestamp()
                cursor = connection.execute(
                    "INSERT INTO business_ideas (title, description, status, created_at) VALUES (?, ?, 'evaluating', ?)",
                    (idea["title"], idea["description"], created_at),
                )
                idea_id = cursor.lastrowid
                created_ids.append(idea_id)
                current_titles.add(idea["title"].casefold())
                candidates = sorted(employee_order, key=lambda employee_id: _queued_count(connection, employee_id))
                employee_id = next((candidate for candidate in candidates if _queued_count(connection, candidate) < QUEUE_LIMIT_PER_EMPLOYEE), None)
                if employee_id:
                    dedupe_key = f"idea:{idea_id}:research"
                    connection.execute(
                        """INSERT OR IGNORE INTO tasks
                           (title, description, employee_id, status, created_at, updated_at,
                            task_kind, mission_type, dedupe_key, idea_id)
                           VALUES (?, ?, ?, 'pending', ?, ?, 'autonomous', 'idea_research', ?, ?)""",
                        (
                            f"Research idea: {idea['title']}",
                            "Evaluate the problem, target audience, competition risks, free-first MVP, "
                            "and assumptions. Do not claim demand is verified or spend money.",
                            employee_id, created_at, created_at, dedupe_key, idea_id,
                        ),
                    )
            report = {
                "created_at": now_iso,
                "model": model,
                "ideas_created": len(created_ids),
                "idea_ids": created_ids,
                "batch_target": batch_size,
                "target_ideas_per_hour": target_per_hour,
                "batch_interval_seconds": interval,
                "hourly_target_is_aspirational": True,
                "target_reached": len(created_ids) >= batch_size,
                "actual_results_only": True,
            }
            connection.execute(
                "INSERT INTO management_reports (report_type, content, created_at) VALUES (?, ?, ?)",
                ("idea_generation", json.dumps(report, separators=(",", ":")), now_iso),
            )
            add_activity(connection, f"Innovation department generated {len(created_ids)} new idea candidate(s) for review.")
        return report
    finally:
        model_lock.release()


def _enqueue_portfolio_improvement(connection, business_id: int, business_title: str, metrics) -> bool:
    if connection.execute(
        """
        SELECT 1 FROM tasks WHERE business_id = ? AND status IN ('pending', 'in_progress')
        LIMIT 1
        """,
        (business_id,),
    ).fetchone():
        return False
    assignments = [
        ("operations", "customer retention", "Improve customer retention using no-cost service changes."),
        ("community-manager", "customer experience", "Review customer feedback and propose a no-cost experience improvement."),
        ("researcher", "new customer segments", "Research a new customer segment using available internal information."),
        ("finance-analyst", "operational costs", "Identify non-spending opportunities to reduce operating costs."),
    ]
    if metrics and metrics["retention_pct"] < 65:
        preferred = assignments[0]
    elif metrics and metrics["satisfaction_pct"] < 75:
        preferred = assignments[1]
    elif metrics and metrics["growth_pct"] > 0:
        preferred = assignments[2]
    else:
        preferred = assignments[3]
    candidates = sorted(assignments, key=lambda item: _queued_count(connection, item[0]))
    preferred = min(candidates, key=lambda item: _queued_count(connection, item[0])) if (
        _queued_count(connection, preferred[0]) >= QUEUE_LIMIT_PER_EMPLOYEE
    ) else preferred
    employee_id, mission_type, description = preferred
    if _queued_count(connection, employee_id) >= QUEUE_LIMIT_PER_EMPLOYEE:
        return False
    now = timestamp()
    dedupe_key = f"portfolio:{business_id}:{datetime.now(timezone.utc).date().isoformat()}"
    connection.execute(
        """
        INSERT OR IGNORE INTO tasks
            (title, description, employee_id, status, created_at, updated_at,
             business_id, task_kind, mission_type, dedupe_key)
        VALUES (?, ?, ?, 'pending', ?, ?, ?, 'autonomous', ?, ?)
        """,
        (
            f"{mission_type.title()}: {business_title}",
            description + " Do not spend money or claim simulated revenue is real.",
            employee_id,
            now,
            now,
            business_id,
            mission_type,
            dedupe_key,
        ),
    )
    task = connection.execute("SELECT id FROM tasks WHERE dedupe_key = ?", (dedupe_key,)).fetchone()
    if task:
        connection.execute(
            """
            INSERT INTO business_assignments
                (business_id, employee_id, assignment_role, current_project, assigned_at)
            SELECT ?, ?, ?, ?, ?
            WHERE NOT EXISTS (
                SELECT 1 FROM business_assignments
                WHERE business_id = ? AND employee_id = ? AND assignment_role = ? AND released_at IS NULL
            )
            """,
            (business_id, employee_id, mission_type, business_title, now, business_id, employee_id, mission_type),
        )
        return True
    return False


def run_management_cycle(database: Database) -> dict:
    resources = resource_snapshot()
    with database.connect() as connection:
        businesses = connection.execute(
            """
            SELECT b.*, i.title FROM businesses b
            JOIN business_ideas i ON i.id = b.idea_id ORDER BY b.id
            """
        ).fetchall()
        declines = []
        assignments_made = 0
        for business in businesses:
            if business["stage"] not in ACTIVE_STAGES:
                continue
            actual = _verified_totals(connection, business["id"])
            actual_costs = (
                actual["refunds_cents"]
                + actual["processing_fees_cents"]
                + actual["expenses_cents"]
                + actual["reinvestment_cents"]
            )
            if (
                business["stage"] in SUCCESS_STAGES
                and actual_costs > actual["actual_revenue_cents"]
                and actual_costs > 0
            ):
                verified_profit = actual["actual_revenue_cents"] - actual_costs
                pause_unprofitable_business(connection, business["id"], verified_profit)
                declines.append({
                    "business_id": business["id"],
                    "reason": f"Verified ledger profit is negative ({verified_profit} cents); costly work paused.",
                })
                continue
            metrics = connection.execute(
                "SELECT * FROM business_metrics WHERE business_id = ? ORDER BY id DESC LIMIT 1",
                (business["id"],),
            ).fetchone()
            if business["stage"] in SUCCESS_STAGES and metrics is not None:
                reason = None
                if metrics["growth_pct"] <= -10:
                    reason = f"Estimated growth is {metrics['growth_pct']:.1f}%."
                elif metrics["retention_pct"] < 35:
                    reason = f"Estimated customer retention is {metrics['retention_pct']:.1f}%."
                elif metrics["satisfaction_pct"] < 40:
                    reason = f"Estimated customer satisfaction is {metrics['satisfaction_pct']:.1f}%."
                if reason:
                    transition_business(connection, business["id"], "declining", reason)
                    declines.append({"business_id": business["id"], "reason": reason})
                    continue
                if _enqueue_portfolio_improvement(connection, business["id"], business["title"], metrics):
                    assignments_made += 1
            elif business["stage"] == "declining":
                mission = create_revival_mission(connection, business["id"], "Portfolio review detected declining performance.")
                if mission["phase"] == "investigating":
                    assignments_made += int(
                        connection.execute(
                            "SELECT 1 FROM tasks WHERE dedupe_key = ?",
                            (f"business:{business['id']}:stage:declining",),
                        ).fetchone()
                        is not None
                    )
            if (
                business["stage"] not in SUCCESS_STAGES
                and business["stage"] in STAGE_ASSIGNMENTS
                and business["stage"] not in {"declining", "revival"}
            ):
                assignments_made += int(_assign(connection, business["id"], business["stage"]) is not None)
            connection.execute(
                "UPDATE businesses SET last_reviewed_at = ? WHERE id = ?",
                (timestamp(), business["id"]),
            )

        task_counts = {
            row["status"]: row["count"]
            for row in connection.execute("SELECT status, COUNT(*) AS count FROM tasks GROUP BY status")
        }
        finance = finance_summary(connection)
        current_stages = {
            row["stage"]: row["count"]
            for row in connection.execute("SELECT stage, COUNT(*) AS count FROM businesses GROUP BY stage")
        }
        report = {
            "created_at": timestamp(),
            "business_count": len(businesses),
            "business_stages": {
                stage: current_stages.get(stage, 0)
                for stage in (
                    "research", "development", "simulation", "ready_for_approval",
                    "live_business", "growing", "stable", "declining", "revival",
                    "temporarily_dormant", "archived",
                )
            },
            "declines_detected": declines,
            "tasks": task_counts,
            "assignments_made": assignments_made,
            "actual_revenue_cents": finance["actual_revenue_cents"],
            "estimated_revenue_is_separate": True,
            "available_business_funds_cents": finance["available_business_funds_cents"],
            "spending_paused_by_default": finance["daily_spending_limit_cents"] == 0,
            "resources": resources,
            "model_calls_in_cycle": 0,
        }
        connection.execute(
            "INSERT INTO management_reports (report_type, content, created_at) VALUES (?, ?, ?)",
            ("portfolio_review", json.dumps(report, separators=(",", ":")), report["created_at"]),
        )
        connection.execute(
            "DELETE FROM management_reports WHERE id NOT IN "
            "(SELECT id FROM management_reports ORDER BY id DESC LIMIT 500)"
        )
        add_activity(connection, "Mayor portfolio review completed; queued internal work only.")
        return report


def process_next_autonomous_task(
    database: Database,
    ollama: OllamaClient,
    model_lock: threading.BoundedSemaphore,
    interactive_chat_waiting: threading.Event | None = None,
) -> dict | None:
    if interactive_chat_waiting is not None and interactive_chat_waiting.is_set():
        return None
    if not model_lock.acquire(blocking=False):
        return None
    try:
        resources = resource_snapshot()
        if resources["memory_percent_used"] >= 95:
            logger.warning("Autonomous Ollama work paused because available system memory is critically low.")
            return None
        status = ollama.status()
        if not status["connected"] or not status["models"]:
            return None
        model = select_chat_model(status["models"], os.getenv("OLLAMA_WORKER_MODEL"))
        if not model:
            logger.warning("No suitable local chat model is available; autonomous work remains queued.")
            return None

        with database.connect() as connection:
            task = connection.execute(
                """
                SELECT t.*, e.name AS employee_name, e.role AS employee_role,
                    e.specialty, b.stage AS business_stage, i.title AS business_title,
                    i.description AS business_description, b.idea_id AS business_idea_id,
                    task_idea.title AS idea_title, task_idea.description AS idea_description,
                    m.retention_pct, m.satisfaction_pct, m.growth_pct,
                    m.estimated_revenue_cents, m.customer_feedback, m.competitor_analysis,
                    r.id AS revival_mission_id, r.phase AS revival_phase,
                    r.attempt_number AS revival_attempt, r.new_market_information
                FROM tasks t
                JOIN employees e ON e.id = t.employee_id
                LEFT JOIN businesses b ON b.id = t.business_id
                LEFT JOIN business_ideas i ON i.id = b.idea_id
                LEFT JOIN business_ideas task_idea ON task_idea.id = t.idea_id
                LEFT JOIN business_metrics m ON m.id = (
                    SELECT MAX(id) FROM business_metrics WHERE business_id = t.business_id
                )
                LEFT JOIN revival_missions r ON r.id = (
                    SELECT MAX(id) FROM revival_missions WHERE business_id = t.business_id
                )
                WHERE t.task_kind = 'autonomous' AND t.status = 'pending'
                ORDER BY t.id LIMIT 1
                """
            ).fetchone()
            if task is None:
                return None
            mission_id = task["revival_mission_id"]
            mission_attempt = task["revival_attempt"]
            if task["dedupe_key"] and task["dedupe_key"].startswith("revival:"):
                try:
                    parts = task["dedupe_key"].split(":", 3)
                    mission_id = int(parts[1])
                    mission_attempt = int(parts[2])
                except (IndexError, ValueError):
                    logger.error("Autonomous task %s has an invalid revival deduplication key.", task["id"])
            cursor = connection.execute(
                """
                UPDATE tasks SET status = 'in_progress', updated_at = ?
                WHERE id = ? AND status = 'pending'
                """,
                (timestamp(), task["id"]),
            )
            if cursor.rowcount != 1:
                return None
            connection.execute(
                "UPDATE employees SET status = 'working' WHERE id = ?", (task["employee_id"],)
            )
        business_context = "No business is attached to this task."
        if task["idea_id"] is not None:
            business_context = (
                f"Idea under review: {task['idea_title']}\n"
                f"Idea description: {task['idea_description']}"
            )
        if task["business_id"] is not None:
            summary = {
                "stage": task["business_stage"],
                "estimated_revenue_cents": task["estimated_revenue_cents"],
                "retention_pct": task["retention_pct"],
                "satisfaction_pct": task["satisfaction_pct"],
                "growth_pct": task["growth_pct"],
                "customer_feedback": task["customer_feedback"],
                "competitor_analysis": task["competitor_analysis"],
                "revival_phase": task["revival_phase"],
                "new_market_information": task["new_market_information"],
            }
            business_context = (
                f"Business: {task['business_title']}\n"
                f"Original idea: {task['business_description']}\n"
                f"Current business context (estimates are simulated): {json.dumps(summary)}"
            )
        stage_instructions = {
            "research": (
                "Produce a practical research brief: specific problem, target user, existing alternatives, "
                "why someone might pay, the strongest risks, and what evidence is still missing. "
                "You are offline: do not claim to have checked live competitors or interviewed customers."
            ),
            "development": (
                "Produce a build-ready MVP blueprint, not a vague idea: product name, one-sentence value, "
                "target user, 3-5 core features, user flow, page/screen list, data needed, acceptance tests, "
                "free-first technical approach, and a 7-step build plan. Do not claim code has been built."
            ),
            "simulation": (
                "Produce a simulation plan: price hypotheses, customer segments, reasons to buy/not buy, "
                "conversion assumptions, retention risks, and the smallest ethical real-world validation "
                "experiment. Clearly say these are hypotheses, not actual customers or sales."
            ),
            "ready_for_approval": (
                "Produce an owner launch-readiness checklist: product quality, accessibility, privacy, "
                "legal/age/platform requirements, support, truthful marketing, payment setup, refunds, "
                "and free/paid operating costs. Do not launch or contact anybody."
            ),
        }.get(task["mission_type"], "Produce a concise, useful internal work result with findings and next steps.")
        prompt = (
            f"Task: {task['title']}\nInstructions: {task['description']}\n"
            f"{business_context}\n\n{stage_instructions}\n\n"
            "Be specific, useful, and concise. Clearly label estimates and uncertainty. Never claim market "
            "facts without evidence. Do not send messages externally, publish marketing, buy anything, "
            "transfer funds, launch experiments, or claim simulated results are actual revenue. Any "
            "real-world experiment or public launch requires owner approval."
        )
        original_timeout = getattr(ollama, "timeout", None)
        if original_timeout is not None:
            ollama.timeout = min(float(original_timeout), 50.0)
        try:
            result = ollama.chat(
                model,
                [
                    {
                        "role": "system",
                        "content": (
                            f"You are {task['employee_name']}, {task['employee_role']} in a local business "
                            f"simulation. Specialty: {task['specialty']}. Work only on the task provided. "
                            "Be concise and return a useful first draft."
                        ),
                    },
                    {"role": "user", "content": prompt},
                ],
                options={
                    "num_predict": 190 if task["mission_type"] == "development" else 140,
                    "num_ctx": 1536,
                    "temperature": 0.48,
                },
            )
        except OllamaError as error:
            with database.connect() as connection:
                connection.execute(
                    """
                    UPDATE tasks SET status = 'pending', updated_at = ?
                    WHERE id = ? AND status = 'in_progress'
                    """,
                    (timestamp(), task["id"]),
                )
                connection.execute(
                    "UPDATE employees SET status = 'available' WHERE id = ?", (task["employee_id"],)
                )
                add_activity(connection, f"Local model unavailable; task remains queued: {task['title']}")
            logger.warning("Autonomous task %s remains queued: %s", task["id"], error)
            return None

        now = timestamp()
        with database.connect() as connection:
            connection.execute(
                """
                UPDATE tasks SET status = 'completed', result = ?, completed_at = ?, updated_at = ?
                WHERE id = ? AND status = 'in_progress'
                """,
                (result, now, now, task["id"]),
            )
            connection.execute(
                "UPDATE employees SET status = 'available' WHERE id = ?", (task["employee_id"],)
            )
            add_activity(connection, f"{task['employee_name']} completed internal work: {task['title']}")
            if task["business_id"] is not None:
                connection.execute(
                    """
                    INSERT INTO business_events
                        (business_id, event_type, details, created_at)
                    VALUES (?, 'internal_analysis_completed', ?, ?)
                    """,
                    (task["business_id"], f"{task['employee_name']}: {result[:500]}", now),
                )
                if task["mission_type"] in {"investigating", "solution_planning", "development", "simulation"}:
                    next_phase = {
                        "investigating": "solution_planning",
                        "solution_planning": "development",
                        "development": "simulation",
                        "simulation": "experiment_recommended",
                    }[task["mission_type"]]
                    mission = connection.execute(
                        "SELECT phase, attempt_number FROM revival_missions WHERE id = ?",
                        (mission_id,),
                    ).fetchone() if mission_id is not None else None
                    if (
                        mission is not None
                        and mission["phase"] == task["mission_type"]
                        and mission["attempt_number"] == mission_attempt
                    ):
                        advance_revival(connection, mission_id, next_phase, result[:1000])
                reward_profitable_contributors(connection, task["business_id"])
            if task["idea_id"] is not None and task["mission_type"] == "idea_research":
                idea_id = task["idea_id"]
                idea_title = task["idea_title"] or f"Idea #{idea_id}"
                candidates = ["strategist", "town-manager", "operations", "finance-analyst"]
                next_employee = min(candidates, key=lambda employee_id: _queued_count(connection, employee_id))
                if _queued_count(connection, next_employee) < QUEUE_LIMIT_PER_EMPLOYEE:
                    next_key = f"idea:{idea_id}:strategy"
                    connection.execute(
                        """INSERT OR IGNORE INTO tasks
                           (title, description, employee_id, status, created_at, updated_at,
                            task_kind, mission_type, dedupe_key, idea_id)
                           VALUES (?, ?, ?, 'pending', ?, ?, 'autonomous', 'idea_strategy', ?, ?)""",
                        (
                            f"Challenge and prioritise: {idea_title}",
                            "Review the research findings. Identify the strongest risk, smallest safe test, "
                            "and whether this idea deserves an owner-approved prototype. Never invent market validation.",
                            next_employee, now, now, next_key, idea_id,
                        ),
                    )
                    add_activity(connection, f"{task['employee_name']} passed idea research to {next_employee} for strategy review.")
            elif task["idea_id"] is not None and task["mission_type"] == "idea_strategy":
                # Continue internal research and prototyping automatically. This is not permission
                # to publish, contact customers, spend money, or claim revenue.
                idea_id = task["idea_id"]
                business = connection.execute(
                    "SELECT * FROM businesses WHERE idea_id = ?", (idea_id,)
                ).fetchone()
                if business is None:
                    cursor = connection.execute(
                        "INSERT INTO businesses (idea_id, stage, created_at, updated_at) VALUES (?, 'research', ?, ?)",
                        (idea_id, now, now),
                    )
                    business_id = cursor.lastrowid
                    connection.execute(
                        """INSERT INTO business_events
                           (business_id, event_type, from_stage, to_stage, details, created_at)
                           VALUES (?, 'internal_incubation_started', NULL, 'research', ?, ?)""",
                        (business_id, "Automated internal research and prototype preparation started. Real-world launch still requires owner approval." , now),
                    )
                else:
                    business_id = business["id"]
                connection.execute(
                    "INSERT INTO business_artifacts (business_id, artifact_type, title, content, created_at) VALUES (?, 'strategy_brief', ?, ?, ?)",
                    (business_id, f"Strategy review: {task['idea_title'] or 'Business idea'}", result, now),
                )
                connection.execute(
                    "UPDATE business_ideas SET status = 'evaluating' WHERE id = ? AND status != 'approved'",
                    (idea_id,),
                )
                _assign(connection, business_id, "research")
                connection.execute(
                    "INSERT INTO management_reports (report_type, content, created_at) VALUES (?, ?, ?)",
                    ("idea_review", json.dumps({
                        "idea_id": idea_id, "business_id": business_id,
                        "title": task["idea_title"], "review": result,
                        "next_step": "internal_research_and_mvp_preparation",
                        "external_launch_requires_owner_approval": True,
                    }, separators=(",", ":")), now),
                )
                add_activity(connection, f"Strategy review completed for {task['idea_title']}; internal research and MVP preparation started.")

            # Complete the internal venture pipeline without exposing anything publicly.
            if (
                task["business_id"] is not None
                and task["mission_type"] in {"research", "development", "simulation", "ready_for_approval"}
                and task["business_stage"] == task["mission_type"]
            ):
                business_id = task["business_id"]
                idea_title = task["business_title"] or f"Business #{business_id}"
                artifact_type = {
                    "research": "research_brief",
                    "development": "mvp_blueprint",
                    "simulation": "simulation_analysis",
                    "ready_for_approval": "launch_checklist",
                }[task["mission_type"]]
                artifact_title = {
                    "research": f"Research brief: {idea_title}",
                    "development": f"MVP blueprint: {idea_title}",
                    "simulation": f"Simulation assumptions: {idea_title}",
                    "ready_for_approval": f"Owner launch checklist: {idea_title}",
                }[task["mission_type"]]
                connection.execute(
                    "INSERT INTO business_artifacts (business_id, artifact_type, title, content, created_at) VALUES (?, ?, ?, ?, ?)",
                    (business_id, artifact_type, artifact_title, result, now),
                )
                if task["mission_type"] == "simulation":
                    idea_row = connection.execute(
                        "SELECT i.title, i.description FROM businesses b JOIN business_ideas i ON i.id = b.idea_id WHERE b.id = ?",
                        (business_id,),
                    ).fetchone()
                    simulation = run_synthetic_customer_simulation(
                        idea_row["title"], idea_row["description"],
                    )
                    connection.execute(
                        """INSERT INTO business_metrics
                           (business_id, estimated_revenue_cents, retention_pct, satisfaction_pct, growth_pct,
                            customer_feedback, competitor_analysis, source, created_at)
                           VALUES (?, ?, ?, ?, ?, ?, ?, 'simulation', ?)""",
                        (
                            business_id, simulation["estimated_revenue_cents"],
                            simulation["retention_pct"], simulation["satisfaction_pct"],
                            simulation["growth_pct"], simulation["customer_feedback"],
                            simulation["competitor_analysis"], now,
                        ),
                    )
                    report_text = json.dumps(simulation, indent=2, sort_keys=True)
                    connection.execute(
                        "INSERT INTO business_artifacts (business_id, artifact_type, title, content, created_at) VALUES (?, 'simulation_report', ?, ?, ?)",
                        (business_id, f"Synthetic customer simulation: {idea_title}", report_text, now),
                    )
                    add_activity(connection, f"Synthetic customer simulation completed for {idea_title}; estimates are not real demand or revenue.")
                if task["mission_type"] == "ready_for_approval":
                    connection.execute(
                        "UPDATE business_ideas SET status = 'proposed' WHERE id = ? AND status != 'approved'",
                        (task["business_idea_id"],),
                    )
                    add_activity(connection, f"{idea_title} is ready for owner review. No public launch or customer outreach has occurred.")
                else:
                    next_stage = {"research": "development", "development": "simulation", "simulation": "ready_for_approval"}[task["mission_type"]]
                    transition_business(
                        connection, business_id, next_stage,
                        f"Automated {task['mission_type']} work completed; moved to internal {next_stage} stage.",
                    )
        return {"task_id": task["id"], "employee_id": task["employee_id"], "model": model}
    finally:
        if "original_timeout" in locals() and original_timeout is not None:
            ollama.timeout = original_timeout
        model_lock.release()


async def scheduler_loop(
    database: Database,
    interval_seconds: int,
    ollama: OllamaClient,
    model_lock: threading.BoundedSemaphore,
    interactive_chat_waiting: threading.Event | None = None,
) -> None:
    recovered = await asyncio.to_thread(recover_unfinished_tasks, database)
    if recovered:
        logger.info("Recovered %s unfinished task(s).", recovered)
    # Seed the visible work queue immediately so employees never look unassigned.
    # Delay model execution briefly so the owner can open a teammate conversation first.
    starter_count = await asyncio.to_thread(seed_initial_team_tasks, database)
    if starter_count:
        logger.info("Created %s first-shift employee task(s).", starter_count)
    startup_delay = max(0, min(180, int(os.getenv("AI_MONEY_TOWN_SCHEDULER_START_DELAY_SECONDS", "10"))))
    if startup_delay:
        await asyncio.sleep(startup_delay)

    # Give the team a short head start, then generate compact idea batches on a
    # cadence designed for a 50-idea/hour target. Local model and CPU capacity
    # determine actual throughput; missed batches are never fabricated.
    initial_idea_delay = max(30, min(1800, int(os.getenv("AI_MONEY_TOWN_INITIAL_IDEA_DELAY_SECONDS", "90"))))
    next_idea_at = time.monotonic() + initial_idea_delay
    idea_retry_delay = max(120, min(600, interval_seconds * 3))
    while True:
        try:
            report = await asyncio.to_thread(run_management_cycle, database)
            logger.info(
                "Portfolio review complete: %s businesses, %s decline(s), %s available bytes of RAM.",
                report["business_count"],
                len(report["declines_detected"]),
                report["resources"]["memory_available_bytes"],
            )
            completed = await asyncio.to_thread(
                process_next_autonomous_task, database, ollama, model_lock, interactive_chat_waiting
            )
            if completed:
                logger.info(
                    "Autonomous task %s completed by %s using the configured local model.",
                    completed["task_id"],
                    completed["employee_id"],
                )
            if time.monotonic() >= next_idea_at:
                idea_report = await asyncio.to_thread(
                    maybe_generate_ideas, database, ollama, model_lock, interactive_chat_waiting
                )
                next_idea_at = time.monotonic() + (
                    max(300, int(os.getenv("AI_MONEY_TOWN_IDEA_INTERVAL_SECONDS", "720")))
                    if idea_report else idea_retry_delay
                )
        except Exception:
            logger.exception("Mayor portfolio review failed; it will retry after the scheduler interval.")
        await asyncio.sleep(interval_seconds)


def scheduler_interval() -> int:
    try:
        return max(20, int(os.getenv("AI_MONEY_TOWN_SCHEDULER_SECONDS", "40")))
    except ValueError:
        logger.warning("Invalid AI_MONEY_TOWN_SCHEDULER_SECONDS; using 120 seconds.")
        return 120
