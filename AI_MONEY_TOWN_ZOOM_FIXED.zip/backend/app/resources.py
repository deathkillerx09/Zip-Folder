from __future__ import annotations

import psutil


def resource_snapshot() -> dict:
    memory = psutil.virtual_memory()
    return {
        "cpu_percent": psutil.cpu_percent(interval=0.1),
        "cpu_count": psutil.cpu_count(logical=True) or 1,
        "memory_available_bytes": memory.available,
        "memory_total_bytes": memory.total,
        "memory_percent_used": memory.percent,
    }
