from __future__ import annotations

import sqlite3
from datetime import datetime, timezone

from fastapi import HTTPException

from .core import add_activity, timestamp


def _verified_totals(connection, business_id: int | None = None) -> dict:
    where = "" if business_id is None else "WHERE business_id = ?"
    parameters = () if business_id is None else (business_id,)
    row = connection.execute(
        f"""
        SELECT
            COALESCE(SUM(CASE WHEN transaction_type = 'payment_settled' AND is_verified = 1
                THEN amount_cents ELSE 0 END), 0) AS actual_revenue_cents,
            COALESCE(SUM(CASE WHEN transaction_type = 'refund' AND is_verified = 1
                THEN amount_cents ELSE 0 END), 0) AS refunds_cents,
            COALESCE(SUM(CASE WHEN transaction_type = 'processing_fee' AND is_verified = 1
                THEN amount_cents ELSE 0 END), 0) AS processing_fees_cents,
            COALESCE(SUM(CASE WHEN transaction_type = 'expense' AND is_verified = 1
                THEN amount_cents ELSE 0 END), 0) AS expenses_cents,
            COALESCE(SUM(CASE WHEN transaction_type = 'reinvestment' AND is_verified = 1
                THEN amount_cents ELSE 0 END), 0) AS reinvestment_cents,
            COALESCE(SUM(CASE WHEN transaction_type = 'payment_settled' AND is_verified = 1
                THEN 1 ELSE 0 END), 0) AS settled_payment_count
        FROM transactions {where}
        """,
        parameters,
    ).fetchone()
    return dict(row)


def finance_summary(connection, business_id: int | None = None) -> dict:
    totals = _verified_totals(connection, business_id)
    business_clause = "" if business_id is None else " AND pending.business_id = ?"
    business_parameters = () if business_id is None else (business_id,)
    pending = connection.execute(
        f"""
        SELECT COALESCE(SUM(MAX(0, pending.amount_cents - COALESCE((
            SELECT SUM(settled.amount_cents) FROM transactions settled
            WHERE settled.source_transaction_id = pending.id
              AND settled.transaction_type = 'payment_settled'
        ), 0))), 0) AS cents
        FROM transactions pending WHERE pending.transaction_type = 'payment_pending'{business_clause}
        """,
        business_parameters,
    ).fetchone()["cents"]
    withdrawal_requests = 0 if business_id is not None else connection.execute(
        "SELECT COALESCE(SUM(amount_cents), 0) FROM transactions WHERE transaction_type = 'withdrawal_request'"
    ).fetchone()[0]
    profit = (
        totals["actual_revenue_cents"]
        - totals["refunds_cents"]
        - totals["processing_fees_cents"]
        - totals["expenses_cents"]
        - totals["reinvestment_cents"]
    )
    available = profit - withdrawal_requests
    settings = connection.execute(
        "SELECT value FROM finance_settings WHERE setting = 'daily_spending_limit_cents'"
    ).fetchone()
    limit = int(settings["value"]) if settings else 0
    estimated = connection.execute(
        """
        SELECT COALESCE(SUM(m.estimated_revenue_cents), 0)
        FROM business_metrics m
        WHERE m.id = (
            SELECT MAX(latest.id) FROM business_metrics latest
            WHERE latest.business_id = m.business_id
        )
        AND (? IS NULL OR m.business_id = ?)
        """,
        (business_id, business_id),
    ).fetchone()[0]
    return {
        **totals,
        "settled_payments_cents": totals["actual_revenue_cents"],
        "estimated_revenue_cents": estimated,
        "estimated_revenue_label": "Latest simulated estimates only; excluded from actual revenue and funds.",
        "pending_payments_cents": pending,
        "profit_cents": profit,
        "available_business_funds_cents": available,
        "withdrawal_requests_cents": withdrawal_requests,
        "daily_spending_limit_cents": limit,
        "actual_sales_label": "Owner-reconciled settled receipts; simulations excluded.",
        "withdrawal_integration_enabled": False,
    }


def finance_transactions(connection, limit: int = 100) -> list[dict]:
    return [
        dict(row)
        for row in connection.execute(
            "SELECT * FROM transactions ORDER BY id DESC LIMIT ?", (limit,)
        )
    ]


def set_spending_limit(connection, amount_cents: int) -> dict:
    if amount_cents < 0:
        raise HTTPException(status_code=422, detail="Spending limit cannot be negative.")
    now = timestamp()
    connection.execute(
        """
        INSERT INTO finance_settings (setting, value, updated_at)
        VALUES ('daily_spending_limit_cents', ?, ?)
        ON CONFLICT(setting) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
        """,
        (str(amount_cents), now),
    )
    add_activity(connection, f"Daily spending authorization limit set to {amount_cents} cents.")
    return finance_summary(connection)


def _insert_transaction(
    connection,
    *,
    business_id: int | None,
    transaction_type: str,
    amount_cents: int,
    external_reference: str,
    evidence_ref: str = "",
    note: str = "",
    source_transaction_id: int | None = None,
    is_verified: bool = False,
) -> dict:
    if amount_cents <= 0:
        raise HTTPException(status_code=422, detail="Amount must be greater than zero.")
    if not external_reference.strip():
        raise HTTPException(status_code=422, detail="An external reference is required.")
    if is_verified and not evidence_ref.strip():
        raise HTTPException(status_code=422, detail="Evidence reference is required to record a verified event.")
    try:
        cursor = connection.execute(
            """
            INSERT INTO transactions
                (business_id, transaction_type, amount_cents, source_transaction_id,
                 external_reference, evidence_ref, note, is_verified, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                business_id,
                transaction_type,
                amount_cents,
                source_transaction_id,
                external_reference.strip(),
                evidence_ref.strip(),
                note.strip(),
                int(is_verified),
                timestamp(),
            ),
        )
    except sqlite3.IntegrityError as error:
        raise HTTPException(status_code=409, detail="Transaction conflicts with an existing ledger record.") from error
    return dict(connection.execute("SELECT * FROM transactions WHERE id = ?", (cursor.lastrowid,)).fetchone())


def record_pending_payment(
    connection,
    business_id: int,
    amount_cents: int,
    external_reference: str,
    note: str = "",
) -> dict:
    if connection.execute("SELECT 1 FROM businesses WHERE id = ?", (business_id,)).fetchone() is None:
        raise HTTPException(status_code=404, detail="Business not found.")
    existing = connection.execute(
        """
        SELECT 1 FROM transactions
        WHERE transaction_type = 'payment_pending' AND business_id = ? AND external_reference = ?
        """,
        (business_id, external_reference.strip()),
    ).fetchone()
    if existing:
        raise HTTPException(status_code=409, detail="A pending payment with this external reference already exists.")
    result = _insert_transaction(
        connection,
        business_id=business_id,
        transaction_type="payment_pending",
        amount_cents=amount_cents,
        external_reference=external_reference,
        note=note,
    )
    add_activity(connection, f"Pending payment recorded for business {business_id}; not counted as actual revenue.")
    return result


def settle_payment(
    connection,
    pending_id: int,
    amount_cents: int,
    evidence_ref: str,
) -> dict:
    pending = connection.execute(
        "SELECT * FROM transactions WHERE id = ? AND transaction_type = 'payment_pending'",
        (pending_id,),
    ).fetchone()
    if pending is None:
        raise HTTPException(status_code=404, detail="Pending payment not found.")
    settled = connection.execute(
        """
        SELECT COALESCE(SUM(amount_cents), 0) FROM transactions
        WHERE source_transaction_id = ? AND transaction_type = 'payment_settled'
        """,
        (pending_id,),
    ).fetchone()[0]
    if amount_cents <= 0 or settled + amount_cents > pending["amount_cents"]:
        raise HTTPException(status_code=409, detail="Settlement exceeds the remaining pending payment.")
    result = _insert_transaction(
        connection,
        business_id=pending["business_id"],
        transaction_type="payment_settled",
        amount_cents=amount_cents,
        external_reference=pending["external_reference"],
        evidence_ref=evidence_ref,
        note="Owner-reconciled against the supplied external evidence reference.",
        source_transaction_id=pending_id,
        is_verified=True,
    )
    add_activity(connection, f"Owner-reconciled payment {pending_id}; verified revenue recorded with evidence.")
    return result


def record_adjustment(
    connection,
    *,
    business_id: int | None,
    transaction_type: str,
    amount_cents: int,
    external_reference: str,
    evidence_ref: str,
    note: str = "",
) -> dict:
    if transaction_type not in {"refund", "processing_fee", "expense", "reinvestment"}:
        raise HTTPException(status_code=422, detail="Unsupported financial adjustment type.")
    if business_id is not None and connection.execute(
        "SELECT 1 FROM businesses WHERE id = ?", (business_id,)
    ).fetchone() is None:
        raise HTTPException(status_code=404, detail="Business not found.")
    if transaction_type == "refund":
        source = connection.execute(
            "SELECT * FROM transactions WHERE id = ? AND transaction_type = 'payment_settled' AND is_verified = 1",
            (int(external_reference) if external_reference.isdigit() else -1,),
        ).fetchone()
        if source is None or (business_id is not None and source["business_id"] != business_id):
            raise HTTPException(status_code=404, detail="Verified source payment not found.")
        refunded = connection.execute(
            "SELECT COALESCE(SUM(amount_cents), 0) FROM transactions WHERE source_transaction_id = ? AND transaction_type = 'refund'",
            (source["id"],),
        ).fetchone()[0]
        if refunded + amount_cents > source["amount_cents"]:
            raise HTTPException(status_code=409, detail="Refund exceeds the unrefunded settled payment.")
        business_id = source["business_id"]
    if transaction_type in {"expense", "reinvestment"}:
        summary = finance_summary(connection, business_id)
        daily_spend = connection.execute(
            """
            SELECT COALESCE(SUM(amount_cents), 0) FROM transactions
            WHERE transaction_type IN ('expense', 'reinvestment')
              AND created_at >= ?
            """,
            (datetime.now(timezone.utc).date().isoformat(),),
        ).fetchone()[0]
        if amount_cents > summary["daily_spending_limit_cents"] - daily_spend:
            raise HTTPException(
                status_code=409,
                detail="Daily spending limit is zero or insufficient; spending is paused.",
            )
        if amount_cents > summary["available_business_funds_cents"]:
            raise HTTPException(
                status_code=409,
                detail="Insufficient verified, available business funds. Personal investment and loans are unavailable.",
            )
    reference = external_reference
    source_id = None
    if transaction_type == "refund":
        source_id = int(external_reference)
        reference = f"refund:{external_reference}"
    result = _insert_transaction(
        connection,
        business_id=business_id,
        transaction_type=transaction_type,
        amount_cents=amount_cents,
        external_reference=reference,
        evidence_ref=evidence_ref,
        note=note,
        source_transaction_id=source_id,
        is_verified=True,
    )
    add_activity(connection, f"Owner-reconciled {transaction_type.replace('_', ' ')} recorded.")
    return result


def request_withdrawal(connection, amount_cents: int, external_reference: str, note: str = "") -> dict:
    summary = finance_summary(connection)
    if amount_cents <= 0 or amount_cents > summary["available_business_funds_cents"]:
        raise HTTPException(status_code=409, detail="Withdrawal request exceeds available business funds.")
    result = _insert_transaction(
        connection,
        business_id=None,
        transaction_type="withdrawal_request",
        amount_cents=amount_cents,
        external_reference=external_reference,
        note="Request only. Withdrawal integration is disabled; no transfer was initiated.",
    )
    add_activity(connection, "Owner withdrawal request recorded; no transfer was initiated.")
    return result
