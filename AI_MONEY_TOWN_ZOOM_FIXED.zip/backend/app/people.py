from __future__ import annotations

from fastapi import HTTPException


def employee_profile(connection, employee_id: str) -> dict:
    employee = connection.execute(
        "SELECT * FROM employees WHERE id = ?", (employee_id,)
    ).fetchone()
    if employee is None:
        raise HTTPException(status_code=404, detail="Employee not found.")
    profile = connection.execute(
        "SELECT * FROM employee_profiles WHERE employee_id = ?", (employee_id,)
    ).fetchone()
    if profile is None:
        raise RuntimeError(f"Employee profile for {employee_id} was not initialized.")
    assignments = [
        dict(row)
        for row in connection.execute(
            """
            SELECT a.*, b.stage, i.title AS business_title
            FROM business_assignments a
            JOIN businesses b ON b.id = a.business_id
            JOIN business_ideas i ON i.id = b.idea_id
            WHERE a.employee_id = ? ORDER BY a.id DESC
            """,
            (employee_id,),
        )
    ]
    tasks = [
        dict(row)
        for row in connection.execute(
            """
            SELECT t.*, i.title AS business_title
            FROM tasks t LEFT JOIN businesses b ON b.id = t.business_id
            LEFT JOIN business_ideas i ON i.id = b.idea_id
            WHERE t.employee_id = ? ORDER BY t.id DESC LIMIT 50
            """,
            (employee_id,),
        )
    ]
    rewards = [
        dict(row)
        for row in connection.execute(
            "SELECT * FROM employee_rewards WHERE employee_id = ? ORDER BY id DESC",
            (employee_id,),
        )
    ]
    messages = [
        dict(row)
        for row in connection.execute(
            "SELECT * FROM messages WHERE employee_id = ? ORDER BY id DESC LIMIT 30",
            (employee_id,),
        )
    ]
    communications = [
        dict(row)
        for row in connection.execute(
            """
            SELECT m.*, sender.name AS sender_name, recipient.name AS recipient_name
            FROM team_messages m
            JOIN employees sender ON sender.id = m.sender_employee_id
            JOIN employees recipient ON recipient.id = m.recipient_employee_id
            WHERE m.sender_employee_id = ? OR m.recipient_employee_id = ?
            ORDER BY m.id DESC LIMIT 30
            """,
            (employee_id, employee_id),
        )
    ]
    successful_projects = [
        dict(row)
        for row in connection.execute(
            """
            SELECT b.id AS business_id, i.title, b.stage,
                COALESCE(SUM(CASE WHEN t.transaction_type = 'payment_settled'
                        AND t.is_verified = 1 THEN t.amount_cents ELSE 0 END), 0)
                  - COALESCE(SUM(CASE WHEN t.transaction_type IN ('refund', 'processing_fee', 'expense', 'reinvestment')
                        AND t.is_verified = 1 THEN t.amount_cents ELSE 0 END), 0) AS verified_profit_cents
            FROM businesses b JOIN business_ideas i ON i.id = b.idea_id
            LEFT JOIN transactions t ON t.business_id = b.id
            GROUP BY b.id, i.title, b.stage
            HAVING EXISTS (
                    SELECT 1 FROM business_assignments a
                    WHERE a.business_id = b.id AND a.employee_id = ?
                )
                AND EXISTS (
                    SELECT 1 FROM employee_rewards r
                    WHERE r.business_id = b.id
                      AND r.employee_id = ?
                      AND r.achievement_code = 'verified_profitable_business'
                )
            ORDER BY b.updated_at DESC
            """,
            (employee_id, employee_id),
        )
    ]
    active_tasks = [task for task in tasks if task["status"] in {"pending", "in_progress"}]
    return {
        "employee": dict(employee),
        "profile": dict(profile),
        "current_project": active_tasks[0] if active_tasks else None,
        "assignments": assignments,
        "achievements": rewards,
        "recent_rewards": rewards[:10],
        "successful_projects": successful_projects,
        "contributions": tasks,
        "conversations": list(reversed(messages)),
        "team_communications": communications,
        "morale_notice": "Morale, reputation, and career values are simulated motivation statistics, not real emotions.",
    }
