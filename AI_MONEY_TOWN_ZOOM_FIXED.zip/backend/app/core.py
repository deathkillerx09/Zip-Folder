from __future__ import annotations

from datetime import datetime, timezone


def timestamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def add_activity(connection, message: str) -> None:
    connection.execute(
        "INSERT INTO activity (message, created_at) VALUES (?, ?)",
        (message, timestamp()),
    )
