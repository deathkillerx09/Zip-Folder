from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator


EMPLOYEES = (
    ("town-manager", "Mayor Wafflebeard", "Mayor", "Runs town meetings, sets priorities, and assigns projects."),
    ("researcher", "Sherlock Beans", "Trend Detective", "Finds customer problems, market trends, and useful clues."),
    ("strategist", "Captain Spreadsheet", "Idea Strategist", "Turns promising research into practical business plans."),
    ("builder", "Gizmo McNoodle", "Product Maker", "Builds and improves useful digital products and prototypes."),
    ("marketer", "Sir Hype-a-Lot", "Marketing Wizard", "Creates honest product stories, designs, and launch experiments."),
    ("finance-analyst", "Cash Moneybags", "Banker & Treasurer", "Keeps the town's virtual ledger, checks verified funds, and explains money records."),
    ("operations", "Inspector Baguette", "Quality Inspector", "Tests products, finds bugs, and checks that work is reliable."),
    ("community-manager", "Bubbles McChat", "Customer Helper", "Listens to customer needs and improves support experiences."),
)


class Database:
    def __init__(self, path: str | Path):
        self.path = Path(path)

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(self.path, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 10000")
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def initialize(self) -> None:
        with self.connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS employees (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    role TEXT NOT NULL,
                    specialty TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'available'
                        CHECK (status IN ('available', 'working', 'offline')),
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL DEFAULT '',
                    employee_id TEXT NOT NULL REFERENCES employees(id),
                    status TEXT NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending', 'in_progress', 'completed')),
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    completed_at TEXT
                );
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    employee_id TEXT NOT NULL REFERENCES employees(id),
                    role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
                    content TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS business_ideas (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'proposed'
                        CHECK (status IN ('proposed', 'evaluating', 'approved', 'archived')),
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS activity (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    message TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS businesses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    idea_id INTEGER NOT NULL UNIQUE REFERENCES business_ideas(id),
                    stage TEXT NOT NULL CHECK (stage IN (
                        'research', 'development', 'simulation', 'ready_for_approval',
                        'live_business', 'growing', 'stable', 'declining', 'revival',
                        'temporarily_dormant', 'archived'
                    )),
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    last_reviewed_at TEXT
                );
                CREATE TABLE IF NOT EXISTS business_artifacts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    business_id INTEGER NOT NULL REFERENCES businesses(id),
                    artifact_type TEXT NOT NULL CHECK (artifact_type IN (
                        'research_brief', 'strategy_brief', 'mvp_blueprint',
                        'simulation_analysis', 'simulation_report', 'launch_checklist',
                        'revival_plan'
                    )),
                    title TEXT NOT NULL,
                    content TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_business_artifacts_business
                    ON business_artifacts(business_id, id DESC);
                CREATE TABLE IF NOT EXISTS business_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    business_id INTEGER NOT NULL REFERENCES businesses(id),
                    event_type TEXT NOT NULL,
                    from_stage TEXT,
                    to_stage TEXT,
                    details TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS business_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    business_id INTEGER NOT NULL REFERENCES businesses(id),
                    estimated_revenue_cents INTEGER NOT NULL DEFAULT 0 CHECK (estimated_revenue_cents >= 0),
                    retention_pct REAL NOT NULL CHECK (retention_pct BETWEEN 0 AND 100),
                    satisfaction_pct REAL NOT NULL CHECK (satisfaction_pct BETWEEN 0 AND 100),
                    growth_pct REAL NOT NULL,
                    customer_feedback TEXT NOT NULL DEFAULT '',
                    competitor_analysis TEXT NOT NULL DEFAULT '',
                    source TEXT NOT NULL DEFAULT 'simulation' CHECK (source = 'simulation'),
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS business_assignments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    business_id INTEGER NOT NULL REFERENCES businesses(id),
                    employee_id TEXT NOT NULL REFERENCES employees(id),
                    assignment_role TEXT NOT NULL,
                    current_project TEXT NOT NULL,
                    assigned_at TEXT NOT NULL,
                    released_at TEXT
                );
                CREATE TABLE IF NOT EXISTS revival_missions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    business_id INTEGER NOT NULL REFERENCES businesses(id),
                    attempt_number INTEGER NOT NULL DEFAULT 1 CHECK (attempt_number > 0),
                    phase TEXT NOT NULL CHECK (phase IN (
                        'investigating', 'solution_planning', 'development',
                        'simulation', 'experiment_recommended', 'paused', 'resolved'
                    )),
                    decline_reason TEXT NOT NULL,
                    customer_feedback TEXT NOT NULL DEFAULT '',
                    sales_retention_analysis TEXT NOT NULL DEFAULT '',
                    competitor_analysis TEXT NOT NULL DEFAULT '',
                    new_market_information TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS employee_profiles (
                    employee_id TEXT PRIMARY KEY REFERENCES employees(id),
                    morale INTEGER NOT NULL DEFAULT 50 CHECK (morale BETWEEN 0 AND 100),
                    experience_points INTEGER NOT NULL DEFAULT 0 CHECK (experience_points >= 0),
                    performance_rating REAL NOT NULL DEFAULT 3.0 CHECK (performance_rating BETWEEN 0 AND 5),
                    reputation INTEGER NOT NULL DEFAULT 50 CHECK (reputation BETWEEN 0 AND 100),
                    career_level TEXT NOT NULL DEFAULT 'novice',
                    virtual_trophies INTEGER NOT NULL DEFAULT 0,
                    workplace_upgrades INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS employee_rewards (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    employee_id TEXT NOT NULL REFERENCES employees(id),
                    business_id INTEGER REFERENCES businesses(id),
                    achievement_code TEXT NOT NULL,
                    badge TEXT NOT NULL,
                    trophy TEXT NOT NULL,
                    experience_points INTEGER NOT NULL CHECK (experience_points > 0),
                    morale_delta INTEGER NOT NULL,
                    reputation_delta INTEGER NOT NULL,
                    evidence_ref TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS team_messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sender_employee_id TEXT NOT NULL REFERENCES employees(id),
                    recipient_employee_id TEXT NOT NULL REFERENCES employees(id),
                    request TEXT NOT NULL,
                    content TEXT NOT NULL,
                    model TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS management_reports (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    report_type TEXT NOT NULL,
                    content TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS finance_settings (
                    setting TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    business_id INTEGER REFERENCES businesses(id),
                    transaction_type TEXT NOT NULL CHECK (transaction_type IN (
                        'payment_pending', 'payment_settled', 'refund', 'processing_fee',
                        'expense', 'reinvestment', 'withdrawal_request'
                    )),
                    amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
                    source_transaction_id INTEGER REFERENCES transactions(id),
                    external_reference TEXT NOT NULL,
                    evidence_ref TEXT NOT NULL DEFAULT '',
                    note TEXT NOT NULL DEFAULT '',
                    is_verified INTEGER NOT NULL DEFAULT 0 CHECK (is_verified IN (0, 1)),
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS transaction_audit (
                    transaction_id INTEGER PRIMARY KEY REFERENCES transactions(id),
                    event TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TRIGGER IF NOT EXISTS transaction_immutable_update
                    BEFORE UPDATE ON transactions BEGIN
                        SELECT RAISE(ABORT, 'financial transaction records are immutable');
                    END;
                CREATE TRIGGER IF NOT EXISTS transaction_immutable_delete
                    BEFORE DELETE ON transactions BEGIN
                        SELECT RAISE(ABORT, 'financial transaction records are immutable');
                    END;
                CREATE TRIGGER IF NOT EXISTS transaction_audit_after_insert
                    AFTER INSERT ON transactions BEGIN
                        INSERT INTO transaction_audit (transaction_id, event, created_at)
                        VALUES (NEW.id, NEW.transaction_type, NEW.created_at);
                    END;
                CREATE TRIGGER IF NOT EXISTS business_event_immutable_update
                    BEFORE UPDATE ON business_events BEGIN
                        SELECT RAISE(ABORT, 'business history records are immutable');
                    END;
                CREATE TRIGGER IF NOT EXISTS business_event_immutable_delete
                    BEFORE DELETE ON business_events BEGIN
                        SELECT RAISE(ABORT, 'business history records are immutable');
                    END;
                CREATE TRIGGER IF NOT EXISTS employee_reward_immutable_update
                    BEFORE UPDATE ON employee_rewards BEGIN
                        SELECT RAISE(ABORT, 'employee reward records are immutable');
                    END;
                CREATE TRIGGER IF NOT EXISTS employee_reward_immutable_delete
                    BEFORE DELETE ON employee_rewards BEGIN
                        SELECT RAISE(ABORT, 'employee reward records are immutable');
                    END;
                CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
                CREATE INDEX IF NOT EXISTS idx_messages_employee ON messages(employee_id, id);
                CREATE INDEX IF NOT EXISTS idx_activity_created ON activity(id DESC);
                CREATE INDEX IF NOT EXISTS idx_business_stage ON businesses(stage);
                CREATE INDEX IF NOT EXISTS idx_business_metrics_latest ON business_metrics(business_id, id DESC);
                CREATE INDEX IF NOT EXISTS idx_assignments_business ON business_assignments(business_id, released_at);
                CREATE INDEX IF NOT EXISTS idx_revival_business ON revival_missions(business_id, id DESC);
                CREATE INDEX IF NOT EXISTS idx_transactions_type ON transactions(transaction_type, id DESC);
                CREATE INDEX IF NOT EXISTS idx_team_messages_employee ON team_messages(sender_employee_id, recipient_employee_id, id DESC);
                CREATE UNIQUE INDEX IF NOT EXISTS idx_reward_business_unique
                    ON employee_rewards(employee_id, business_id, achievement_code)
                    WHERE business_id IS NOT NULL;
                CREATE UNIQUE INDEX IF NOT EXISTS idx_reward_employee_unique
                    ON employee_rewards(employee_id, achievement_code)
                    WHERE business_id IS NULL;
                """
            )
            # Additive migrations keep existing Phase 1 task rows and statuses intact.
            task_columns = {
                row["name"] for row in connection.execute("PRAGMA table_info(tasks)")
            }
            for name, declaration in (
                ("business_id", "INTEGER REFERENCES businesses(id)"),
                ("task_kind", "TEXT NOT NULL DEFAULT 'owner'"),
                ("mission_type", "TEXT"),
                ("dedupe_key", "TEXT"),
                ("result", "TEXT NOT NULL DEFAULT ''"),
                ("idea_id", "INTEGER REFERENCES business_ideas(id)"),
            ):
                if name not in task_columns:
                    connection.execute(f"ALTER TABLE tasks ADD COLUMN {name} {declaration}")
            revival_columns = {
                row["name"] for row in connection.execute("PRAGMA table_info(revival_missions)")
            }
            if "attempt_number" not in revival_columns:
                connection.execute(
                    "ALTER TABLE revival_missions ADD COLUMN attempt_number INTEGER NOT NULL DEFAULT 1"
                )
            connection.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_tasks_dedupe ON tasks(dedupe_key) WHERE dedupe_key IS NOT NULL"
            )
            connection.execute(
                "CREATE INDEX IF NOT EXISTS idx_tasks_idea_status ON tasks(idea_id, status, id)"
            )
            now = datetime.now(timezone.utc).isoformat()
            connection.executemany(
                """
                INSERT OR IGNORE INTO employees (id, name, role, specialty, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                [(employee_id, name, role, specialty, now) for employee_id, name, role, specialty in EMPLOYEES],
            )
            legacy_names = {
                "town-manager": "Avery", "researcher": "Sage", "strategist": "Morgan", "builder": "Riley",
                "marketer": "Jordan", "finance-analyst": "Casey", "operations": "Quinn", "community-manager": "Taylor",
            }
            for employee_id, name, role, specialty in EMPLOYEES:
                legacy_name = legacy_names[employee_id]
                connection.execute(
                    "UPDATE employees SET name = ?, role = ?, specialty = ? WHERE id = ? AND (name = ? OR name = ?)",
                    (name, role, specialty, employee_id, legacy_name, name),
                )
            connection.execute(
                "INSERT INTO activity (message, created_at) "
                "SELECT ?, ? WHERE NOT EXISTS (SELECT 1 FROM activity)",
                ("AI Money Town is ready. All financial figures are simulations, not real revenue.", now),
            )
            connection.executemany(
                """
                INSERT OR IGNORE INTO employee_profiles (employee_id, updated_at)
                VALUES (?, ?)
                """,
                [(employee_id, now) for employee_id, *_ in EMPLOYEES],
            )
            connection.execute(
                """
                INSERT OR IGNORE INTO finance_settings (setting, value, updated_at)
                VALUES ('daily_spending_limit_cents', ?, ?)
                """,
                ("0", now),
            )
            legacy_approved = connection.execute(
                """
                SELECT id, title FROM business_ideas
                WHERE status = 'approved'
                  AND NOT EXISTS (SELECT 1 FROM businesses WHERE idea_id = business_ideas.id)
                """
            ).fetchall()
            for idea in legacy_approved:
                cursor = connection.execute(
                    """
                    INSERT INTO businesses (idea_id, stage, created_at, updated_at)
                    VALUES (?, 'research', ?, ?)
                    """,
                    (idea["id"], now, now),
                )
                business_id = cursor.lastrowid
                connection.execute(
                    """
                    INSERT INTO business_events
                        (business_id, event_type, to_stage, details, created_at)
                    VALUES (?, 'created', 'research', ?, ?)
                    """,
                    (business_id, "Migrated previously approved Phase 1 idea into the research lifecycle.", now),
                )
                cursor = connection.execute(
                    """
                    INSERT INTO tasks
                        (title, description, employee_id, status, created_at, updated_at,
                         business_id, task_kind, mission_type, dedupe_key)
                    VALUES (?, ?, 'researcher', 'pending', ?, ?, ?, 'autonomous', 'research',
                            ?)
                    """,
                    (
                        f"Market research: {idea['title']}",
                        "Continue the approved idea's research using internal, no-cost analysis only.",
                        now,
                        now,
                        business_id,
                        f"business:{business_id}:stage:research",
                    ),
                )
                connection.execute(
                    """
                    INSERT INTO business_assignments
                        (business_id, employee_id, assignment_role, current_project, assigned_at)
                    VALUES (?, 'researcher', 'research', ?, ?)
                    """,
                    (business_id, idea["title"], now),
                )
                connection.execute(
                    "INSERT INTO activity (message, created_at) VALUES (?, ?)",
                    (f"Previously approved idea migrated into business research: {idea['title']}", now),
                )
