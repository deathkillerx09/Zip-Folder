from __future__ import annotations

import json
import os
import socket
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from collections.abc import Iterator


class OllamaError(Exception):
    """Raised when the local Ollama service cannot fulfill a request."""


def select_chat_model(models: list[str], configured: str | None = None) -> str | None:
    """Choose a small conversational model, never an embedding or code-only model."""
    available = set(models)
    if configured and configured in available and not any(tag in configured.lower() for tag in ("embed", "coder", "code")):
        return configured
    for candidate in (
        "qwen3.5:0.8b",
        "llama3.2:1b",
        "gemma2:2b",
        "qwen3:4b",
        "llama3.2:3b",
    ):
        if candidate in available:
            return candidate
    return next((model for model in models if not any(tag in model.lower() for tag in ("embed", "coder", "code"))), None)


class OllamaClient:
    def __init__(self, base_url: str = "http://127.0.0.1:11434", timeout: float = 55.0):
        parsed = urlparse(base_url)
        if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
            raise ValueError("Ollama must use a local HTTP URL (localhost or 127.0.0.1).")
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def _request(self, path: str, payload: dict | None = None) -> dict:
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        request = Request(
            f"{self.base_url}{path}",
            data=data,
            headers={"Content-Type": "application/json"},
            method="GET" if payload is None else "POST",
        )
        try:
            with urlopen(request, timeout=self.timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except (HTTPError, URLError, TimeoutError, socket.timeout, json.JSONDecodeError) as error:
            raise OllamaError(f"Local Ollama request failed: {error}") from error

    def status(self) -> dict:
        try:
            response = self._request("/api/tags")
            models = [model["name"] for model in response.get("models", []) if "name" in model]
            return {"connected": True, "models": models, "error": None}
        except OllamaError as error:
            return {"connected": False, "models": [], "error": str(error)}

    def chat(
        self,
        model: str,
        messages: list[dict[str, str]],
        options: dict | None = None,
    ) -> str:
        generation_options = {
            "temperature": 0.58,
            "num_ctx": int(os.getenv("OLLAMA_NUM_CTX", "1024")),
            "num_predict": int(os.getenv("OLLAMA_NUM_PREDICT", "64")),
        }
        if options:
            generation_options.update(options)
        try:
            response = self._request(
                "/api/chat",
                {
                    "model": model,
                    "messages": messages,
                    "stream": False,
                    "think": False,
                    "keep_alive": "10m",
                    "options": generation_options,
                },
            )
        except OllamaError:
            raise
        try:
            content = response["message"]["content"]
        except (KeyError, TypeError) as error:
            raise OllamaError("Local Ollama returned an invalid chat response.") from error
        if not isinstance(content, str) or not content.strip():
            raise OllamaError("Local Ollama returned an empty chat response.")
        return content.strip()

    def stream_chat(
        self,
        model: str,
        messages: list[dict[str, str]],
        options: dict | None = None,
    ) -> Iterator[str]:
        """Yield answer tokens from Ollama so the town chat never looks frozen."""
        generation_options = {
            "temperature": 0.58,
            "num_ctx": int(os.getenv("OLLAMA_NUM_CTX", "1024")),
            "num_predict": int(os.getenv("OLLAMA_NUM_PREDICT", "48")),
        }
        if options:
            generation_options.update(options)
        request = Request(
            f"{self.base_url}/api/chat",
            data=json.dumps({
                "model": model,
                "messages": messages,
                "stream": True,
                "think": False,
                "keep_alive": "10m",
                "options": generation_options,
            }).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urlopen(request, timeout=self.timeout) as response:
                for raw_line in response:
                    if not raw_line.strip():
                        continue
                    try:
                        packet = json.loads(raw_line.decode("utf-8"))
                    except json.JSONDecodeError as error:
                        raise OllamaError("Local Ollama returned an invalid streaming response.") from error
                    if packet.get("error"):
                        raise OllamaError(str(packet["error"]))
                    message = packet.get("message") or {}
                    token = message.get("content", "")
                    if token:
                        yield token
                    if packet.get("done"):
                        break
        except (HTTPError, URLError, TimeoutError, socket.timeout, OSError) as error:
            raise OllamaError(f"Local Ollama streaming request failed: {error}") from error
