from fastapi.testclient import TestClient

from backend.app.main import create_app


def test_private_site_gate_protects_dashboard_and_api(tmp_path, monkeypatch):
    monkeypatch.setenv("AI_MONEY_TOWN_ACCESS_USERNAME", "town-owner")
    monkeypatch.setenv("AI_MONEY_TOWN_ACCESS_PASSWORD", "test-password-only")

    app = create_app(tmp_path / "private-town.sqlite3", scheduler_enabled=False)
    with TestClient(app) as client:
        assert client.get("/").status_code == 401
        assert client.get("/api/dashboard").status_code == 401
        assert client.get("/static/styles.css").status_code == 401

        credentials = ("town-owner", "test-password-only")
        assert client.get("/", auth=credentials).status_code == 200
        assert client.get("/api/dashboard", auth=credentials).status_code == 200
        assert client.get("/static/styles.css", auth=credentials).status_code == 200
