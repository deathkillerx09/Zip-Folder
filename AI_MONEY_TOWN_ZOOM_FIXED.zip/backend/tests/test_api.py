from pathlib import Path

from fastapi.testclient import TestClient

from backend.app.main import create_app
from backend.app.database import Database


class FakeOllama:
    def status(self):
        return {"connected": True, "models": ["test-model"], "error": None}

    def chat(self, model, messages, options=None):
        assert model == "test-model"
        assert messages[-1]["role"] == "user"
        return "A simulated response."


def client_for(tmp_path: Path) -> TestClient:
    return TestClient(create_app(tmp_path / "test-town.sqlite3", FakeOllama()))


def test_dashboard_seeds_eight_employees_and_separates_task_counts(tmp_path):
    client = client_for(tmp_path)
    response = client.get("/api/dashboard")

    assert response.status_code == 200
    dashboard = response.json()
    assert dashboard["town"]["employee_count"] == 8
    assert dashboard["town"]["active_task_count"] == 0
    assert dashboard["town"]["completed_task_count"] == 0
    assert len(dashboard["employees"]) == 8
    assert dashboard["ollama"]["connected"] is True


def test_task_assignment_and_completion_are_persistent(tmp_path):
    client = client_for(tmp_path)
    created = client.post(
        "/api/tasks",
        json={"title": "Explore customer needs", "description": "Interview simulation", "employee_id": "researcher"},
    )
    assert created.status_code == 201
    task_id = created.json()["id"]
    assert created.json()["employee_name"] == "Sherlock Beans"

    updated = client.patch(f"/api/tasks/{task_id}", json={"status": "completed"})
    assert updated.status_code == 200
    assert updated.json()["completed_at"] is not None

    refreshed = TestClient(create_app(tmp_path / "test-town.sqlite3", FakeOllama()))
    dashboard = refreshed.get("/api/dashboard").json()
    assert dashboard["town"]["active_task_count"] == 0
    assert dashboard["town"]["completed_task_count"] == 1
    assert dashboard["tasks"][0]["status"] == "completed"


def test_ideas_and_employee_conversations_are_saved(tmp_path):
    client = client_for(tmp_path)
    idea = client.post(
        "/api/ideas",
        json={"title": "Local repair directory", "description": "A simulated business concept."},
    )
    assert idea.status_code == 201

    sent = client.post(
        "/api/employees/strategist/messages",
        json={"content": "Suggest a small first experiment.", "model": "test-model"},
    )
    assert sent.status_code == 201
    assert len(sent.json()["messages"]) == 2

    refreshed = TestClient(create_app(tmp_path / "test-town.sqlite3", FakeOllama()))
    messages = refreshed.get("/api/employees/strategist/messages").json()
    assert [message["role"] for message in messages] == ["user", "assistant"]
    assert refreshed.get("/api/dashboard").json()["ideas"][0]["title"] == "Local repair directory"


def test_invalid_employee_or_task_status_returns_client_error(tmp_path):
    client = client_for(tmp_path)
    missing_employee = client.post(
        "/api/tasks",
        json={"title": "Unassigned", "employee_id": "missing"},
    )
    assert missing_employee.status_code == 404

    task = client.post("/api/tasks", json={"title": "Valid", "employee_id": "researcher"})
    invalid_status = client.patch(f"/api/tasks/{task.json()['id']}", json={"status": "cancelled"})
    assert invalid_status.status_code == 422


def test_automation_status_advertises_fifty_idea_hourly_target(tmp_path, monkeypatch):
    monkeypatch.delenv("AI_MONEY_TOWN_IDEA_TARGET_PER_HOUR", raising=False)
    monkeypatch.delenv("AI_MONEY_TOWN_IDEA_BATCH_SIZE", raising=False)
    monkeypatch.delenv("AI_MONEY_TOWN_IDEA_INTERVAL_SECONDS", raising=False)
    client = TestClient(create_app(tmp_path / "automation-status.sqlite3", FakeOllama(), scheduler_enabled=False))
    status = client.get("/api/automation/status")
    assert status.status_code == 200
    assert status.json()["idea_batch_target"] == 10
    assert status.json()["idea_target_per_hour"] == 50
    assert status.json()["idea_batch_interval_seconds"] == 720


def test_city_state_exposes_live_department_ideas_and_hourly_target(tmp_path):
    client = client_for(tmp_path)
    created = client.post(
        "/api/ideas",
        json={"title": "Desk Buddy Timer", "description": "A small focus timer for shared study desks."},
    )
    assert created.status_code == 201

    state = client.get("/api/city/state").json()
    assert state["idea_stats"]["target_per_hour"] == 50
    assert state["idea_stats"]["created_last_hour"] == 1
    assert state["ideas"][0]["title"] == "Desk Buddy Timer"
    assert state["task_summary"]["active"] == 0


def test_city_state_reflects_persistent_employee_tasks_and_treasury(tmp_path):
    client = client_for(tmp_path)
    task = client.post(
        "/api/tasks",
        json={"title": "Check live town state", "employee_id": "researcher"},
    ).json()
    assert client.patch(f"/api/tasks/{task['id']}", json={"status": "in_progress"}).status_code == 200

    state = client.get("/api/city/state").json()
    researcher = next(employee for employee in state["employees"] if employee["id"] == "researcher")

    assert {employee["id"] for employee in state["employees"]} >= {
        "town-manager", "researcher", "strategist", "builder",
    }
    assert researcher["name"] == "Sherlock Beans"
    assert researcher["current_task"]["id"] == task["id"]
    assert researcher["current_task"]["status"] == "in_progress"
    assert state["tasks"]["in_progress"] == 1
    assert state["treasury"]["actual_revenue_cents"] == 0
    assert state["treasury"]["available_business_funds_cents"] == 0


class ChatModelSelectionOllama:
    def __init__(self):
        self.called_model = None
        self.system_prompt = None

    def status(self):
        return {
            "connected": True,
            "models": ["qwen2.5-coder:1.5b", "qwen3:4b", "nomic-embed-text:latest"],
            "error": None,
        }

    def chat(self, model, messages, options=None):
        self.called_model = model
        self.system_prompt = messages[0]["content"]
        return "Let's work through that together."


def test_employee_chat_prefers_a_conversation_model_and_natural_persona(tmp_path):
    ollama = ChatModelSelectionOllama()
    client = TestClient(create_app(tmp_path / "chat-model.sqlite3", ollama, scheduler_enabled=False))
    response = client.post(
        "/api/employees/researcher/messages",
        json={"content": "What are you researching?"},
    )

    assert response.status_code == 201
    assert response.json()["model"] == "qwen3:4b"
    assert ollama.called_model == "qwen3:4b"
    assert "friendly, natural teammate" in ollama.system_prompt
    assert "Be honest about what you have and have not done" in ollama.system_prompt


def test_employee_stream_chat_saves_user_and_assistant_messages(tmp_path):
    client = client_for(tmp_path)
    response = client.post(
        "/api/employees/researcher/messages/stream",
        json={"content": "What should we research first?"},
    )
    assert response.status_code == 200
    assert "text/event-stream" in response.headers["content-type"]
    assert '"type":"meta"' in response.text
    assert '"type":"token"' in response.text
    assert '"type":"done"' in response.text
    messages = client.get("/api/employees/researcher/messages").json()
    assert [message["role"] for message in messages[-2:]] == ["user", "assistant"]
    assert messages[-1]["content"] == "A simulated response."


class EmptyStreamOllama:
    def __init__(self):
        self.fallback_called = False

    def status(self):
        return {"connected": True, "models": ["qwen3.5:0.8b"], "error": None}

    def stream_chat(self, model, messages, options=None):
        return iter(())

    def chat(self, model, messages, options=None):
        self.fallback_called = True
        return "I am here. I can help with the current task."


def test_employee_stream_falls_back_when_model_returns_no_stream_tokens(tmp_path):
    ollama = EmptyStreamOllama()
    client = TestClient(create_app(tmp_path / "empty-stream.sqlite3", ollama, scheduler_enabled=False))
    response = client.post(
        "/api/employees/researcher/messages/stream",
        json={"content": "Are you there?"},
    )
    assert response.status_code == 200
    assert '"type":"status"' in response.text
    assert "I am here" in response.text
    assert '"type":"done"' in response.text
    assert ollama.fallback_called is True


def test_fun_employee_names_and_bank_treasurer_are_seeded(tmp_path):
    client = client_for(tmp_path)
    employees = {employee["id"]: employee for employee in client.get("/api/employees").json()}
    assert employees["town-manager"]["name"] == "Mayor Wafflebeard"
    assert employees["researcher"]["name"] == "Sherlock Beans"
    assert employees["strategist"]["name"] == "Captain Spreadsheet"
    assert employees["finance-analyst"]["name"] == "Cash Moneybags"
    assert employees["finance-analyst"]["role"] == "Banker & Treasurer"


def test_legacy_default_employee_names_migrate_to_custom_names(tmp_path):
    database = Database(tmp_path / "legacy-names.sqlite3")
    database.initialize()
    with database.connect() as connection:
        connection.execute("UPDATE employees SET name = 'Sage', role = 'Market Researcher' WHERE id = 'researcher'")
        connection.execute("UPDATE employees SET name = 'Casey', role = 'Finance Analyst' WHERE id = 'finance-analyst'")
    database.initialize()
    with database.connect() as connection:
        researcher = connection.execute("SELECT name, role FROM employees WHERE id = 'researcher'").fetchone()
        banker = connection.execute("SELECT name, role FROM employees WHERE id = 'finance-analyst'").fetchone()
    assert tuple(researcher) == ("Sherlock Beans", "Trend Detective")
    assert tuple(banker) == ("Cash Moneybags", "Banker & Treasurer")
