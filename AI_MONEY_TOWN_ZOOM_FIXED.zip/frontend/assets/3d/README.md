# Optional 3D art assets

The current town is procedural Three.js geometry. It can render offline, but it is not yet a Genshin Impact-quality art set. A convincing stylized fantasy world needs authored textured GLB/glTF models rather than more primitive boxes and cones.

Recommended free CC0 packs to download separately:

- Quaternius Medieval Village MegaKit (CC0, glTF/FBX/OBJ): https://quaternius.itch.io/medieval-village-megakit
- Quaternius Stylized Nature MegaKit (CC0, textured nature models, glTF/FBX/OBJ): https://quaternius.itch.io/stylized-nature-megakit

Place extracted glTF/GLB assets under this folder before integrating them. The application does not download assets or contact a CDN at runtime. Until proper assets are installed and integrated, the procedural city remains the fallback.
