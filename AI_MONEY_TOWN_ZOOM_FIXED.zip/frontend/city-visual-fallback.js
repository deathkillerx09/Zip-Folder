/*
 * AI Money Town - cinematic clickable department hub.
 * The town uses an isometric Canvas fallback because the local Three.js view
 * presents only its clear colour on the owner's current browser/GPU. Department
 * selection uses a smooth camera push, full-screen fade and custom workspace view.
 * It uses the real city-state API and employee conversation endpoints.
 */
(() => {
  "use strict";
  const viewport = document.getElementById("city-viewport");
  if (!viewport || window.__AMT_PLAYABLE_TOWN) return;

  const canvas = document.createElement("canvas");
  canvas.id = "amt-playable-town";
  canvas.setAttribute("aria-label", "AI Money Town playable isometric world");
  canvas.tabIndex = 0;
  canvas.style.cssText = "position:absolute;inset:0;width:100%;height:100%;display:block;z-index:1;touch-action:pan-y;cursor:default;outline:0;";
  viewport.append(canvas);
  const ctx = canvas.getContext("2d", { alpha: false });
  const loading = document.getElementById("city-loading");
  if (loading) loading.hidden = true;
  const controlHint = document.getElementById("city-controls");
  if (controlHint) controlHint.innerHTML = '<span><strong>Click any department building</strong> to visit its workplace</span><span>Watch the camera glide in, then the screen fades into the department</span><span>Click a teammate to talk · <kbd>Esc</kbd> Return to town</span>';

  // A deliberately spacious 5-by-2 valley layout. The previous 20-unit
  // spacing compressed sign anchors into the same screen columns, causing
  // department names and OPEN buttons to overlap on wide monitors.
  const districts = [
    { id:"innovation", title:"Ideas Workshop", x:-60, z:-34, wall:"#eadcc7", roof:"#8660b4", accent:"#f5dc91", dir:1, h:9.5, tag:"IDEAS", short:"IDEAS", interior:"ideas", subtitle:"Brainstorming, prototypes and clever experiments" },
    { id:"research-lab", title:"Research Library", x:-30, z:-34, wall:"#dbe7df", roof:"#477fa5", accent:"#c4e7ed", dir:1, h:8, tag:"RESEARCH", short:"RESEARCH", interior:"library", subtitle:"Trends, customer needs and market clues" },
    { id:"town-hall", title:"Mayor's Hall", x:0, z:-34, wall:"#f0e1bd", roof:"#b66c42", accent:"#f7d77f", dir:1, h:10, tag:"MAYOR", short:"MAYOR", interior:"hall", subtitle:"Town plans, priorities and team meetings" },
    { id:"product-hq", title:"Maker Workshop", x:30, z:-34, wall:"#e5d7bf", roof:"#478463", accent:"#c2e7b7", dir:1, h:8, tag:"MAKERS", short:"MAKERS", interior:"workshop", subtitle:"Building and improving useful products" },
    { id:"customer-centre", title:"Customer Lounge", x:60, z:-34, wall:"#eddbd4", roof:"#b45e71", accent:"#f6c8cb", dir:1, h:8, tag:"CUSTOMER CARE", short:"CUSTOMER CARE", interior:"lounge", subtitle:"Listening to customers and solving problems" },
    { id:"marketing", title:"Creative Studio", x:-60, z:34, wall:"#ead9e0", roof:"#a75686", accent:"#f5c8df", dir:-1, h:8, tag:"CREATIVE", short:"CREATIVE", interior:"studio", subtitle:"Stories, design and responsible promotion" },
    { id:"sales", title:"Sales Arcade", x:-30, z:34, wall:"#d9e7dc", roof:"#3d897e", accent:"#bde8db", dir:-1, h:8, tag:"SALES", short:"SALES", interior:"arcade", subtitle:"Product displays and customer offers" },
    { id:"central-bank", title:"Central Bank", x:0, z:34, wall:"#e9e0c8", roof:"#3f7059", accent:"#efdf9b", dir:-1, h:10, tag:"CENTRAL BANK", short:"CENTRAL BANK", interior:"bank", subtitle:"The town's accounting ledger and money records" },
    { id:"quality-assurance", title:"Quality Workshop", x:30, z:34, wall:"#dce2ee", roof:"#6579a8", accent:"#cedaf6", dir:-1, h:8, tag:"QUALITY", short:"QUALITY", interior:"quality", subtitle:"Testing, checking and fixing product problems" },
    { id:"recreation", title:"Team Garden", x:60, z:34, wall:"#d9e7cd", roof:"#67975a", accent:"#d8edab", dir:-1, h:7, tag:"TEAM GARDEN", short:"TEAM GARDEN", interior:"garden", subtitle:"A quiet place for breaks and celebrations" },
  ];
  const roleDistrict = {
    "town-manager":"town-hall", researcher:"research-lab", strategist:"innovation",
    builder:"product-hq", marketer:"marketing", "finance-analyst":"central-bank",
    operations:"quality-assurance", "community-manager":"customer-centre",
  };
  const stationLabels = {
    "town-manager":"Mayor's strategy map", researcher:"Trend detective archive", strategist:"Big idea pinboard",
    builder:"Prototype engineering bench", marketer:"Campaign design studio", "finance-analyst":"Vault-side ledger desk",
    operations:"Product testing station", "community-manager":"Customer care counter"
  };
  const stationKinds = {
    "town-manager":"mayor", researcher:"research", strategist:"ideas", builder:"maker",
    marketer:"creative", "finance-analyst":"bank", operations:"quality", "community-manager":"service"
  };
  const colors = ["#4d86a0", "#bd8050", "#638b62", "#9a70b4", "#b96f7a", "#4f9a92", "#7e85ae", "#bd9b4c"];
  const state = { employees:[], tasks:{}, businesses:[], treasury:{}, ideas:[], ideaStats:{target_per_hour:50,created_last_hour:0}, player:{x:0,z:32,facing:0}, velocity:{x:0,z:0}, yaw:0, zoom:6.4, pointer:null, chat:null, worldTime:0, insideBuilding:null, interiorTargets:[], districtPlaques:[], viewCenter:null, hoveredDistrict:null, transitioning:false };
  let width = 1, height = 1, dpr = 1;
  const clamp = (v,a,b) => Math.max(a, Math.min(b,v));
  const mix = (a,b,t) => a + (b-a)*t;
  const money = cents => `$${(Number(cents || 0)/100).toFixed(2)}`;
  const center = () => state.viewCenter ? {x:state.viewCenter.x,z:state.viewCenter.z} : {x:0,z:0};
  const easeInOut = t => t < .5 ? 4*t*t*t : 1-Math.pow(-2*t+2,3)/2;
  function resize() {
    const rect = viewport.getBoundingClientRect();
    width = Math.max(320, rect.width); height = Math.max(360, rect.height);
    dpr = Math.min(window.devicePixelRatio || 1, 1.35);
    canvas.width = Math.round(width*dpr); canvas.height = Math.round(height*dpr);
    ctx.setTransform(dpr,0,0,dpr,0,0);
    draw();
  }
  function project(x,y=0,z=0) {
    const c=center(), cs=Math.cos(state.yaw), sn=Math.sin(state.yaw);
    const dx=x-c.x, dz=z-c.z;
    const rx=dx*cs-dz*sn, rz=dx*sn+dz*cs;
    return {x:width*.5+(rx-rz)*.707106*state.zoom, y:height*.51+(rx+rz)*.355*state.zoom-y*state.zoom*.88};
  }
  function path(points, fill, stroke=null, lineWidth=1) {
    ctx.beginPath(); points.forEach((p,i)=>{const q=project(p[0],p[1]||0,p[2]); if(i===0)ctx.moveTo(q.x,q.y);else ctx.lineTo(q.x,q.y);}); ctx.closePath();
    if(fill){ctx.fillStyle=fill;ctx.fill();} if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=lineWidth;ctx.stroke();}
  }
  function line(points, color, thickness=1, dash=[]) {
    ctx.beginPath(); points.forEach((p,i)=>{const q=project(p[0],p[1]||0,p[2]); if(i===0)ctx.moveTo(q.x,q.y);else ctx.lineTo(q.x,q.y);});
    ctx.strokeStyle=color;ctx.lineWidth=thickness;ctx.lineCap="round";ctx.lineJoin="round";ctx.setLineDash(dash);ctx.stroke();ctx.setLineDash([]);
  }
  function ellipseAt(x,y,z,rx,ry,fill,shadow=false) {
    const p=project(x,y,z);ctx.beginPath();ctx.ellipse(p.x,p.y,rx*state.zoom,ry*state.zoom,0,0,Math.PI*2);ctx.fillStyle=fill;
    if(shadow){ctx.shadowColor="#243d2c55";ctx.shadowBlur=10*state.zoom/5;ctx.shadowOffsetY=3;}ctx.fill();ctx.shadowColor="transparent";ctx.shadowBlur=0;ctx.shadowOffsetY=0;
  }
  function worldText(text,x,y,z,size=10,color="#fff",weight=700) {
    const p=project(x,y,z);ctx.font=`${weight} ${size}px system-ui,Segoe UI,sans-serif`;ctx.textAlign="center";ctx.textBaseline="middle";
    ctx.lineWidth=3;ctx.strokeStyle="#203a31cc";ctx.strokeText(text,p.x,p.y);ctx.fillStyle=color;ctx.fillText(text,p.x,p.y);
  }
  function drawBackground() {
    const g=ctx.createLinearGradient(0,0,0,height);g.addColorStop(0,"#8dc8e5");g.addColorStop(.48,"#c5e1d2");g.addColorStop(1,"#8cb878");ctx.fillStyle=g;ctx.fillRect(0,0,width,height);
    // Soft, layered alpine skyline gives the map an open-world horizon.
    for(let layer=0;layer<3;layer++){
      const y=height*(.28+layer*.085), color=["#789b9b","#6f987d","#5c9368"][layer];
      ctx.beginPath();ctx.moveTo(0,height);ctx.lineTo(0,y+75);
      for(let x=-40;x<=width+80;x+=80){const peak=y+Math.sin(x*.013+layer*2)*24-Math.abs(Math.sin(x*.027+layer))*45;ctx.lineTo(x,peak);ctx.lineTo(x+38,peak+34);}
      ctx.lineTo(width,height);ctx.closePath();ctx.fillStyle=color;ctx.globalAlpha=.22+layer*.1;ctx.fill();ctx.globalAlpha=1;
    }
    const glow=ctx.createRadialGradient(width*.52,height*.38,10,width*.52,height*.38,width*.62);glow.addColorStop(0,"#fff4c655");glow.addColorStop(1,"#fff4c600");ctx.fillStyle=glow;ctx.fillRect(0,0,width,height);
  }
  function drawMeadow() {
    path([[-145,0,-120],[145,0,-120],[145,0,120],[-145,0,120]],"#8fbd78");
    // Meadow patches with soft painterly edges.
    for(let i=0;i<28;i++){
      const x=Math.sin(i*91.7)*95,z=Math.cos(i*47.3)*83,r=5+(i%5)*2;
      ellipseAt(x,0.015,z,r*1.4,r*.75,["#a2c982","#7eae70","#b0ce86","#91b97c"][i%4]);
    }
    // River ribbon curves along the valley's eastern edge.
    const river=[];for(let i=0;i<=20;i++){const z=-75+i*7.5;river.push([112+Math.sin(i*.31)*6,0.055,z]);}
    line(river,"#527f72",11*state.zoom/5);line(river,"#75c9d0",8.2*state.zoom/5);line(river.map(([x,y,z])=>[x-1,y+.01,z]),"#d2f2e7",.8*state.zoom/5);
    // Hills and boulders in the distance.
    for(let i=0;i<20;i++){
      const x=-120+i*13,z=-88-(i%3)*8,r=5+(i%4)*2;ellipseAt(x,0,z,r*1.3,r*.58,["#73966a","#698b69","#92a77b"][i%3]);
    }
  }
  function drawRoads() {
    path([[-82,.03,-5.0],[82,.03,-5.0],[82,.03,5.0],[-82,.03,5.0]],"#9d9b8e");
    path([[-82,.06,-4.1],[82,.06,-4.1],[82,.06,4.1],[-82,.06,4.1]],"#5a625e");
    line([[-78,.1,0],[78,.1,0]],"#e9d9a9",.8,[7,6]);
    for(const d of districts){const end=d.z+d.dir*5.7;path([[d.x-2.35,.04,0],[d.x+2.35,.04,0],[d.x+2.35,.04,end],[d.x-2.35,.04,end]],"#858a80");path([[d.x-1.78,.08,0],[d.x+1.78,.08,0],[d.x+1.78,.08,end],[d.x-1.78,.08,end]],"#666e68");line([[d.x-1.7,.12,end],[d.x+1.7,.12,end]],"#e2d8ba",.7,[3,3]);}
    // Stone-edged sidewalks and plaza paving.
    for(const z of [-5.8,5.8])line([[-80,.14,z],[80,.14,z]],"#d2c8a9",1.5);
    path([[-13,.12,-10],[13,.12,-10],[13,.12,10],[-13,.12,10]],"#bdb49b");
    for(let x=-11;x<=11;x+=2.2)line([[x,.14,-9],[x,.14,9]],"#a9a28f",.55);
  }
  function drawTree(x,z,s=1) {
    const p=project(x,0,z), sc=state.zoom*s;
    // shadow, trunk, rounded layered canopy; no primitive cube silhouettes.
    ctx.beginPath();ctx.ellipse(p.x+2*sc,p.y,1.02*sc,.42*sc,0,0,Math.PI*2);ctx.fillStyle="#34533a55";ctx.fill();
    const trunk=project(x,.9*s,z);ctx.strokeStyle="#73513b";ctx.lineWidth=2.6*s*state.zoom/5;ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(trunk.x,trunk.y);ctx.stroke();
    const crown=project(x,2.45*s,z);const r=state.zoom*1.45*s;
    for(const [ox,oy,rr,col] of [[-r*.65,-r*.1,r*.78,"#367c51"],[r*.55,-r*.2,r*.84,"#4d9a61"],[0,-r*.86,r*.95,"#5baa6c"],[-r*.1,-r*1.38,r*.58,"#77bd77"]]){
      ctx.beginPath();ctx.arc(crown.x+ox,crown.y+oy,rr,0,Math.PI*2);ctx.fillStyle=col;ctx.fill();
      ctx.beginPath();ctx.arc(crown.x+ox-r*.2,crown.y+oy-r*.25,rr*.28,0,Math.PI*2);ctx.fillStyle="#c3e49a33";ctx.fill();
    }
  }
  function drawBuilding(d) {
    const x=d.x,z=d.z,w=10.8,dep=8.8,h=d.h,dir=d.dir;
    // Soft drop shadow and raised stone plinth.
    path([[x-w/2,0,z-dep/2],[x+w/2,0,z-dep/2],[x+w/2,0,z+dep/2],[x-w/2,0,z+dep/2]],"#3658443d");
    path([[x-w/2-.7,.25,z-dep/2-.7],[x+w/2+.7,.25,z-dep/2-.7],[x+w/2+.7,.25,z+dep/2+.7],[x-w/2-.7,.25,z+dep/2+.7]],"#b9b39d","#e6ddc5",1);
    // Main walls, two distinct sunlit faces.
    path([[x-w/2,.35,z+dep/2],[x+w/2,.35,z+dep/2],[x+w/2,h,z+dep/2],[x-w/2,h,z+dep/2]],d.wall,"#ab987b",1);
    path([[x+w/2,.35,z+dep/2],[x+w/2,.35,z-dep/2],[x+w/2,h,z-dep/2],[x+w/2,h,z+dep/2]],"#b9ac93","#97866e",1);
    // Timber beams and base course.
    for(const edgeX of [x-w/2+.45,x+w/2-.45])line([[edgeX,.5,z+dep/2+.025],[edgeX,h-.2,z+dep/2+.025]],"#80583e",1.8);
    line([[x-w/2,.8,z+dep/2+.04],[x+w/2,.8,z+dep/2+.04]],"#987453",1.5);
    // Deep front windows with warm panes and cross mullions.
    for(const wx of [x-3.6,x-1.3,x+1.3,x+3.6])for(const wy of [2.3,5.0]){
      path([[wx-.55,wy-.62,z+dep/2+.05],[wx+.55,wy-.62,z+dep/2+.05],[wx+.55,wy+.62,z+dep/2+.05],[wx-.55,wy+.62,z+dep/2+.05]],"#34555a","#ead9b4",.8);
      path([[wx-.4,wy-.45,z+dep/2+.09],[wx+.4,wy-.45,z+dep/2+.09],[wx+.4,wy+.4,z+dep/2+.09],[wx-.4,wy+.4,z+dep/2+.09]],"#9bcbd0");
      line([[wx,wy-.6,z+dep/2+.12],[wx,wy+.6,z+dep/2+.12]],"#e8d9b6",.7);
    }
    // Arched entry and lanterns.
    path([[x-1,.35,z+dep/2+.12],[x+1,.35,z+dep/2+.12],[x+1,2.55,z+dep/2+.12],[x-1,2.55,z+dep/2+.12]],"#604536","#d9c49d",1);
    path([[x-.65,.4,z+dep/2+.16],[x+.65,.4,z+dep/2+.16],[x+.65,2.28,z+dep/2+.16],[x-.65,2.28,z+dep/2+.16]],"#244c4c");
    for(const lx of [x-1.6,x+1.6]){const lp=project(lx,2.9,z+dep/2+.2);ctx.fillStyle="#ffe3a0";ctx.shadowColor="#ffcc69";ctx.shadowBlur=8;ctx.beginPath();ctx.arc(lp.x,lp.y,2.4,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;}
    // Pitched, layered roof with visible gable silhouette.
    path([[x-w/2-.5,h,z-dep/2-.45],[x+w/2+.5,h,z-dep/2-.45],[x+w/2+.5,h,z+dep/2+.45],[x-w/2-.5,h,z+dep/2+.45]],d.roof,"#513d38",1.3);
    path([[x-w/2-.7,h,z+dep/2+.7],[x+w/2+.7,h,z+dep/2+.7],[x,h+3.3,z+dep/2*.12],[x-w/2-.7,h,z+dep/2+.7]],d.roof,"#5b4038",1);
    path([[x-w/2-.7,h,z-dep/2-.7],[x+w/2+.7,h,z-dep/2-.7],[x,h+3.3,z-dep/2*.12],[x-w/2-.7,h,z-dep/2-.7]],"#8d5747","#553b35",1);
    // Roof ridge, dormers and guild crest.
    line([[x-w/2,h+3.32,z],[x+w/2,h+3.32,z]],"#e2b879",1.5);
    for(const ox of [-2.65,2.65]){path([[x+ox-.72,h+1.0,z+dir*1.0],[x+ox+.72,h+1.0,z+dir*1.0],[x+ox+.72,h+2.5,z+dir*1.0],[x+ox-.72,h+2.5,z+dir*1.0]],"#d8c5a5","#765746",.8);}
    // Each district gets a different roof landmark so the town is readable at a glance.
    const crest=project(x,h+3.25,z);
    if(d.id==="central-bank"){
      ctx.fillStyle="#d3b567";ctx.beginPath();ctx.ellipse(crest.x,crest.y-2,13,7,0,Math.PI,Math.PI*2);ctx.fill();ctx.strokeStyle="#f3df9d";ctx.lineWidth=1.5;ctx.stroke();
      ctx.fillStyle="#f5dc8d";ctx.beginPath();ctx.arc(crest.x,crest.y-9,3,0,Math.PI*2);ctx.fill();
    }else if(d.id==="research-lab"){
      ctx.strokeStyle="#4d6671";ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(crest.x-8,crest.y+5);ctx.lineTo(crest.x+8,crest.y-13);ctx.stroke();ctx.fillStyle="#d6eff0";ctx.beginPath();ctx.arc(crest.x+8,crest.y-13,5,0,Math.PI*2);ctx.fill();ctx.stroke();
    }else if(d.id==="innovation"){
      ctx.fillStyle="#b5a0e8";ctx.strokeStyle="#f4e2aa";ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(crest.x,crest.y-18);ctx.lineTo(crest.x+10,crest.y-2);ctx.lineTo(crest.x,crest.y+6);ctx.lineTo(crest.x-10,crest.y-2);ctx.closePath();ctx.fill();ctx.stroke();
    }else if(d.id==="town-hall"){
      ctx.strokeStyle="#73513b";ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(crest.x,crest.y+6);ctx.lineTo(crest.x,crest.y-22);ctx.stroke();ctx.fillStyle="#bb594e";ctx.beginPath();ctx.moveTo(crest.x,crest.y-22);ctx.lineTo(crest.x+18,crest.y-17);ctx.lineTo(crest.x,crest.y-11);ctx.closePath();ctx.fill();
    }else if(d.id==="product-hq"){
      ctx.fillStyle="#547967";ctx.fillRect(crest.x-9,crest.y-13,18,15);ctx.strokeStyle="#f0d39b";ctx.lineWidth=2;ctx.beginPath();ctx.arc(crest.x,crest.y-4,7,0,Math.PI*2);ctx.stroke();
    }else if(d.id==="marketing"){
      for(let i=0;i<3;i++){ctx.fillStyle=["#e58eaf","#8fc7d0","#e7c875"][i];ctx.beginPath();ctx.moveTo(crest.x-13+i*13,crest.y-7);ctx.lineTo(crest.x-5+i*13,crest.y-7);ctx.lineTo(crest.x-9+i*13,crest.y+5);ctx.closePath();ctx.fill();}
    }else if(d.id==="quality-assurance"){
      ctx.strokeStyle="#f0e5c1";ctx.lineWidth=3;ctx.beginPath();ctx.arc(crest.x-2,crest.y-4,7,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.moveTo(crest.x+3,crest.y+1);ctx.lineTo(crest.x+11,crest.y+9);ctx.stroke();
    }else if(d.id==="customer-centre"){
      ctx.fillStyle="#e6a0a3";ctx.beginPath();ctx.moveTo(crest.x-15,crest.y+5);ctx.lineTo(crest.x,crest.y-9);ctx.lineTo(crest.x+15,crest.y+5);ctx.closePath();ctx.fill();
    }else if(d.id==="sales"){
      ctx.fillStyle="#e4c87b";ctx.fillRect(crest.x-10,crest.y-8,20,14);ctx.fillStyle="#4b7e76";ctx.fillRect(crest.x-6,crest.y-4,12,7);
    }else if(d.id==="recreation"){
      ctx.fillStyle="#6ea36a";for(let i=0;i<3;i++){ctx.beginPath();ctx.ellipse(crest.x-8+i*8,crest.y-3,5,9,(i-1)*.5,0,Math.PI*2);ctx.fill();}
    }
    // Department names and entry controls are drawn together in a dedicated
    // screen-space plaque pass, so nearby buildings cannot cover one another.
  }
  function drawFountain() {
    const p=project(0,0,0);const s=state.zoom;
    ctx.beginPath();ctx.ellipse(p.x,p.y,3.9*s,2.1*s,0,0,Math.PI*2);ctx.fillStyle="#6a8279";ctx.fill();ctx.strokeStyle="#e1deca";ctx.lineWidth=2;ctx.stroke();
    const q=project(0,.9,0);ctx.beginPath();ctx.ellipse(q.x,q.y,2.65*s,1.4*s,0,0,Math.PI*2);ctx.fillStyle="#62bdd0";ctx.fill();ctx.strokeStyle="#d9e6d7";ctx.lineWidth=2;ctx.stroke();
    const orb=project(0,2.3,0);ctx.beginPath();ctx.arc(orb.x,orb.y,Math.max(3,s*.53),0,Math.PI*2);ctx.fillStyle="#9ce8e8";ctx.shadowColor="#6adce8";ctx.shadowBlur=12;ctx.fill();ctx.shadowBlur=0;
  }
  function drawFlowerPatch(x,z) {
    for(let i=0;i<8;i++){const p=project(x+Math.sin(i*7)*.8,.35,z+Math.cos(i*5)*.7);ctx.beginPath();ctx.arc(p.x,p.y,1.1,0,Math.PI*2);ctx.fillStyle=["#f6d17d","#eea5b0","#eee8bb","#c6b5e7"][i%4];ctx.fill();}
  }
  function employeeLocation(employee,index) {
    const id=roleDistrict[employee.id] || districts[index%districts.length].id;
    const d=districts.find(item=>item.id===id)||districts[index%districts.length];
    return {x:d.x+(index%2?1.8:-1.8),z:d.z+(index%3-1)*1.45};
  }
  function drawEmployee(employee,index,time) {
    const pos=employeeLocation(employee,index), bob=Math.sin(time*2.2+index)*.035;
    const p=project(pos.x,0,pos.z), sc=state.zoom;
    ctx.beginPath();ctx.ellipse(p.x,p.y+2,5.2*sc/5,2.6*sc/5,0,0,Math.PI*2);ctx.fillStyle="#314c3850";ctx.fill();
    const body=project(pos.x,.75+bob,pos.z), head=project(pos.x,1.58+bob,pos.z);
    ctx.beginPath();ctx.ellipse(body.x,body.y,4.6*sc/5,7.4*sc/5,0,0,Math.PI*2);ctx.fillStyle=colors[index%colors.length];ctx.fill();ctx.strokeStyle="#fff4d8";ctx.lineWidth=1;ctx.stroke();
    ctx.beginPath();ctx.arc(head.x,head.y,3.1*sc/5,0,Math.PI*2);ctx.fillStyle="#edc39f";ctx.fill();
    ctx.beginPath();ctx.arc(head.x,head.y-1.2*sc/5,3.2*sc/5,Math.PI,Math.PI*2);ctx.fillStyle=["#45392f","#6b4938","#312d31","#876144"][index%4];ctx.fill();
    const busy=employee.current_task && ["pending","in_progress"].includes(employee.current_task.status);
    if(busy){ctx.fillStyle="#24513c";ctx.beginPath();ctx.arc(p.x+8,p.y-12,3.5,0,Math.PI*2);ctx.fill();ctx.fillStyle="#a5f0b3";ctx.beginPath();ctx.arc(p.x+8,p.y-12,1.5,0,Math.PI*2);ctx.fill();}
    const label=project(pos.x,2.25,pos.z);ctx.font="700 8px system-ui";ctx.textAlign="center";ctx.lineWidth=3;ctx.strokeStyle="#1b3a30";ctx.strokeText(employee.name||employee.role,label.x,label.y);ctx.fillStyle="#fff";ctx.fillText(employee.name||employee.role,label.x,label.y);
  }
  function drawPlayer(time) {
    const {x,z}=state.player,p=project(x,0,z),sc=state.zoom;
    ctx.beginPath();ctx.ellipse(p.x,p.y+2,6.5*sc/5,3.2*sc/5,0,0,Math.PI*2);ctx.fillStyle="#263a365c";ctx.fill();
    const b=project(x,.78,z),h=project(x,1.64,z);
    ctx.beginPath();ctx.ellipse(b.x,b.y,5.6*sc/5,8.2*sc/5,0,0,Math.PI*2);ctx.fillStyle="#2e7180";ctx.fill();ctx.strokeStyle="#f7dc9a";ctx.lineWidth=1.3;ctx.stroke();
    ctx.beginPath();ctx.arc(h.x,h.y,3.6*sc/5,0,Math.PI*2);ctx.fillStyle="#edc29c";ctx.fill();
    ctx.beginPath();ctx.arc(h.x,h.y-1.2*sc/5,3.6*sc/5,Math.PI,Math.PI*2);ctx.fillStyle="#49372e";ctx.fill();
    const pack=project(x+.42,.9,z+.12);ctx.fillStyle="#e5b55f";ctx.fillRect(pack.x-2,pack.y-3,4,6);
  }
  function drawDepartmentPlaques(){
    state.districtPlaques=[];
    const occupied=[];
    const candidates=[[0,0],[0,-40],[0,40],[-52,0],[52,0],[0,-78],[0,78],[-52,-40],[52,-40],[-52,40],[52,40]];
    for(const d of districts){
      const anchor=project(d.x,d.h+3.25,d.z);
      const title=(d.title||d.tag).toUpperCase();
      ctx.font="800 8px system-ui";
      const cardW=clamp(ctx.measureText(title).width+24,108,130),cardH=34;
      let chosen=null;
      for(const [ox,oy] of candidates){
        const x=clamp(anchor.x-cardW/2+ox,8,width-cardW-8);
        const y=clamp(anchor.y+18-cardH/2+oy,184,height-cardH-56);
        const box={x,y,w:cardW,h:cardH};
        const collision=occupied.some(other=>!(box.x+box.w+8<other.x||other.x+other.w+8<box.x||box.y+box.h+7<other.y||other.y+other.h+7<box.y));
        if(!collision){chosen=box;break;}
      }
      if(!chosen)chosen={x:clamp(anchor.x-cardW/2,8,width-cardW-8),y:clamp(anchor.y+18-cardH/2,184,height-cardH-56),w:cardW,h:cardH};
      occupied.push(chosen);
      const hovered=state.hoveredDistrict===d.id;
      ctx.save();
      ctx.shadowColor=hovered?"#f5d98eaa":"#14271c66";ctx.shadowBlur=hovered?16:8;ctx.shadowOffsetY=3;
      rounded(chosen.x,chosen.y,chosen.w,cardH,8,hovered?"#264d3b":"#17372fef",hovered?"#fff0b8":"#d9c18a",hovered?2:1.2);
      ctx.shadowColor="transparent";ctx.shadowBlur=0;ctx.shadowOffsetY=0;
      ctx.fillStyle=d.accent||"#e8c985";rounded(chosen.x+7,chosen.y+7,3,cardH-14,2,d.accent||"#e8c985");
      ctx.textAlign="center";ctx.textBaseline="middle";
      ctx.font="800 8px system-ui";ctx.fillStyle="#fff5dc";
      ctx.fillText(title,chosen.x+chosen.w/2+3,chosen.y+11,chosen.w-18);
      ctx.font="700 6.5px system-ui";ctx.fillStyle=hovered?"#fff1c5":"#c8d8cb";
      ctx.fillText(hovered?"OPEN WORKPLACE ↗":"CLICK TO ENTER ↗",chosen.x+chosen.w/2+3,chosen.y+25,chosen.w-18);
      ctx.restore();
      state.districtPlaques.push({district:d,...chosen});
    }
  }
  function draw() {
    if(!ctx||!width||!height)return;
    state.worldTime+=.016;
    if(state.insideBuilding){
      const district=districts.find(item=>item.id===state.insideBuilding);
      if(district){drawInterior(district);return;}
      state.insideBuilding=null;
    }
    drawBackground();drawMeadow();drawRoads();
    // Layer foliage and buildings by isometric depth so near objects overlap correctly.
    const renderables=[];
    for(let i=0;i<72;i++){const angle=i*2.399, r=65+(i%9)*6;renderables.push({depth:Math.cos(angle)*r+Math.sin(angle)*r*.72,draw:()=>drawTree(Math.cos(angle)*r,Math.sin(angle)*r*.72,.78+(i%5)*.12)});}
    for(const d of districts)renderables.push({depth:d.x+d.z,draw:()=>drawBuilding(d)});
    renderables.push({depth:0,draw:drawFountain});
    for(let i=0;i<28;i++){const x=-58+i*4.3,z=(i%2?1:-1)*8.5;renderables.push({depth:x+z,draw:()=>drawFlowerPatch(x,z)});}
    renderables.sort((a,b)=>a.depth-b.depth);for(const item of renderables)item.draw();
    drawDepartmentPlaques();
    const status=document.getElementById("city-render-status");if(status){status.textContent=`${state.employees.length} staff · select a department · ${state.tasks.in_progress||0} working · ${state.tasks.pending||0} queued`;status.dataset.state="ready";}
    const loc=document.getElementById("city-location-name");if(loc)loc.textContent="AI Money Town · Choose a department";
  }
  function frame(t){
    state.last=t;
    // Gentle ambient animation only. There is deliberately no WASD or avatar movement.
    if(!state.transitioning) draw();
    requestAnimationFrame(frame);
  }
  function nearestEmployee() {
    if(state.insideBuilding){const staff=state.employees.filter(e=>(roleDistrict[e.id]||"")===state.insideBuilding);return staff[0]||null;}
    return null;
  }
  function hitDistrict(mx,my){
    // The visible plaque is the first hit target; the roof/body remains clickable too.
    const plaque=state.districtPlaques.find(item=>mx>=item.x&&mx<=item.x+item.w&&my>=item.y&&my<=item.y+item.h);
    if(plaque)return plaque.district;
    let best=null,bestScore=Infinity;
    for(const d of districts){
      const p=project(d.x,d.h+2.8,d.z);
      const dx=Math.abs(mx-p.x),dy=Math.abs(my-p.y);
      const nx=dx/Math.max(62,84*state.zoom/6),ny=dy/Math.max(44,64*state.zoom/6);
      if(nx<=1&&ny<=1){const score=nx*nx+ny*ny;if(score<bestScore){best=d;bestScore=score;}}
    }
    return best;
  }
  function transitionCurtain(){
    let overlay=document.getElementById("amt-department-transition");
    if(overlay)return overlay;
    overlay=document.createElement("div");overlay.id="amt-department-transition";
    overlay.innerHTML='<div class="amt-transition-glow"></div><div class="amt-transition-copy"><span class="amt-transition-eyebrow">AI MONEY TOWN  ·  DEPARTMENT ACCESS</span><strong id="amt-transition-title">Entering department</strong><small id="amt-transition-subtitle">A new workspace awaits</small><i></i></div>';
    overlay.style.cssText="position:absolute;inset:0;z-index:60;display:grid;place-items:center;pointer-events:none;opacity:0;background:radial-gradient(ellipse at 50% 48%,#17251ee8 0%,#07100df7 65%,#020605 100%);transition:opacity 420ms cubic-bezier(.22,.75,.24,1);overflow:hidden";
    const style=document.createElement("style");style.textContent=`
      #amt-department-transition .amt-transition-glow{position:absolute;width:min(64vw,620px);height:min(64vw,620px);border-radius:50%;background:radial-gradient(circle,#d6b76b28 0%,#b8934820 30%,transparent 70%);filter:blur(18px);transform:scale(.72);transition:transform 850ms ease,opacity 850ms ease;opacity:0}
      #amt-department-transition .amt-transition-copy{position:relative;display:grid;gap:13px;justify-items:center;text-align:center;opacity:0;transform:translateY(18px);transition:opacity 420ms ease,transform 650ms cubic-bezier(.2,.7,.2,1);padding:24px}
      #amt-department-transition .amt-transition-eyebrow{color:#d8c18a;font:800 10px/1.2 system-ui,sans-serif;letter-spacing:.24em}
      #amt-department-transition strong{color:#fff8e9;font:700 clamp(25px,4vw,48px)/1.08 Georgia,serif;text-shadow:0 5px 28px #0008}
      #amt-department-transition small{color:#d9ded3;font:500 12px/1.5 system-ui,sans-serif;letter-spacing:.06em}
      #amt-department-transition i{display:block;width:76px;height:2px;margin-top:7px;background:linear-gradient(90deg,transparent,#e8cc87,transparent);box-shadow:0 0 18px #e8cc8777}
      #amt-department-transition.is-visible .amt-transition-copy{opacity:1;transform:translateY(0)}
      #amt-department-transition.is-visible .amt-transition-glow{opacity:1;transform:scale(1.1)}
      .city-viewport.department-mode #city-controls,
      .city-viewport.department-mode .city-hud-top,
      .city-viewport.department-mode .city-minimap-panel,
      .city-viewport.department-mode #city-action-prompt{display:none!important}
      .city-viewport.department-mode #city-return-town{display:block!important}
      .city-return-town{z-index:55!important}
    `;document.head.append(style);viewport.append(overlay);return overlay;
  }
  function setTransitionText(title,subtitle){
    const overlay=transitionCurtain();
    overlay.querySelector("#amt-transition-title").textContent=title;
    overlay.querySelector("#amt-transition-subtitle").textContent=subtitle||"";
    return overlay;
  }
  function animateCameraTo(d){
    return new Promise(resolve=>{
      const origin=center(),startZoom=state.zoom,target={x:d.x,z:d.z+2.5};
      const start=performance.now(),duration=880;
      state.transitioning=true;
      const overlay=setTransitionText(`Entering ${d.title}`,d.subtitle);
      overlay.style.opacity="0";overlay.classList.remove("is-visible");
      const tick=now=>{
        const p=clamp((now-start)/duration,0,1),e=easeInOut(p);
        state.viewCenter={x:mix(origin.x,target.x,e),z:mix(origin.z,target.z,e)};
        state.zoom=mix(startZoom,10.8,e);
        draw();
        if(p>.38){overlay.style.opacity=String(clamp((p-.38)/.62,0,1));if(p>.57)overlay.classList.add("is-visible");}
        if(p<1)requestAnimationFrame(tick);else resolve(overlay);
      };
      requestAnimationFrame(tick);
    });
  }
  async function enterBuilding(d){
    if(state.transitioning||state.insideBuilding)return;
    const returnButton=document.getElementById("city-return-town");
    const overlay=await animateCameraTo(d);
    // Swap scene while the screen is fully dark; the department fades in beneath it.
    state.insideBuilding=d.id;state.viewCenter=null;state.zoom=6.0;draw();
    viewport.classList.add("department-mode");if(returnButton)returnButton.hidden=false;
    setTransitionText(d.title,d.subtitle);
    requestAnimationFrame(()=>{overlay.style.opacity="0";overlay.classList.remove("is-visible");});
    window.setTimeout(()=>{state.transitioning=false;},460);
    if(d.id==="central-bank"){
      const note=document.getElementById("city-sync-status");
      if(note)note.textContent="Cash Moneybags manages the virtual ledger. A real payout account is not connected.";
    }
  }
  async function exitBuilding(){
    if(state.transitioning||!state.insideBuilding)return;
    const d=districts.find(item=>item.id===state.insideBuilding);
    state.transitioning=true;
    const overlay=setTransitionText("Returning to the valley","Your departments are ready whenever you are");
    overlay.style.opacity="0";overlay.classList.remove("is-visible");
    requestAnimationFrame(()=>{overlay.style.opacity="1";overlay.classList.add("is-visible");});
    await new Promise(resolve=>setTimeout(resolve,430));
    state.insideBuilding=null;state.viewCenter=null;state.zoom=6.4;state.hoveredDistrict=null;draw();
    viewport.classList.remove("department-mode");
    hideDepartmentLivePanel();
    const returnButton=document.getElementById("city-return-town");if(returnButton)returnButton.hidden=true;
    setTransitionText("Welcome back","Choose another department to visit");
    requestAnimationFrame(()=>{overlay.style.opacity="0";overlay.classList.remove("is-visible");});
    window.setTimeout(()=>{state.transitioning=false;},460);
  }
  function makeModal(){let modal=document.getElementById("amt-world-modal");if(modal)return modal;
    modal=document.createElement("div");modal.id="amt-world-modal";modal.className="amt-world-modal";modal.hidden=true;
    modal.innerHTML=`<section class="amt-world-card"><header><div><small id="amt-world-kicker">TOWN INTERACTION</small><h2 id="amt-world-title">Employee</h2></div><button id="amt-world-close" aria-label="Close">×</button></header><div id="amt-world-content"></div></section>`;
    viewport.append(modal);modal.querySelector("#amt-world-close").addEventListener("click",()=>modal.hidden=true);return modal;
  }
  async function openEmployeeChat(employee){
    const modal=makeModal(),content=modal.querySelector("#amt-world-content"),title=modal.querySelector("#amt-world-title"),kicker=modal.querySelector("#amt-world-kicker");
    state.chat=employee;title.textContent=employee.name||employee.role;kicker.textContent=`${employee.role} · ${employee.status||"available"}`;
    content.innerHTML=`<div class="amt-employee-welcome"><div class="amt-employee-avatar">${escapeHtml((employee.name||"? ").split(/\s+/).map(part=>part[0]||"").slice(0,2).join(""))}</div><div><strong>Hey! I'm ${escapeHtml(employee.name||"your teammate")}.</strong><span>${escapeHtml(employee.role)} · ${escapeHtml(stationLabels[employee.id]||"Team workstation")}</span><small>Ask me what I'm doing, share an idea, or give me a new direction.</small></div></div><p class="amt-chat-task">${employee.current_task?.title?`Currently working on: ${escapeHtml(employee.current_task.title)}`:"I'm at my workstation and ready for a task."}</p><div class="amt-quick-prompts"><button type="button" data-quick="What are you working on right now?">What are you working on?</button><button type="button" data-quick="What's your best idea so far?">Your best idea</button><button type="button" data-quick="What do you need from me?">How can I help?</button></div><div class="amt-chat-log" id="amt-chat-log"><p class="amt-chat-muted">Loading conversation…</p></div><form id="amt-chat-form"><input id="amt-chat-input" maxlength="4000" placeholder="Talk to ${escapeHtml(employee.name||"your teammate")}…" autocomplete="off"><button type="submit">Send</button></form><p class="amt-chat-note" id="amt-chat-note">Local Ollama conversation · replies depend on the model running on this computer.</p>`;
    modal.hidden=false;
    const log=content.querySelector("#amt-chat-log");
    try{const response=await fetch(`/api/employees/${encodeURIComponent(employee.id)}/messages`);if(!response.ok)throw new Error(`HTTP ${response.status}`);const data=await response.json();log.replaceChildren();(data.messages||[]).forEach(m=>appendMessage(log,m.role,m.content));if(!data.messages?.length)log.innerHTML='<p class="amt-chat-muted">Start a conversation. Ask about their current work, findings or next steps.</p>';}
    catch(error){log.innerHTML=`<p class="amt-chat-muted">Could not load the saved conversation: ${escapeHtml(error.message)}</p>`;}
    content.querySelector("#amt-chat-form").addEventListener("submit",event=>{event.preventDefault();sendChat(employee,content);});
    content.querySelectorAll("[data-quick]").forEach(button=>button.addEventListener("click",()=>{const input=content.querySelector("#amt-chat-input");input.value=button.dataset.quick;content.querySelector("#amt-chat-form").requestSubmit();}));
    content.querySelector("#amt-chat-input").focus();
  }
  function escapeHtml(value){return String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));}
  function appendMessage(log,role,text){const item=document.createElement("div");item.className=`amt-chat-msg ${role==="user"?"user":"assistant"}`;const speaker=document.createElement("b");speaker.textContent=role==="user"?"YOU":"TEAMMATE";const p=document.createElement("p");p.textContent=text;item.append(speaker,p);log.append(item);log.scrollTop=log.scrollHeight;return p;}
  async function sendChat(employee,content){const input=content.querySelector("#amt-chat-input"),button=content.querySelector("button[type=submit]"),log=content.querySelector("#amt-chat-log"),note=content.querySelector("#amt-chat-note"),text=input.value.trim();if(!text)return;input.value="";input.disabled=true;button.disabled=true;appendMessage(log,"user",text);const reply=appendMessage(log,"assistant","Thinking…");note.textContent="Connecting to the local AI model…";
    try{const response=await fetch(`/api/employees/${encodeURIComponent(employee.id)}/messages/stream`,{method:"POST",headers:{"Content-Type":"application/json","Accept":"text/event-stream"},body:JSON.stringify({content:text})});if(!response.ok){const body=await response.json().catch(()=>({}));throw new Error(body.detail||`Chat service returned ${response.status}`);}if(!response.body)throw new Error("Streaming is not supported by this browser.");
      const reader=response.body.getReader(),decoder=new TextDecoder();let buffer="",got=false;
      while(true){const {value,done}=await reader.read();if(done)break;buffer+=decoder.decode(value,{stream:true});const blocks=buffer.split("\n\n");buffer=blocks.pop()||"";for(const block of blocks){const line=block.split("\n").find(row=>row.startsWith("data:"));if(!line)continue;const packet=JSON.parse(line.slice(5).trim());if(packet.type==="token"){if(!got){reply.textContent="";got=true;}reply.textContent+=packet.content||"";log.scrollTop=log.scrollHeight;}else if(packet.type==="meta")note.textContent=`Replying with ${packet.model||"local model"}…`;else if(packet.type==="error")throw new Error(packet.detail||"Local AI error");}}
      if(!got)throw new Error("The local model returned no text. Check that Ollama has a chat model installed and running.");note.textContent="Message saved to this employee's conversation.";
    }catch(error){reply.textContent=`I couldn't reply: ${error.message}`;reply.classList.add("error");note.textContent="Check Ollama is running and that a chat model is installed.";}
    finally{input.disabled=false;button.disabled=false;input.focus();}
  }
  function openBuilding(d){enterBuilding(d);}
  const interiorThemes = {
    ideas:{wall:"#59436f",trim:"#d9b77a",floor:"#b69b7b",light:"#f5cf82",label:"THE IDEA FORGE",props:"ideas"},
    library:{wall:"#38566a",trim:"#d8bd82",floor:"#a78c70",light:"#d7e8d4",label:"THE CLUE LIBRARY",props:"library"},
    hall:{wall:"#704a35",trim:"#f0d18a",floor:"#c3a47a",light:"#f4d890",label:"MAYOR'S WAR ROOM",props:"hall"},
    workshop:{wall:"#385d4d",trim:"#e1ba73",floor:"#a88a68",light:"#d5e6a5",label:"THE MAKER'S WORKSHOP",props:"workshop"},
    lounge:{wall:"#6b4650",trim:"#efc6a1",floor:"#c7a29a",light:"#ffe0c0",label:"CUSTOMER LOUNGE",props:"lounge"},
    studio:{wall:"#68445d",trim:"#f0c47d",floor:"#b99691",light:"#f5c6de",label:"THE CREATIVE STUDIO",props:"studio"},
    arcade:{wall:"#315d5b",trim:"#e9c67b",floor:"#b4a47d",light:"#c6eddd",label:"THE SALES ARCADE",props:"arcade"},
    bank:{wall:"#344f43",trim:"#edcf82",floor:"#b8aa8b",light:"#f4df9b",label:"THE TOWN TREASURY",props:"bank"},
    quality:{wall:"#3e4c69",trim:"#cad7ee",floor:"#a9b1bd",light:"#d7e1ff",label:"THE QUALITY LAB",props:"quality"},
    garden:{wall:"#456348",trim:"#e6d39a",floor:"#a6bb8c",light:"#e2efbd",label:"THE REST GARDEN",props:"garden"},
  };
  function rounded(x,y,w,h,r,fill,stroke=null,lw=1){ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=lw;ctx.stroke();}}
  function drawInteriorDesk(x,y,w,theme,kind="desk"){
    ctx.save();ctx.fillStyle="#18251f55";ctx.beginPath();ctx.ellipse(x,y+21,w*.57,12,0,0,Math.PI*2);ctx.fill();
    // table face and top are drawn with perspective so each staff member has a visible station.
    ctx.beginPath();ctx.moveTo(x-w*.52,y-5);ctx.lineTo(x+w*.52,y-5);ctx.lineTo(x+w*.43,y+16);ctx.lineTo(x-w*.43,y+16);ctx.closePath();ctx.fillStyle="#6f4b36";ctx.fill();
    ctx.beginPath();ctx.moveTo(x-w*.58,y-12);ctx.lineTo(x,y-22);ctx.lineTo(x+w*.58,y-12);ctx.lineTo(x,y-2);ctx.closePath();ctx.fillStyle=theme.trim;ctx.fill();ctx.strokeStyle="#ffffff55";ctx.stroke();
    if(kind==="bank"){rounded(x-16,y-28,32,18,3,"#e9dfbe","#80693e");ctx.fillStyle="#977c42";ctx.font="700 7px system-ui";ctx.textAlign="center";ctx.fillText("LEDGER",x,y-16);for(let i=0;i<4;i++){ctx.fillStyle=["#e9c86d","#d5a64f","#f2df94"][i%3];ctx.beginPath();ctx.arc(x+27+i*4,y-12,4,0,Math.PI*2);ctx.fill();}}
    else if(kind==="maker"){rounded(x-17,y-32,34,24,3,"#25483f","#e7d29b");ctx.fillStyle="#9fe0ba";ctx.fillRect(x-10,y-25,20,9);ctx.fillStyle="#e4c177";ctx.fillRect(x-4,y-13,8,4);}
    else if(kind==="research"){rounded(x-18,y-29,36,22,3,"#eee2c7","#805d3f");for(let i=0;i<3;i++){ctx.fillStyle=["#c46d59","#5a8c9e","#d9ad58"][i];ctx.fillRect(x-12+i*9,y-23,6,11);}}
    else if(kind==="creative"){rounded(x-18,y-30,36,23,3,"#f5e4d0","#8a5f64");ctx.fillStyle="#d77da0";ctx.fillRect(x-12,y-24,10,10);ctx.fillStyle="#7fb5b5";ctx.fillRect(x+2,y-24,10,10);}
    else if(kind==="mayor"){rounded(x-22,y-31,44,27,4,"#e8d9ad","#805d3f");ctx.fillStyle="#638b78";ctx.fillRect(x-17,y-26,34,17);ctx.strokeStyle="#e8cc82";ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x-13,y-21);ctx.lineTo(x+12,y-21);ctx.moveTo(x-8,y-15);ctx.lineTo(x+8,y-15);ctx.stroke();ctx.fillStyle="#c85b4e";ctx.fillRect(x+14,y-33,3,10);}
    else if(kind==="ideas"){rounded(x-20,y-31,40,26,4,"#74588c","#e7cb88");for(let i=0;i<4;i++){ctx.fillStyle=["#f5d77b","#a9d9c5","#efabb5","#b8c9ef"][i];ctx.save();ctx.translate(x-12+i*8,y-20+(i%2)*3);ctx.rotate(-.08+i*.05);ctx.fillRect(-3,-5,7,9);ctx.restore();}}
    else if(kind==="quality"){rounded(x-20,y-31,40,26,4,"#394e67","#cbd7e6");ctx.fillStyle="#a7d7c1";ctx.fillRect(x-14,y-25,28,13);ctx.strokeStyle="#f1d487";ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x-10,y-18);ctx.lineTo(x-4,y-13);ctx.lineTo(x+7,y-24);ctx.stroke();}
    else if(kind==="service"){rounded(x-20,y-30,40,24,5,"#6c5360","#f0c9ae");ctx.fillStyle="#f2d4b6";ctx.fillRect(x-13,y-24,26,11);ctx.fillStyle="#ca7890";ctx.beginPath();ctx.arc(x,y-18,4,0,Math.PI*2);ctx.fill();ctx.strokeStyle="#f0d7b6";ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,y-25,12,Math.PI,Math.PI*2);ctx.stroke();}
    else {rounded(x-13,y-28,26,17,3,"#edf0df","#8a7959");ctx.strokeStyle="#c6a86c";ctx.beginPath();ctx.moveTo(x-8,y-22);ctx.lineTo(x+8,y-22);ctx.moveTo(x-8,y-17);ctx.lineTo(x+5,y-17);ctx.stroke();}
    ctx.restore();
  }
  function drawInteriorAvatar(employee,x,y,index,theme,station){
    const t=state.worldTime, bob=Math.sin(t*2+index)*2;
    ctx.save();ctx.fillStyle="#14241f55";ctx.beginPath();ctx.ellipse(x,y+27,27,10,0,0,Math.PI*2);ctx.fill();
    // chair
    rounded(x-19,y-4,38,34,9,"#344f49","#d8c08a");
    // body / head / hair
    ctx.fillStyle=colors[index%colors.length];ctx.beginPath();ctx.roundRect(x-16,y-3+bob,32,31,10);ctx.fill();ctx.strokeStyle="#f4e5c7";ctx.lineWidth=1.5;ctx.stroke();
    ctx.fillStyle="#edc29d";ctx.beginPath();ctx.arc(x,y-20+bob,14,0,Math.PI*2);ctx.fill();
    ctx.fillStyle=["#40352f","#76513c","#302a33","#9a7046","#473f38","#5c382b","#3b302b","#845d45"][index%8];ctx.beginPath();ctx.arc(x,y-25+bob,14,Math.PI,Math.PI*2);ctx.fill();
    ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(x-4.5,y-20+bob,1.7,0,Math.PI*2);ctx.arc(x+4.5,y-20+bob,1.7,0,Math.PI*2);ctx.fill();
    // Small signature accessories make each teammate recognisable at a glance.
    if(index===0){ctx.fillStyle="#e9c66f";ctx.beginPath();ctx.moveTo(x-12,y-32+bob);ctx.lineTo(x-8,y-42+bob);ctx.lineTo(x-2,y-34+bob);ctx.lineTo(x+4,y-43+bob);ctx.lineTo(x+12,y-32+bob);ctx.closePath();ctx.fill();}
    else if(index===1){ctx.fillStyle="#9c704c";ctx.beginPath();ctx.ellipse(x,y-29+bob,15,5,0,Math.PI,Math.PI*2);ctx.fill();ctx.fillRect(x-12,y-30+bob,24,4);}
    else if(index===2){ctx.strokeStyle="#d8e6e5";ctx.lineWidth=2;ctx.beginPath();ctx.arc(x-5,y-20+bob,4,0,Math.PI*2);ctx.arc(x+5,y-20+bob,4,0,Math.PI*2);ctx.moveTo(x-1,y-20+bob);ctx.lineTo(x+1,y-20+bob);ctx.stroke();}
    else if(index===3){ctx.strokeStyle="#e2b966";ctx.lineWidth=3;ctx.beginPath();ctx.arc(x,y-26+bob,13,Math.PI,Math.PI*2);ctx.stroke();ctx.fillStyle="#e2b966";ctx.fillRect(x-10,y-29+bob,20,4);}
    else if(index===4){ctx.fillStyle="#bd6890";ctx.beginPath();ctx.arc(x+12,y-23+bob,4,0,Math.PI*2);ctx.fill();ctx.strokeStyle="#f1d6a6";ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x+12,y-19+bob);ctx.lineTo(x+17,y-12+bob);ctx.stroke();}
    else if(index===5){ctx.strokeStyle="#f1d477";ctx.lineWidth=2;ctx.beginPath();ctx.arc(x+8,y-20+bob,5,0,Math.PI*2);ctx.stroke();ctx.fillStyle="#e6c16e";ctx.fillRect(x-12,y-37+bob,24,5);}
    else if(index===6){ctx.strokeStyle="#e5e9ed";ctx.lineWidth=2;ctx.beginPath();ctx.arc(x+12,y-23+bob,5,0,Math.PI*2);ctx.moveTo(x+15,y-19+bob);ctx.lineTo(x+20,y-13+bob);ctx.stroke();}
    else {ctx.fillStyle="#b8e4df";ctx.beginPath();ctx.arc(x+13,y-12+bob,4,0,Math.PI*2);ctx.arc(x+19,y-17+bob,3,0,Math.PI*2);ctx.fill();}
    ctx.fillStyle="#243d33";ctx.font="700 9px system-ui";ctx.textAlign="center";ctx.fillText(employee.name||employee.role,x,y+43);
    ctx.fillStyle="#f8edcf";ctx.font="600 7px system-ui";ctx.fillText(station,x,y+55);
    const taskStatus=employee.current_task?.status;
    const busy=taskStatus==="in_progress";
    const queued=taskStatus==="pending";
    rounded(x-27,y-53,54,14,7,busy?"#245c43":queued?"#73562b":"#596a5f",null);
    ctx.fillStyle=busy?"#c9f3d2":queued?"#ffe3a0":"#e5eadc";ctx.font="700 6px system-ui";ctx.fillText(busy?"WORKING":queued?"TASK QUEUED":"ON STANDBY",x,y-43);
    ctx.restore();
    state.interiorTargets.push({employee,x,y:y-12,r:31});
  }
  function drawRoomDecor(d,theme){
    const w=width,h=height,kind=theme.props;
    // rear wall sconces, windows and banners create a proper room silhouette.
    for(const sx of [.16,.84]){rounded(w*sx-13,h*.2,26,58,10,"#263b35","#d8c18c",2);rounded(w*sx-8,h*.215,16,43,7,theme.light,"#f7e7bb",1);}
    rounded(w*.38,h*.105,w*.24,h*.09,8,"#1e332b","#e0c384",2);
    ctx.fillStyle="#f8e9c9";ctx.font="800 12px system-ui";ctx.textAlign="center";ctx.fillText(theme.label,w*.5,h*.16);
    if(kind==="bank"){
      // Large brass vault door and gold ledger counter.
      ctx.fillStyle="#243d32";ctx.beginPath();ctx.arc(w*.5,h*.36,Math.min(w,h)*.105,0,Math.PI*2);ctx.fill();ctx.strokeStyle="#d9b85f";ctx.lineWidth=8;ctx.stroke();ctx.strokeStyle="#f5e1a0";ctx.lineWidth=2;ctx.beginPath();ctx.arc(w*.5,h*.36,Math.min(w,h)*.075,0,Math.PI*2);ctx.stroke();
      ctx.beginPath();ctx.moveTo(w*.5,h*.29);ctx.lineTo(w*.5,h*.43);ctx.moveTo(w*.43,h*.36);ctx.lineTo(w*.57,h*.36);ctx.stroke();
      ctx.fillStyle="#f1ce69";for(let i=0;i<9;i++){ctx.beginPath();ctx.ellipse(w*.19+i*8,h*.52-(i%3)*3,7,3,0,0,Math.PI*2);ctx.fill();}
      rounded(w*.68,h*.27,w*.17,h*.18,8,"#6a5035","#e2c67e",2);ctx.fillStyle="#f8e5ad";ctx.font="700 8px system-ui";ctx.fillText("TOWN LEDGER",w*.765,h*.32);ctx.font="700 14px system-ui";ctx.fillText(money(state.treasury.available_business_funds_cents),w*.765,h*.38);
    }else if(kind==="library"){
      for(let j=0;j<2;j++){const x=w*(.25+j*.5);rounded(x-34,h*.25,68,110,5,"#563c2d","#d8bb83",2);for(let shelf=0;shelf<3;shelf++){ctx.fillStyle="#d9bf88";ctx.fillRect(x-29,h*.28+shelf*33,58,3);for(let b=0;b<6;b++){ctx.fillStyle=["#9b6253","#4f8390","#bc9659","#65866c"][b%4];ctx.fillRect(x-27+b*9,h*.255+shelf*33,7,23);}}}
      rounded(w*.43,h*.29,w*.14,h*.1,5,"#e6d3a9","#805b3a");ctx.fillStyle="#486c78";ctx.font="700 8px system-ui";ctx.fillText("TREND MAP",w*.5,h*.34);
    }else if(kind==="ideas"){
      rounded(w*.19,h*.24,w*.62,h*.23,8,"#947453","#dfc78c",3);ctx.fillStyle="#f2e5c9";ctx.font="800 10px system-ui";ctx.fillText("BIG IDEAS BOARD",w*.5,h*.275);
      const sticky=["#f4d77e","#9bd5c4","#f0a9b0","#a9c7ee","#d5b6ec","#f2c59b"];for(let i=0;i<6;i++){const x=w*.25+(i%3)*w*.17,y=h*.31+Math.floor(i/3)*h*.075;ctx.save();ctx.translate(x,y);ctx.rotate((i%2?-.04:.03));ctx.fillStyle=sticky[i];ctx.fillRect(-w*.035,-h*.023,w*.07,h*.046);ctx.fillStyle="#5e5545";ctx.fillRect(-w*.023,-h*.006,w*.046,2);ctx.restore();}
      ctx.strokeStyle="#e7c987";ctx.lineWidth=3;ctx.beginPath();ctx.arc(w*.5,h*.55,34,0,Math.PI*2);ctx.stroke();
    }else if(kind==="hall"){
      for(const x of [.28,.72]){rounded(w*x-20,h*.25,40,135,9,"#8c6340","#e9cc8a",2);ctx.fillStyle="#f5e3b3";ctx.fillRect(w*x-2,h*.25,4,135);}
      rounded(w*.35,h*.28,w*.3,h*.14,8,"#e8ddc0","#9d7c53",2);ctx.fillStyle="#597e71";ctx.font="800 9px system-ui";ctx.fillText("TOWN MAP & PLANS",w*.5,h*.34);
    }else if(kind==="workshop"){
      for(let i=0;i<3;i++){const x=w*(.25+i*.25);rounded(x-27,h*.27,54,70,7,"#314a40","#d8bd83",2);ctx.strokeStyle="#edcf84";ctx.lineWidth=3;ctx.beginPath();ctx.arc(x,h*.32,16,0,Math.PI*2);ctx.stroke();ctx.fillStyle="#a4e0c1";ctx.fillRect(x-10,h*.37,20,4);}
      rounded(w*.39,h*.44,w*.22,h*.055,5,"#c69a61","#805738",2);
    }else if(kind==="studio"){
      rounded(w*.18,h*.25,w*.64,h*.22,8,"#f2e0cb","#d2b77e",3);const posters=["#d77b94","#6d9db3","#d6ad57","#8c82b9"];for(let i=0;i<4;i++){ctx.fillStyle=posters[i];ctx.fillRect(w*.22+i*w*.145,h*.29,w*.1,h*.13);ctx.fillStyle="#fff0d5";ctx.fillRect(w*.23+i*w*.145,h*.305,w*.08,4);ctx.fillRect(w*.23+i*w*.145,h*.32,w*.055,3);}
      ctx.strokeStyle="#e6d6b6";ctx.lineWidth=5;ctx.beginPath();ctx.arc(w*.78,h*.48,22,0,Math.PI*2);ctx.stroke();ctx.fillStyle="#283b34";ctx.beginPath();ctx.arc(w*.78,h*.48,9,0,Math.PI*2);ctx.fill();
    }else if(kind==="lounge"){
      rounded(w*.22,h*.31,w*.2,h*.13,15,"#bb7880","#f0d3b4",2);rounded(w*.58,h*.31,w*.2,h*.13,15,"#bb7880","#f0d3b4",2);rounded(w*.42,h*.36,w*.16,h*.1,12,"#e2b77c","#fff0d8",2);ctx.fillStyle="#f8e4c6";ctx.font="700 9px system-ui";ctx.fillText("LISTEN · HELP · IMPROVE",w*.5,h*.51);
    }else if(kind==="arcade"){
      for(let i=0;i<4;i++){const x=w*(.22+i*.18);rounded(x-27,h*.28,54,105,5,"#f0e5c8","#b08a56",2);for(let j=0;j<3;j++){ctx.fillStyle=["#d87868","#6da3a0","#d5b85d"][j];ctx.fillRect(x-18,h*.32+j*26,36,17);}}
    }else if(kind==="quality"){
      rounded(w*.22,h*.26,w*.56,h*.18,7,"#dfe7ee","#b6c8db",2);ctx.strokeStyle="#63809b";ctx.lineWidth=2;for(let i=0;i<4;i++){ctx.beginPath();ctx.moveTo(w*.27+i*w*.14,h*.39);ctx.lineTo(w*.31+i*w*.14,h*.31);ctx.lineTo(w*.35+i*w*.14,h*.39);ctx.stroke();}
      ctx.fillStyle="#e8d28c";ctx.beginPath();ctx.arc(w*.5,h*.5,18,0,Math.PI*2);ctx.fill();ctx.strokeStyle="#5c6d7e";ctx.lineWidth=4;ctx.beginPath();ctx.arc(w*.5,h*.5,12,0,Math.PI*2);ctx.stroke();
    }else if(kind==="garden"){
      for(let i=0;i<7;i++){const x=w*.2+i*w*.1;ctx.fillStyle="#4b8c59";ctx.beginPath();ctx.ellipse(x,h*.39,13,24,0,0,Math.PI*2);ctx.fill();ctx.fillStyle="#b9d99b";ctx.beginPath();ctx.arc(x-4,h*.34,5,0,Math.PI*2);ctx.fill();}
    }
  }
  function departmentPanelData(d, staff){
    const tasks = staff.map(e=>e.current_task).filter(Boolean);
    const activeTasks = tasks.filter(t=>["pending","in_progress"].includes(t.status)).length;
    const completedTasks = tasks.filter(t=>t.status==="completed").length;
    const businesses = state.businesses || [];
    const ideaStats = state.ideaStats || {target_per_hour:50,created_last_hour:0};
    const recentIdeas = (state.ideas || []).slice(0,5);
    const evaluatingIdeas = (state.ideas || []).filter(i=>i.status==="evaluating").length;
    const moneyRows = [
      ["Available funds", money(state.treasury.available_business_funds_cents)],
      ["Verified revenue", money(state.treasury.actual_revenue_cents)],
      ["Pending receipts", money(state.treasury.pending_payments_cents)],
      ["Verified expenses", money(state.treasury.expenses_cents)],
    ];
    let metrics=[];let listTitle="CURRENT WORK";let list=[];
    if(d.id==="central-bank") {
      metrics=moneyRows;listTitle="BANKER'S DESK";list=[
        "Cash Moneybags · Treasurer",
        "All balances shown are ledger records",
        "No card or payout account is connected",
        `Daily spending cap: ${money(state.treasury.daily_spending_limit_cents)}`
      ];
    } else if(d.id==="innovation") {
      metrics=[["Ideas this hour",`${ideaStats.created_last_hour||0} / ${ideaStats.target_per_hour||50}`],["Awaiting review",String(evaluatingIdeas)],["Total idea bank",String(ideaStats.total_count ?? state.ideas?.length ?? 0)]];
      listTitle="LATEST IDEAS";list=recentIdeas.map(i=>`${i.title} · ${String(i.status||"new").replaceAll("_"," ")}`);
    } else if(d.id==="research-lab") {
      metrics=[["Ideas under evaluation",String(evaluatingIdeas)],["Research tasks active",String(activeTasks)],["Completed team tasks",String(completedTasks)]];
      listTitle="RESEARCH QUEUE";list=tasks.map(t=>t.title).slice(0,5);
      if(!list.length)list=recentIdeas.slice(0,4).map(i=>i.title);
    } else if(d.id==="product-hq") {
      metrics=[["Products in development",String(businesses.filter(b=>b.stage==="development").length)],["Ready for testing",String(businesses.filter(b=>b.stage==="simulation").length)],["Current tasks",String(activeTasks)]];
      listTitle="BUILD QUEUE";list=tasks.map(t=>t.title).slice(0,5);
    } else if(d.id==="marketing") {
      metrics=[["Launch-ready projects",String(businesses.filter(b=>b.stage==="ready_for_approval").length)],["Growing businesses",String(businesses.filter(b=>["growing","live_business"].includes(b.stage)).length)],["Draft tasks",String(activeTasks)]];
      listTitle="CAMPAIGN WORK";list=tasks.map(t=>t.title).slice(0,5);
    } else if(d.id==="sales") {
      metrics=[["Approved projects",String(businesses.filter(b=>b.stage==="ready_for_approval").length)],["Live projects",String(businesses.filter(b=>["live_business","growing","stable"].includes(b.stage)).length)],["Owner approval required","Yes"]];
      listTitle="SALES READINESS";list=businesses.slice(0,5).map(b=>b.title);
    } else if(d.id==="quality-assurance") {
      metrics=[["Projects in testing",String(businesses.filter(b=>b.stage==="simulation").length)],["Declining projects",String(businesses.filter(b=>b.stage==="declining").length)],["Team tasks",String(activeTasks)]];
      listTitle="QUALITY CHECKS";list=tasks.map(t=>t.title).slice(0,5);
    } else if(d.id==="town-hall") {
      metrics=[["Active tasks",String(state.taskSummary?.active||0)],["Businesses",String(businesses.length)],["Ideas this hour",String(ideaStats.created_last_hour||0)]];
      listTitle="MAYOR'S PRIORITIES";list=tasks.map(t=>t.title).slice(0,5);
    } else if(d.id==="customer-centre") {
      metrics=[["Customer feedback items",String(businesses.filter(b=>b.customer_feedback).length)],["Businesses monitored",String(businesses.length)],["Support tasks",String(activeTasks)]];
      listTitle="CUSTOMER CARE";list=tasks.map(t=>t.title).slice(0,5);
    } else {
      const avgMorale=staff.length?Math.round(staff.reduce((sum,e)=>sum+Number(e.morale||70),0)/staff.length):0;
      metrics=[["Team morale",`${avgMorale}/100`],["Tasks completed",String(completedTasks)],["Breaks & rewards","Available"]];
      listTitle="TEAM STATUS";list=staff.map(e=>`${e.name}: ${e.status||"available"}`);
    }
    return {metrics,listTitle,list,activeTasks,completedTasks};
  }
  function ensureDepartmentLivePanel(){
    let panel=document.getElementById("amt-department-live-panel");
    if(panel)return panel;
    panel=document.createElement("aside");panel.id="amt-department-live-panel";panel.className="amt-department-live-panel";panel.hidden=true;
    viewport.append(panel);return panel;
  }
  function updateDepartmentLivePanel(d,staff){
    const panel=ensureDepartmentLivePanel();
    const info=departmentPanelData(d,staff);
    const esc=escapeHtml;
    const metricHtml=info.metrics.map(([label,value])=>`<div class="amt-live-metric"><span>${esc(label)}</span><strong>${esc(value)}</strong></div>`).join("");
    const teamHtml=staff.map(employee=>{
      const status=employee.current_task?.status||employee.status||"available";
      const statusLabel=status==="in_progress"?"WORKING":status==="pending"?"QUEUED":status.replaceAll("_"," ").toUpperCase();
      const work=employee.current_task?.title||employee.current_assignment?.project||employee.specialty||"Ready for an assignment";
      return `<div class="amt-live-teammate"><div class="amt-live-teammate-top"><strong>${esc(employee.name||employee.role)}</strong><span class="amt-live-status ${status==="in_progress"?"working":""}">${esc(statusLabel)}</span></div><small>${esc(employee.role||"Team member")}</small><p>${esc(work)}</p><button type="button" data-live-chat="${esc(employee.id)}">Talk to ${esc(employee.name||"teammate")}</button></div>`;
    }).join("");
    const listHtml=info.list.length?info.list.slice(0,5).map(item=>`<li>${esc(item)}</li>`).join(""):'<li class="muted">Nothing recorded yet. Work will appear here as the team progresses.</li>';
    const signature=JSON.stringify([d.id,info.metrics,info.list,staff.map(e=>[e.id,e.name,e.status,e.current_task?.title,e.current_task?.status])]);
    if(panel.dataset.signature!==signature){
      panel.innerHTML=`<div class="amt-live-panel-head"><div><span>LIVE DEPARTMENT BOARD</span><h3>${esc(d.title)}</h3><p>${esc(d.subtitle||"")}</p></div><span class="amt-live-pulse"></span></div><div class="amt-live-metrics">${metricHtml}</div><section class="amt-live-section"><h4>${esc(info.listTitle)}</h4><ul>${listHtml}</ul></section><section class="amt-live-section"><h4>PEOPLE AT WORK</h4><div class="amt-live-team">${teamHtml||'<p class="muted">No employees assigned to this department yet.</p>'}</div></section><p class="amt-live-footnote">Live town data · refreshes automatically · simulated demand is not sales</p>`;
      panel.dataset.signature=signature;
      panel.querySelectorAll("[data-live-chat]").forEach(button=>button.addEventListener("click",()=>{const employee=state.employees.find(e=>e.id===button.dataset.liveChat);if(employee)void openEmployeeChat(employee);}));
    }
    panel.hidden=false;
  }
  function hideDepartmentLivePanel(){const panel=document.getElementById("amt-department-live-panel");if(panel)panel.hidden=true;}

  function drawInterior(d){
    const theme=interiorThemes[d.interior]||interiorThemes.hall,w=width,h=height;
    const bg=ctx.createLinearGradient(0,0,0,h);bg.addColorStop(0,"#172d2d");bg.addColorStop(.58,"#304c43");bg.addColorStop(1,"#162a22");ctx.fillStyle=bg;ctx.fillRect(0,0,w,h);
    // A perspective room with a visible floor, side walls, rafters and warm light.
    ctx.beginPath();ctx.moveTo(w*.06,h*.12);ctx.lineTo(w*.94,h*.12);ctx.lineTo(w*.86,h*.67);ctx.lineTo(w*.14,h*.67);ctx.closePath();ctx.fillStyle=theme.wall;ctx.fill();ctx.strokeStyle=theme.trim;ctx.lineWidth=5;ctx.stroke();
    ctx.beginPath();ctx.moveTo(w*.14,h*.67);ctx.lineTo(w*.86,h*.67);ctx.lineTo(w*.99,h*.99);ctx.lineTo(w*.01,h*.99);ctx.closePath();ctx.fillStyle=theme.floor;ctx.fill();ctx.strokeStyle="#ffffff45";ctx.lineWidth=2;ctx.stroke();
    for(let i=0;i<8;i++){const x=w*.13+i*w*.105;ctx.strokeStyle="#fff8e022";ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x,h*.68);ctx.lineTo(w*.5+(x-w*.5)*1.32,h*.98);ctx.stroke();}
    for(const x of [w*.14,w*.86]){ctx.fillStyle="#1c332b";ctx.fillRect(x-7,h*.12,14,h*.55);ctx.fillStyle=theme.trim;ctx.fillRect(x-10,h*.12,20,6);}
    drawRoomDecor(d,theme);
    const staff=state.employees.filter(e=>(roleDistrict[e.id]||"")===d.id);
    updateDepartmentLivePanel(d,staff);
    state.interiorTargets=[];
    const positions=staff.length===1?[w*.5]:staff.map((_,i)=>w*(.34+(i/(Math.max(1,staff.length-1)))*.32));
    staff.forEach((employee,index)=>{
      const x=positions[index],y=h*.69+Math.floor(index/3)*h*.04;
      drawInteriorDesk(x,y,w*.13,theme,stationKinds[employee.id]||"desk");
      drawInteriorAvatar(employee,x,y-31,Math.max(0,state.employees.findIndex(person=>person.id===employee.id)),theme,stationLabels[employee.id]||"Workstation");
    });
    if(!staff.length){rounded(w*.28,h*.68,w*.44,55,10,"#1b342b","#d7c087",2);ctx.fillStyle="#f7e9cb";ctx.font="700 12px system-ui";ctx.textAlign="center";ctx.fillText("A quiet room for future teammates",w*.5,h*.73);}
    // Title ribbon, subtitle and honest status.
    rounded(18,16,Math.min(w-36,480),58,12,"#14291fdc","#ffffff35",1);ctx.fillStyle="#e6cd90";ctx.font="800 9px system-ui";ctx.textAlign="left";ctx.fillText(theme.label,34,34);ctx.fillStyle="#fff8e7";ctx.font="700 15px system-ui";ctx.fillText(d.title,34,55);ctx.fillStyle="#d5e1d6";ctx.font="10px system-ui";ctx.fillText(d.subtitle||"Department workspace",34,67);
    if(d.id==="central-bank"){
      rounded(w*.2,h*.87,w*.6,34,9,"#1c382c","#e4ca82",1);ctx.fillStyle="#f9e7b5";ctx.font="700 10px system-ui";ctx.fillText(`LEDGER BALANCE  ${money(state.treasury.available_business_funds_cents)}`,w*.5,h*.892);
      ctx.fillStyle="#f4dca1";ctx.font="9px system-ui";ctx.fillText("Virtual ledger only · no card or payout account is connected",w*.5,h*.925);
      rounded(w*.5-78,h*.945,156,27,8,"#e4c77b","#fff1c2",1);ctx.fillStyle="#263b2e";ctx.font="800 9px system-ui";ctx.fillText("OPEN TREASURY LEDGER",w*.5,h*.962);
    }else{
      ctx.fillStyle="#f6e9c9";ctx.font="9px system-ui";ctx.textAlign="center";ctx.fillText("Click a teammate at their custom workstation to start a conversation",w*.5,h*.94);
    }
    const status=document.getElementById("city-render-status");if(status){status.textContent=`Inside ${d.title} · ${staff.length} teammate${staff.length===1?"":"s"} at work`;status.dataset.state="ready";}
    const loc=document.getElementById("city-location-name");if(loc)loc.textContent=`AI Money Town · ${d.title}`;
  }
  function doInteraction(){
    if(state.insideBuilding){const staff=state.employees.filter(e=>(roleDistrict[e.id]||"")===state.insideBuilding);if(staff[0])void openEmployeeChat(staff[0]);}
  }
  // Keyboard navigation is intentionally removed. The world is a clickable department hub.
  // Escape remains as a familiar way to return from a room; no WASD movement is registered.
  window.addEventListener("keydown",event=>{
    const target=event.target;if(target?.closest?.("input,textarea,select,[contenteditable=true]"))return;
    // Prevent the hidden legacy Three.js canvas from still receiving old movement keys.
    if(["KeyW","KeyA","KeyS","KeyD","ArrowUp","ArrowDown","ArrowLeft","ArrowRight","ShiftLeft","ShiftRight","KeyF","KeyE"].includes(event.code)){
      if(!document.getElementById("city-screen")?.hidden){event.preventDefault();event.stopImmediatePropagation();}
      return;
    }
    if(event.code!=="Escape"||state.transitioning)return;
    const modal=document.getElementById("amt-world-modal");
    if(modal&&!modal.hidden){modal.hidden=true;return;}
    if(state.insideBuilding)void exitBuilding();
  },true);
  canvas.addEventListener("pointermove",event=>{
    const rect=canvas.getBoundingClientRect(),mx=event.clientX-rect.left,my=event.clientY-rect.top;
    let hover=null;
    if(!state.insideBuilding&&!state.transitioning){const d=hitDistrict(mx,my);hover=d?.id||null;}
    else if(state.insideBuilding&&!state.transitioning){const employeeTarget=state.interiorTargets.find(item=>Math.hypot(item.x-mx,item.y-my)<item.r);hover=employeeTarget?`employee:${employeeTarget.employee.id}`:null;}
    if(hover!==state.hoveredDistrict){state.hoveredDistrict=hover;canvas.style.cursor=hover?"pointer":"default";draw();}
  });
  canvas.addEventListener("pointerup",event=>{
    if(state.transitioning)return;
    const rect=canvas.getBoundingClientRect(),mx=event.clientX-rect.left,my=event.clientY-rect.top;
    if(state.insideBuilding){
      const target=state.interiorTargets.find(item=>Math.hypot(item.x-mx,item.y-my)<item.r);
      if(target){const employee=state.employees.find(e=>e.id===target.employee.id);if(employee)void openEmployeeChat(employee);return;}
      if(state.insideBuilding==="central-bank"&&my>height*.93&&mx>width*.35&&mx<width*.65){document.querySelector('[data-screen="dashboard"]')?.click();setTimeout(()=>document.getElementById("treasury")?.scrollIntoView({behavior:"smooth"}),220);}
      return;
    }
    const district=hitDistrict(mx,my);if(district)void enterBuilding(district);
  });
  const returnButton=document.getElementById("city-return-town");
  returnButton?.addEventListener("click",()=>void exitBuilding());
  document.getElementById("city-recenter")?.addEventListener("click",()=>{
    if(state.insideBuilding)void exitBuilding();
    else{state.viewCenter=null;state.zoom=6.4;state.hoveredDistrict=null;draw();}
  });
  document.getElementById("city-zoom-in")?.addEventListener("click",()=>{if(!state.insideBuilding){state.zoom=Math.min(10,state.zoom+0.65);draw();}});
  document.getElementById("city-zoom-out")?.addEventListener("click",()=>{if(!state.insideBuilding){state.zoom=Math.max(3.8,state.zoom-0.65);draw();}});
  canvas.addEventListener("wheel",event=>{if(state.insideBuilding)return;event.preventDefault();state.zoom=Math.max(3.8,Math.min(10,state.zoom+(event.deltaY<0?0.35:-0.35)));draw();},{passive:false});
  async function sync(){try{const response=await fetch("/api/city/state",{cache:"no-store"});if(!response.ok)throw new Error(String(response.status));const data=await response.json();state.employees=data.employees||[];state.tasks=data.tasks||{};state.businesses=data.businesses||[];state.treasury=data.treasury||{};state.ideas=data.ideas||[];state.ideaStats=data.idea_stats||{target_per_hour:50,created_last_hour:0};state.taskSummary=data.task_summary||{};draw();}catch(error){const status=document.getElementById("city-sync-status");if(status)status.textContent=`Town data offline · ${error.message}`;}}
  function disableBrokenWebGL(){const original=viewport.querySelector('canvas[aria-label^="AI Money Town 3D world"]');if(original){original.style.visibility="hidden";original.setAttribute("aria-hidden","true");}
    const refs=window.__AMT_TOWN_DEBUG_REFS?.();if(refs?.renderer){try{refs.renderer.render=()=>{};}catch{}}
    viewport.dataset.renderer="isometric-fallback";
  }
  window.__AMT_PLAYABLE_TOWN={renderer:"cinematic clickable isometric department hub",getState:()=>({insideBuilding:state.insideBuilding,employees:state.employees.length,transitioning:state.transitioning}),recenter:()=>{if(state.insideBuilding)void exitBuilding();else{state.viewCenter=null;state.zoom=6.4;draw();}},enterBuilding:(id)=>{const d=districts.find(item=>item.id===id);if(d)void enterBuilding(d);},exitBuilding:()=>void exitBuilding(),openEmployee:(id)=>{const employee=state.employees.find(item=>item.id===id);if(employee)void openEmployeeChat(employee);},getDepartments:()=>districts.map(d=>({id:d.id,title:d.title,staff:state.employees.filter(e=>(roleDistrict[e.id]||"")===d.id).map(e=>e.name)}))};
  // Wait briefly for the module's WebGL canvas, then cover it with the guaranteed visible renderer.
  let attempts=0;const settle=()=>{disableBrokenWebGL();attempts++;if(attempts<12&&!viewport.querySelector('canvas[aria-label^="AI Money Town 3D world"]'))setTimeout(settle,150);};settle();
  if(typeof ResizeObserver!=="undefined")new ResizeObserver(resize).observe(viewport);else window.addEventListener("resize",resize);
  resize();void sync();setInterval(sync,6000);requestAnimationFrame(frame);
})();
