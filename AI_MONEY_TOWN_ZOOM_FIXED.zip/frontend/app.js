const $ = (selector) => document.querySelector(selector);
const elements = {
  stats: $("#town-stats"),
  employees: $("#employee-list"),
  employeeCount: $("#employee-count"),
  taskCount: $("#task-count"),
  tasks: $("#task-list"),
  ideas: $("#idea-list"),
  ideaCount: $("#idea-count"),
  activity: $("#activity-list"),
  ollama: $("#ollama-status"),
  taskEmployee: $("#task-employee"),
  chatTitle: $("#chat-title"),
  chatMessages: $("#chat-messages"),
  chatInput: $("#chat-input"),
  chatForm: $("#chat-form"),
  toast: $("#toast"),
  businesses: $("#business-list"),
  revivalList: $("#revival-list"),
  revivalCount: $("#revival-count"),
  financeSummary: $("#finance-summary"),
  ledger: $("#ledger-list"),
  reports: $("#report-list"),
  employeeDialog: $("#employee-dialog"),
  employeeDialogTitle: $("#employee-dialog-title"),
  employeeDialogContent: $("#employee-dialog-content"),
  businessDialog: $("#business-dialog"),
  businessDialogTitle: $("#business-dialog-title"),
  businessDialogContent: $("#business-dialog-content"),
};
let selectedEmployee = null;
let refreshTimer;
let dashboardData = null;
let empireData = null;
let financialTransactions = [];
let managementReports = [];
const cityScreen = $("#city-screen");
const dashboardScreen = $("#overview");
const stageTransitions = {
  research: ["development", "temporarily_dormant", "archived"],
  development: ["research", "simulation", "temporarily_dormant", "archived"],
  simulation: ["development", "ready_for_approval", "temporarily_dormant", "archived"],
  ready_for_approval: ["simulation", "live_business", "temporarily_dormant", "archived"],
  live_business: ["growing", "stable", "declining", "temporarily_dormant"],
  growing: ["live_business", "stable", "declining", "temporarily_dormant"],
  stable: ["growing", "declining", "temporarily_dormant"],
  declining: ["revival", "temporarily_dormant", "archived", "growing", "stable"],
  revival: ["research", "development", "simulation", "live_business", "declining", "temporarily_dormant", "archived"],
  temporarily_dormant: ["revival", "archived"],
  archived: ["revival"],
};
const revivalTransitions = {
  investigating: ["solution_planning", "paused"],
  solution_planning: ["development", "paused"],
  development: ["simulation", "paused"],
  simulation: ["experiment_recommended", "paused"],
  experiment_recommended: ["resolved", "paused"],
  paused: ["investigating"],
  resolved: [],
};

function node(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

function initials(name) {
  return name.split(/\s+/).map((part) => part[0]).join("").slice(0, 2).toUpperCase();
}

function showToast(message) {
  elements.toast.textContent = message;
  elements.toast.classList.add("visible");
  clearTimeout(refreshTimer);
  refreshTimer = setTimeout(() => elements.toast.classList.remove("visible"), 2800);
}

async function api(path, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  const ownerToken = $("#owner-token")?.value || sessionStorage.getItem("ai-money-town-owner-token");
  if (ownerToken) headers["X-Owner-Token"] = ownerToken;
  const response = await fetch(path, {
    ...options,
    headers,
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.detail || `Request failed (${response.status})`);
  return payload;
}

function dollars(cents) {
  return new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format((cents || 0) / 100);
}

function centsFromInput(value) {
  const amount = Number(value);
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("Enter an amount greater than zero.");
  return Math.round(amount * 100);
}

function titleCase(value) {
  return value.replaceAll("_", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function renderStats(town) {
  const stats = [
    ["Town Employees", town.employee_count, "Distinct AI roles", "♙", "green"],
    ["Queued / Running", town.active_task_count, "Pending + in progress; not all started", "▤", "lavender"],
    ["Completed Tasks", town.completed_task_count, "Simulation work", "✓", "amber"],
    ["Business Ideas", town.idea_count, "Saved for exploration", "✳", "blue"],
  ];
  elements.stats.replaceChildren(...stats.map(([label, value, meta, icon, color]) => {
    const card = node("div", "stat-card");
    const info = node("div");
    info.append(node("span", "stat-label", label), node("strong", "stat-value", value), node("div", "stat-meta", meta));
    card.append(info, node("span", `stat-icon ${color}`, icon));
    return card;
  }));
}

function renderEmployees(employees) {
  elements.employeeCount.textContent = `${employees.length} TEAM MEMBERS`;
  elements.taskEmployee.replaceChildren();
  elements.employees.replaceChildren();
  for (const employee of employees) {
    const option = node("option", "", `${employee.name} · ${employee.role}`);
    option.value = employee.id;
    elements.taskEmployee.append(option);

    const card = node("div", "employee-card");
    card.append(node("span", "employee-avatar", initials(employee.name)));
    const info = node("div", "employee-info");
    info.append(node("strong", "", employee.name), node("small", "", employee.role));
    const state = (employee.status || "available").replaceAll("_", " ");
    const stateLine = node("small", `employee-state ${employee.status === "working" ? "is-working" : "is-available"}`, state === "working" ? "Working on a task" : "Waiting for assignment");
    info.append(stateLine);
    card.append(info);
    const chat = node("button", "chat-button", selectedEmployee === employee.id ? "Selected" : "Chat");
    chat.type = "button";
    chat.addEventListener("click", () => selectEmployee(employee));
    card.append(chat);
    const profile = node("button", "chat-button profile-button", "Profile");
    profile.type = "button";
    profile.addEventListener("click", () => openEmployeeProfile(employee));
    card.append(profile);
    elements.employees.append(card);
  }
}

function renderTasks(tasks) {
  const activeCount = tasks.filter((task) => task.status !== "completed").length;
  const runningCount = tasks.filter((task) => task.status === "in_progress").length;
  const queuedCount = tasks.filter((task) => task.status === "pending").length;
  elements.taskCount.textContent = `${runningCount} running · ${queuedCount} queued · ${tasks.length} total`;
  if (!tasks.length) {
    elements.tasks.replaceChildren(node("p", "empty-list", "No tasks yet. Assign the first one above."));
    return;
  }
  elements.tasks.replaceChildren(...tasks.map((task) => {
    const item = node("article", "task-item");
    const top = node("div", "task-top");
    top.append(node("strong", "task-title", task.title), node("span", "idea-status", task.status.replace("_", " ")));
    item.append(top);
    if (task.description) item.append(node("p", "task-desc", task.description));
    const footer = node("div", "task-footer");
    footer.append(node("span", "task-owner", `Assigned to ${task.employee_name}`));
    const select = node("select", "status-select");
    select.setAttribute("aria-label", `Update status for ${task.title}`);
    for (const [value, label] of [["pending", "Pending"], ["in_progress", "In progress"], ["completed", "Completed"]]) {
      const option = node("option", "", label);
      option.value = value;
      option.selected = task.status === value;
      select.append(option);
    }
    select.addEventListener("change", async () => {
      try {
        await api(`/api/tasks/${task.id}`, { method: "PATCH", body: JSON.stringify({ status: select.value }) });
        await loadDashboard();
        showToast("Task status saved.");
      } catch (error) {
        showToast(error.message);
        await loadDashboard();
      }
    });
    footer.append(select);
    item.append(footer);
    return item;
  }));
}

function renderIdeas(ideas) {
  elements.ideaCount.textContent = `${ideas.length} saved`;
  if (!ideas.length) {
    elements.ideas.replaceChildren(node("p", "empty-list", "Your ideas will be saved here."));
    return;
  }
  elements.ideas.replaceChildren(...ideas.map((idea) => {
    const item = node("article", "idea-item");
    const top = node("div", "task-top");
    top.append(node("strong", "idea-title", idea.title));
    const select = node("select", "status-select");
    select.setAttribute("aria-label", `Update idea status for ${idea.title}`);
    for (const [value, label] of [["proposed", "Proposed"], ["evaluating", "Evaluating"], ["approved", "Approve business"], ["archived", "Archived"]]) {
      const option = node("option", "", label);
      option.value = value;
      option.selected = idea.status === value;
      select.append(option);
    }
    select.addEventListener("change", async () => {
      try {
        await api(`/api/ideas/${idea.id}`, {
          method: "PATCH",
          body: JSON.stringify({ status: select.value }),
        });
        await loadDashboard();
        showToast(select.value === "approved" ? "Idea approved and moved into Research." : "Idea status saved.");
      } catch (error) {
        showToast(error.message);
        await loadDashboard();
      }
    });
    top.append(select);
    item.append(top);
    if (idea.description) item.append(node("p", "idea-desc", idea.description));
    return item;
  }));
}

function timeAgo(value) {
  const seconds = Math.max(0, Math.floor((Date.now() - new Date(value).getTime()) / 1000));
  if (seconds < 60) return "Just now";
  if (seconds < 3600) return `${Math.floor(seconds / 60)} min ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)} hr ago`;
  return new Date(value).toLocaleDateString();
}

function renderActivity(activity) {
  if (!activity.length) {
    elements.activity.replaceChildren(node("p", "empty-list", "Town activity will appear here."));
    return;
  }
  elements.activity.replaceChildren(...activity.map((entry) => {
    const row = node("div", "activity-row");
    const content = node("div");
    content.append(node("div", "activity-message", entry.message), node("time", "activity-time", timeAgo(entry.created_at)));
    row.append(node("span", "activity-bullet"), content);
    return row;
  }));
}

function renderOllama(status) {
  elements.ollama.className = `ollama-status ${status.connected ? "connected" : "error"}`;
  const message = status.connected
    ? `Ollama connected${status.models.length ? ` · ${status.models.length} model${status.models.length === 1 ? "" : "s"}` : " · no models pulled"}`
    : "Ollama offline · local chat unavailable";
  elements.ollama.replaceChildren(node("span", "status-dot"), node("span", "", message));
  $("#chat-note").textContent = status.connected
    ? "Conversations use your local Ollama model and are saved on this device."
    : status.error || "Start Ollama locally to enable employee conversations.";
}

function statusChip(value) {
  const chip = node("span", "stage-chip", titleCase(value));
  chip.dataset.stage = value;
  return chip;
}

function renderEmpire(data) {
  empireData = data;
  const businesses = data.businesses;
  const businessSelects = document.querySelectorAll(".business-select");
  for (const select of businessSelects) {
    const allowEmpty = select.querySelector('option[value=""]') !== null;
    const emptyOption = allowEmpty ? select.querySelector('option[value=""]').cloneNode(true) : null;
    select.replaceChildren();
    if (emptyOption) select.append(emptyOption);
    for (const business of businesses) {
      const option = node("option", "", business.title);
      option.value = business.id;
      select.append(option);
    }
    select.disabled = businesses.length === 0;
  }
  if (!businesses.length) {
    elements.businesses.replaceChildren(node("p", "empty-list", "The team is incubating promising ideas automatically. Internal research, MVP blueprints and synthetic testing run before any real-world launch approval."));
  } else {
    elements.businesses.replaceChildren(...businesses.map(renderBusinessCard));
  }
  renderRevivalMissions(data.revival_missions);
  renderFinanceSummary(data.finance);
  renderLedger(financialTransactions, data.finance);
  renderReports(managementReports);
}

function renderBusinessCard(business) {
  const card = node("article", "business-card");
  const header = node("div", "business-card-header");
  const identity = node("div");
  identity.append(node("h3", "", business.title), statusChip(business.stage));
  header.append(identity);
  const detail = node("button", "button button-outline", "History & performance");
  detail.type = "button";
  detail.addEventListener("click", () => openBusinessDetail(business.id));
  header.append(detail);
  card.append(header);

  const metrics = node("div", "business-metric-grid");
  const metricsToShow = [
    ["Actual settled sales", dollars(business.actual_sales_cents), "evidence-referenced"],
    ["Verified profit", dollars(business.verified_profit_cents), "settled ledger only"],
    ["Pending payments", dollars(business.pending_payment_cents), "not actual revenue"],
    ["Estimated revenue", dollars(business.estimated_revenue_cents), "simulation only"],
    ["Retention", business.retention_pct == null ? "—" : `${business.retention_pct.toFixed(1)}%`, "simulated"],
    ["Customer satisfaction", business.satisfaction_pct == null ? "—" : `${business.satisfaction_pct.toFixed(1)}%`, "simulated"],
    ["Growth trend", business.growth_pct == null ? "—" : `${business.growth_pct.toFixed(1)}%`, "simulated"],
  ];
  for (const [label, value, note] of metricsToShow) {
    const metric = node("div", "business-metric");
    metric.append(node("span", "stat-label", label), node("strong", "", value), node("small", "", note));
    metrics.append(metric);
  }
  card.append(metrics);
  const employees = node("p", "assignment-line",
    business.employees.length
      ? `Assigned: ${business.employees.map((employee) => `${employee.name} · ${titleCase(employee.assignment_role)}`).join(", ")}`
      : "No active employee assignments.");
  card.append(employees);

  const controls = node("div", "business-controls");
  const transitionForm = node("form", "inline-form lifecycle-form");
  const select = node("select");
  select.setAttribute("aria-label", `Move ${business.title} to another lifecycle stage`);
  const placeholder = node("option", "", "Move to lifecycle stage...");
  placeholder.value = "";
  select.append(placeholder);
  for (const target of stageTransitions[business.stage] || []) {
    const option = node("option", "", titleCase(target));
    option.value = target;
    select.append(option);
  }
  const transitionButton = node("button", "button button-dark", "Update stage");
  transitionButton.type = "submit";
  transitionForm.append(select, transitionButton);
  transitionForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!select.value) return;
    try {
      await api(`/api/businesses/${business.id}/transition`, {
        method: "POST",
        body: JSON.stringify({ target: select.value }),
      });
      await loadDashboard();
      showToast(`Business moved to ${titleCase(select.value)}.`);
    } catch (error) {
      showToast(error.message);
    }
  });
  controls.append(transitionForm);

  const metricsForm = node("form", "business-input-form");
  metricsForm.append(node("strong", "", "Record simulated performance"));
  const row = node("div", "metric-inputs");
  const metricFields = [
    ["estimated_revenue", "Est. revenue ($)", "number"],
    ["retention_pct", "Retention %", "number"],
    ["satisfaction_pct", "Satisfaction %", "number"],
    ["growth_pct", "Growth %", "number"],
  ];
  for (const [name, label, type] of metricFields) {
    const input = node("input");
    input.name = name;
    input.type = type;
    input.step = name === "estimated_revenue" ? "0.01" : "0.1";
    input.min = name === "growth_pct" ? "-100" : "0";
    input.placeholder = label;
    input.setAttribute("aria-label", label);
    if (name !== "growth_pct") input.max = "1000000000";
    row.append(input);
  }
  metricsForm.append(row);
  for (const [name, placeholderText] of [
    ["customer_feedback", "Simulated customer feedback summary"],
    ["competitor_analysis", "Competitor observations"],
  ]) {
    const input = node("input");
    input.name = name;
    input.maxLength = 4000;
    input.placeholder = placeholderText;
    metricsForm.append(input);
  }
  const recordMetrics = node("button", "button button-outline", "Save simulated report");
  recordMetrics.type = "submit";
  metricsForm.append(recordMetrics);
  metricsForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = new FormData(metricsForm);
    try {
      await api(`/api/businesses/${business.id}/metrics`, {
        method: "POST",
        body: JSON.stringify({
          estimated_revenue_cents: Math.round(Number(form.get("estimated_revenue") || 0) * 100),
          retention_pct: Number(form.get("retention_pct")),
          satisfaction_pct: Number(form.get("satisfaction_pct")),
          growth_pct: Number(form.get("growth_pct")),
          customer_feedback: form.get("customer_feedback"),
          competitor_analysis: form.get("competitor_analysis"),
        }),
      });
      await loadDashboard();
      showToast("Simulated performance report saved; no revenue was added to the ledger.");
    } catch (error) {
      showToast(error.message);
    }
  });
  controls.append(metricsForm);
  if (["declining", "temporarily_dormant", "archived"].includes(business.stage)) {
    const revivalForm = node("form", "inline-form revival-request-form");
    const market = node("input");
    market.placeholder = "New market information to justify revival";
    market.maxLength = 4000;
    market.required = true;
    const submit = node("button", "button button-outline", "Request revival");
    submit.type = "submit";
    revivalForm.append(market, submit);
    revivalForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      try {
        await api(`/api/businesses/${business.id}/revival`, {
          method: "POST",
          body: JSON.stringify({ new_market_information: market.value }),
        });
        await loadDashboard();
        showToast("Revival mission opened; no spending was authorized.");
      } catch (error) {
        showToast(error.message);
      }
    });
    controls.append(revivalForm);
  }
  card.append(controls);
  return card;
}

function renderRevivalMissions(missions) {
  elements.revivalCount.textContent = `${missions.length} mission${missions.length === 1 ? "" : "s"}`;
  if (!missions.length) {
    elements.revivalList.replaceChildren(node("p", "empty-list", "No businesses currently need revival. Old projects remain saved for future opportunities."));
    return;
  }
  elements.revivalList.replaceChildren(...missions.map((mission) => {
    const item = node("article", "revival-item");
    const header = node("div", "task-top");
    header.append(node("strong", "task-title", mission.business_title), statusChip(mission.phase));
    item.append(header);
    item.append(node("p", "task-desc", `Decline signal: ${mission.decline_reason}`));
    item.append(node("p", "task-desc", `Customer feedback: ${mission.customer_feedback || "Not recorded"} · Sales/retention: ${mission.sales_retention_analysis || "Not analyzed"}`));
    item.append(node("p", "task-desc", `Competitor notes: ${mission.competitor_analysis || "Not recorded"} · New market info: ${mission.new_market_information || "None supplied"}`));
    const next = revivalTransitions[mission.phase] || [];
    if (next.length) {
      const form = node("form", "inline-form");
      const select = node("select");
      select.setAttribute("aria-label", `Advance revival mission for ${mission.business_title}`);
      for (const phase of next) {
        const option = node("option", "", titleCase(phase));
        option.value = phase;
        select.append(option);
      }
      const submit = node("button", "button button-outline", "Advance mission");
      submit.type = "submit";
      form.append(select, submit);
      form.addEventListener("submit", async (event) => {
        event.preventDefault();
        try {
          await api(`/api/revival-missions/${mission.id}/advance`, {
            method: "POST",
            body: JSON.stringify({ phase: select.value }),
          });
          await loadDashboard();
          showToast(select.value === "experiment_recommended"
            ? "Controlled experiment recommendation recorded; it was not launched."
            : "Revival work updated.");
        } catch (error) {
          showToast(error.message);
        }
      });
      item.append(form);
    }
    return item;
  }));
}

function renderFinanceSummary(finance) {
  const cells = [
    ["Actual verified revenue", dollars(finance.actual_revenue_cents), "Owner-reconciled receipts"],
    ["Estimated revenue", dollars(empireData.businesses.reduce((sum, item) => sum + (item.estimated_revenue_cents || 0), 0)), "Simulation only"],
    ["Pending payments", dollars(finance.pending_payments_cents), "Not settled"],
    ["Settled payments", dollars(finance.settled_payments_cents), `${finance.settled_payment_count} verified entries`],
    ["Refunds", dollars(finance.refunds_cents), "Owner-reconciled"],
    ["Processing fees", dollars(finance.processing_fees_cents), "Owner-reconciled"],
    ["Expenses", dollars(finance.expenses_cents), "Not auto-purchased"],
    ["Reinvestment", dollars(finance.reinvestment_cents), "Verified ledger outflows"],
    ["Profit", dollars(finance.profit_cents), "Actual receipts less costs"],
    ["Available funds", dollars(finance.available_business_funds_cents), "Virtual ledger only"],
    ["Withdrawal requests", dollars(finance.withdrawal_requests_cents), "No transfer configured"],
    ["Daily spending limit", dollars(finance.daily_spending_limit_cents), "Default is $0"],
  ];
  elements.financeSummary.replaceChildren(...cells.map(([label, amount, note]) => {
    const cell = node("div", "finance-stat");
    cell.append(node("span", "stat-label", label), node("strong", "", amount), node("small", "", note));
    return cell;
  }));
  $("#spending-limit-input").value = (finance.daily_spending_limit_cents / 100).toFixed(2);
}

function renderLedger(transactions, finance) {
  if (!transactions.length) {
    elements.ledger.replaceChildren(node("p", "empty-list", "No financial transactions recorded. Simulated purchases and estimated sales never enter this ledger."));
    return;
  }
  elements.ledger.replaceChildren(...transactions.map((transaction) => {
    const item = node("article", "ledger-item");
    const summary = node("div", "ledger-summary");
    const details = node("div");
    details.append(
      node("strong", "", `${titleCase(transaction.transaction_type)} · ${transaction.external_reference}`),
      node("small", "", `${transaction.note || "Ledger record"}${transaction.evidence_ref ? ` · Evidence: ${transaction.evidence_ref}` : ""}`),
    );
    summary.append(details, node("span", "ledger-amount", dollars(transaction.amount_cents)));
    item.append(summary);
    item.append(node("span", transaction.is_verified ? "ledger-badge verified" : "ledger-badge pending",
      transaction.is_verified ? "Owner-reconciled · evidence recorded" : "Pending / not counted as actual revenue"));
    if (transaction.transaction_type === "payment_pending") {
      const settled = transactions
        .filter((record) => record.transaction_type === "payment_settled" && record.source_transaction_id === transaction.id)
        .reduce((sum, record) => sum + record.amount_cents, 0);
      const remaining = transaction.amount_cents - settled;
      if (remaining > 0) {
        const form = node("form", "inline-form settle-form");
        const amount = node("input");
        amount.type = "number";
        amount.min = "0.01";
        amount.step = "0.01";
        amount.value = (remaining / 100).toFixed(2);
        amount.setAttribute("aria-label", "Reconciled amount in dollars");
        amount.required = true;
        const evidence = node("input");
        evidence.placeholder = "External evidence reference";
        evidence.maxLength = 300;
        evidence.required = true;
        const submit = node("button", "button button-dark", "Reconcile settlement");
        submit.type = "submit";
        form.append(amount, evidence, submit);
        form.addEventListener("submit", async (event) => {
          event.preventDefault();
          try {
            await api(`/api/finance/pending-payments/${transaction.id}/settle`, {
              method: "POST",
              body: JSON.stringify({ amount_cents: centsFromInput(amount.value), evidence_ref: evidence.value }),
            });
            await loadDashboard();
            showToast("Owner-reconciled receipt recorded; no bank transfer was performed.");
          } catch (error) {
            showToast(error.message);
          }
        });
        item.append(form);
      }
    }
    return item;
  }));
}

function renderReports(reports) {
  if (!reports.length) {
    elements.reports.replaceChildren(node("p", "empty-list", "The persistent Mayor scheduler will create reports when the server starts."));
    return;
  }
  elements.reports.replaceChildren(...reports.map((report) => {
    const item = node("article", "report-item");
    const summary = report.content;
    const declines = summary.declines_detected.length
      ? ` · ${summary.declines_detected.length} decline(s) detected`
      : "";
    item.append(
      node("strong", "", `Portfolio review · ${new Date(report.created_at).toLocaleString()}`),
      node("p", "task-desc", `${summary.business_count} businesses · ${summary.assignments_made} assignments · ${summary.tasks.pending || 0} pending tasks${declines}`),
      node("small", "", `Actual revenue ${dollars(summary.actual_revenue_cents)} · Available ${dollars(summary.available_business_funds_cents)} · CPU ${summary.resources.cpu_percent}% · RAM ${summary.resources.memory_percent_used}%`),
    );
    return item;
  }));
}

async function openBusinessDetail(businessId) {
  try {
    const history = await api(`/api/businesses/${businessId}`);
    const business = history.business;
    elements.businessDialogTitle.textContent = business.title;
    const content = elements.businessDialogContent;
    content.replaceChildren(
      node("p", "detail-kicker", `Current stage: ${titleCase(business.stage)} · ${history.events.length} history events · ${history.tasks.length} tasks`),
      node("p", "profile-stat-row", `Actual settled sales ${dollars(history.financials.actual_revenue_cents)} · Verified profit ${dollars(history.financials.profit_cents)} · Pending receipts ${dollars(history.financials.pending_payments_cents)} · Estimated revenue ${dollars(history.financials.estimated_revenue_cents)} (simulation only)`),
      node("h3", "", "Performance history"),
    );
    if (!history.metrics.length) content.append(node("p", "empty-list", "No simulated performance reports yet."));
    for (const metric of history.metrics) {
      content.append(node("p", "detail-line", `${new Date(metric.created_at).toLocaleString()} · Estimate ${dollars(metric.estimated_revenue_cents)} · Retention ${metric.retention_pct}% · Satisfaction ${metric.satisfaction_pct}% · Growth ${metric.growth_pct}%`));
      if (metric.customer_feedback) content.append(node("p", "task-desc", `Customer feedback: ${metric.customer_feedback}`));
      if (metric.competitor_analysis) content.append(node("p", "task-desc", `Competitor analysis: ${metric.competitor_analysis}`));
    }
    content.append(node("h3", "", "Work products and prototype files"));
    if (!history.artifacts?.length) {
      content.append(node("p", "empty-list", "The team has not produced a saved work product for this business yet."));
    }
    for (const artifact of (history.artifacts || [])) {
      const section = node("section", "artifact-card");
      section.append(
        node("strong", "", `${titleCase(artifact.artifact_type.replaceAll("_", " "))} · ${artifact.title}`),
        node("small", "", new Date(artifact.created_at).toLocaleString()),
      );
      const body = node("pre", "artifact-content", artifact.content);
      section.append(body);
      content.append(section);
    }
    content.append(node("h3", "", "Employee assignment history"));
    for (const assignment of history.assignments) {
      content.append(node("p", "detail-line", `${assignment.name} · ${assignment.role} · ${titleCase(assignment.assignment_role)}${assignment.released_at ? " · completed assignment" : " · current"}`));
    }
    content.append(node("h3", "", "Task history"));
    for (const task of history.tasks) {
      content.append(node("p", "detail-line", `${task.title} · ${titleCase(task.status)}${task.result ? ` · ${task.result}` : ""}`));
    }
    content.append(node("h3", "", "Business lifecycle history"));
    for (const event of history.events) {
      content.append(node("p", "detail-line", `${new Date(event.created_at).toLocaleString()} · ${event.event_type}${event.from_stage ? `: ${titleCase(event.from_stage)} → ${titleCase(event.to_stage)}` : ""} · ${event.details}`));
    }
    content.append(node("h3", "", "Financial ledger history"));
    if (!history.transactions.length) content.append(node("p", "empty-list", "No actual financial transactions recorded for this business."));
    for (const transaction of history.transactions) {
      content.append(node("p", "detail-line", `${new Date(transaction.created_at).toLocaleString()} · ${titleCase(transaction.transaction_type)} · ${dollars(transaction.amount_cents)} · ${transaction.is_verified ? "owner-reconciled" : "pending"}${transaction.evidence_ref ? ` · Evidence: ${transaction.evidence_ref}` : ""}`));
    }
    elements.businessDialog.showModal();
  } catch (error) {
    showToast(error.message);
  }
}

async function openEmployeeProfile(employee) {
  try {
    const profile = await api(`/api/employees/${employee.id}/profile`);
    elements.employeeDialogTitle.textContent = `${profile.employee.name} · ${profile.employee.role}`;
    const content = elements.employeeDialogContent;
    content.replaceChildren(
      node("p", "detail-kicker", profile.morale_notice),
      node("div", "profile-stat-row", `Simulated morale ${profile.profile.morale}/100 · Experience ${profile.profile.experience_points} XP · Career ${titleCase(profile.profile.career_level)} · Reputation ${profile.profile.reputation}/100 · Rating ${profile.profile.performance_rating.toFixed(1)}/5 · Virtual trophies ${profile.profile.virtual_trophies} · Workplace upgrades ${profile.profile.workplace_upgrades}`),
      node("h3", "", "Current project"),
      node("p", "detail-line", profile.current_project
        ? `${profile.current_project.title} · ${titleCase(profile.current_project.status)}${profile.current_project.business_title ? ` · ${profile.current_project.business_title}` : ""}`
        : "No active task."),
      node("h3", "", "Business assignments"),
    );
    if (!profile.assignments.length) content.append(node("p", "empty-list", "No business assignments yet."));
    for (const assignment of profile.assignments) {
      content.append(node("p", "detail-line", `${assignment.business_title} · ${titleCase(assignment.assignment_role)} · ${titleCase(assignment.stage)}`));
    }
    content.append(node("h3", "", "Achievements and recognition"));
    if (!profile.achievements.length) content.append(node("p", "empty-list", "No simulated achievements recorded."));
    for (const reward of profile.achievements) {
      content.append(node("p", "detail-line", `${reward.badge} · ${reward.trophy} · +${reward.experience_points} XP · Evidence: ${reward.evidence_ref}`));
    }
    content.append(node("h3", "", "Previous successful projects"));
    if (!profile.successful_projects.length) content.append(node("p", "empty-list", "No positive verified-profit projects recorded yet."));
    for (const project of profile.successful_projects) {
      content.append(node("p", "detail-line", `${project.title} · Recorded as profitable after ledger verification · Current net ${dollars(project.verified_profit_cents)}`));
    }
    content.append(node("h3", "", "Contributions"));
    for (const task of profile.contributions.slice(0, 10)) {
      content.append(node("p", "detail-line", `${task.title} · ${titleCase(task.status)}${task.result ? ` · ${task.result}` : ""}`));
    }
    content.append(node("h3", "", "Recent employee conversations"));
    for (const message of profile.conversations.slice(-8)) {
      content.append(node("p", "detail-line", `${titleCase(message.role)}: ${message.content}`));
    }
    content.append(node("h3", "", "Department communications"));
    for (const message of profile.team_communications.slice(0, 8)) {
      content.append(node("p", "detail-line", `${message.sender_name} → ${message.recipient_name}: ${message.content}`));
    }
    const rewardForm = node("form", "stack-form share-form");
    rewardForm.append(node("h3", "", "Record evidence-based simulated recognition"));
    const rewardType = node("select");
    rewardType.setAttribute("aria-label", "Recognition category");
    for (const [value, label] of [
      ["product_improvement", "Product improvement"],
      ["customer_satisfaction", "Customer satisfaction"],
      ["good_research", "Good research"],
      ["cost_savings", "Cost savings"],
      ["security_quality", "Security and quality"],
      ["ethical_decision", "Ethical decision"],
    ]) {
      const option = node("option", "", label);
      option.value = value;
      rewardType.append(option);
    }
    const rewardEvidence = node("input");
    rewardEvidence.placeholder = "Owner-verified evidence reference";
    rewardEvidence.required = true;
    rewardEvidence.maxLength = 300;
    const rewardSubmit = node("button", "button button-outline", "Award simulated badge");
    rewardSubmit.type = "submit";
    rewardForm.append(rewardType, rewardEvidence, rewardSubmit);
    rewardForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      rewardSubmit.disabled = true;
      try {
        await api(`/api/employees/${employee.id}/rewards`, {
          method: "POST",
          body: JSON.stringify({ achievement_code: rewardType.value, evidence_ref: rewardEvidence.value }),
        });
        elements.employeeDialog.close();
        await openEmployeeProfile(employee);
        showToast("Simulated recognition and morale update recorded.");
      } catch (error) {
        showToast(error.message);
      } finally {
        rewardSubmit.disabled = false;
      }
    });
    content.append(rewardForm);
    const shareForm = node("form", "stack-form share-form");
    shareForm.append(node("h3", "", "Share an AI-generated finding with a colleague"));
    const recipient = node("select");
    recipient.setAttribute("aria-label", "Recipient department");
    for (const member of dashboardData.employees.filter((item) => item.id !== employee.id)) {
      const option = node("option", "", `${member.name} · ${member.role}`);
      option.value = member.id;
      recipient.append(option);
    }
    const request = node("textarea");
    request.rows = 2;
    request.maxLength = 2000;
    request.placeholder = "What should this employee investigate and share?";
    request.required = true;
    const send = node("button", "button button-dark", "Generate and send locally");
    send.type = "submit";
    shareForm.append(recipient, request, send);
    shareForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      send.disabled = true;
      try {
        await api(`/api/employees/${employee.id}/share`, {
          method: "POST",
          body: JSON.stringify({ recipient_employee_id: recipient.value, request: request.value }),
        });
        elements.employeeDialog.close();
        await openEmployeeProfile(employee);
        showToast("AI-generated department finding saved.");
      } catch (error) {
        showToast(error.message);
      } finally {
        send.disabled = false;
      }
    });
    content.append(shareForm);
    elements.employeeDialog.showModal();
  } catch (error) {
    showToast(error.message);
  }
}

async function loadDashboard() {
  try {
    const data = await api("/api/dashboard");
    dashboardData = data;
    renderStats(data.town);
    renderEmployees(data.employees);
    renderTasks(data.tasks);
    renderIdeas(data.ideas);
    renderActivity(data.activity);
    renderOllama(data.ollama);
    const [portfolio, transactions, reports] = await Promise.all([
      api("/api/empire"),
      api("/api/finance/transactions"),
      api("/api/management/reports"),
    ]);
    financialTransactions = transactions;
    managementReports = reports;
    renderEmpire(portfolio);
  } catch (error) {
    showToast(`Could not load town data: ${error.message}`);
  }
}

async function selectEmployee(employee) {
  selectedEmployee = employee.id;
  elements.chatTitle.textContent = `${employee.name} · ${employee.role}`;
  elements.chatInput.disabled = false;
  elements.chatForm.querySelector("button").disabled = false;
  renderEmployees(await api("/api/employees"));
  try {
    renderConversation(await api(`/api/employees/${employee.id}/messages`));
  } catch (error) {
    showToast(error.message);
  }
}

function renderConversation(messages) {
  if (!messages.length) {
    elements.chatMessages.replaceChildren(node("p", "empty-state", "No messages yet. Say hello to start."));
    return;
  }
  elements.chatMessages.replaceChildren(...messages.map((message) => {
    const line = node("p", `chat-message ${message.role}`);
    line.append(node("strong", "", message.role === "user" ? "You:" : "Employee:"), document.createTextNode(message.content));
    return line;
  }));
  elements.chatMessages.scrollTop = elements.chatMessages.scrollHeight;
}

$("#task-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const formElement = event.currentTarget;
  const form = new FormData(formElement);
  try {
    await api("/api/tasks", {
      method: "POST",
      body: JSON.stringify({
        title: form.get("title"),
        description: form.get("description"),
        employee_id: form.get("employee_id"),
      }),
    });
    formElement.reset();
    await loadDashboard();
    showToast("Task assigned and saved.");
  } catch (error) {
    showToast(error.message);
  }
});

$("#idea-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const formElement = event.currentTarget;
  const form = new FormData(formElement);
  try {
    await api("/api/ideas", {
      method: "POST",
      body: JSON.stringify({ title: form.get("title"), description: form.get("description") }),
    });
    formElement.reset();
    await loadDashboard();
    showToast("Business idea saved.");
  } catch (error) {
    showToast(error.message);
  }
});

elements.chatForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const content = elements.chatInput.value.trim();
  if (!content || !selectedEmployee) return;
  const button = elements.chatForm.querySelector("button");
  button.disabled = true;
  try {
    const response = await api(`/api/employees/${selectedEmployee}/messages`, {
      method: "POST",
      body: JSON.stringify({ content }),
    });
    elements.chatInput.value = "";
    renderConversation(await api(`/api/employees/${selectedEmployee}/messages`));
    showToast(`Reply from ${response.model}.`);
    await loadDashboard();
  } catch (error) {
    showToast(error.message);
  } finally {
    button.disabled = false;
  }
});

$("#owner-token-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const token = $("#owner-token").value.trim();
  if (!token) {
    showToast("Enter the owner token configured on the server.");
    return;
  }
  sessionStorage.setItem("ai-money-town-owner-token", token);
  try {
    await api("/api/owner/status");
    $("#owner-token-status").textContent = "Owner actions authorized for this tab.";
    $("#owner-token-status").classList.add("authorized");
    showToast("Owner actions unlocked for this browser tab.");
  } catch (error) {
    sessionStorage.removeItem("ai-money-town-owner-token");
    $("#owner-token-status").textContent = error.message;
    $("#owner-token-status").classList.remove("authorized");
  }
});

$("#spending-limit-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const amount = Number($("#spending-limit-input").value);
    if (!Number.isFinite(amount) || amount < 0) throw new Error("Enter a non-negative spending limit.");
    await api("/api/finance/spending-limit", {
      method: "PUT",
      body: JSON.stringify({ amount_cents: Math.round(amount * 100) }),
    });
    await loadDashboard();
    showToast("Daily spending limit saved. It does not authorize a purchase by itself.");
  } catch (error) {
    showToast(error.message);
  }
});

$("#pending-payment-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const formElement = event.currentTarget;
  const form = new FormData(formElement);
  try {
    await api("/api/finance/pending-payments", {
      method: "POST",
      body: JSON.stringify({
        business_id: Number(form.get("business_id")),
        amount_cents: centsFromInput(form.get("amount")),
        external_reference: form.get("external_reference"),
      }),
    });
    formElement.reset();
    await loadDashboard();
    showToast("Receipt recorded as pending—not counted as revenue.");
  } catch (error) {
    showToast(error.message);
  }
});

$("#adjustment-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const formElement = event.currentTarget;
  const form = new FormData(formElement);
  try {
    await api("/api/finance/adjustments", {
      method: "POST",
      body: JSON.stringify({
        business_id: form.get("business_id") ? Number(form.get("business_id")) : null,
        transaction_type: form.get("transaction_type"),
        amount_cents: centsFromInput(form.get("amount")),
        external_reference: form.get("external_reference"),
        evidence_ref: form.get("evidence_ref"),
      }),
    });
    formElement.reset();
    await loadDashboard();
    showToast("Owner-reconciled ledger adjustment recorded.");
  } catch (error) {
    showToast(error.message);
  }
});

$("#run-review-button").addEventListener("click", async () => {
  try {
    await api("/api/management/run", { method: "POST" });
    await loadDashboard();
    showToast("Mayor portfolio review completed; only no-cost internal work was queued.");
  } catch (error) {
    showToast(error.message);
  }
});

for (const dialog of [elements.employeeDialog, elements.businessDialog]) {
  dialog.querySelector(".dialog-close").addEventListener("click", () => dialog.close());
  dialog.addEventListener("click", (event) => {
    if (event.target === dialog) dialog.close();
  });
}

$("#refresh-button").addEventListener("click", loadDashboard);
$("#today-label").textContent = new Date().toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });

function navigateToView(view, anchor) {
  const isCity = view === "city";
  cityScreen.hidden = !isCity;
  dashboardScreen.hidden = isCity;
  for (const link of document.querySelectorAll(".nav-link")) {
    link.classList.toggle("active", isCity
      ? link.dataset.screen === "city"
      : link.dataset.screen === "dashboard" || (!link.dataset.screen && link.getAttribute("href") === anchor));
  }
  if (!isCity && anchor) document.querySelector(anchor)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

for (const link of document.querySelectorAll(".nav-link")) {
  link.addEventListener("click", (event) => {
    event.preventDefault();
    if (link.dataset.screen === "city") navigateToView("city");
    else navigateToView("dashboard", link.dataset.screen === "dashboard" ? "#overview" : link.hash);
  });
}

loadDashboard();
