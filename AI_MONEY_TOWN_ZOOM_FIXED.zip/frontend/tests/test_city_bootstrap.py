from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_index_loads_city_bootstrap_instead_of_unchecked_module():
    html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
    assert '/static/city-bootstrap.js' in html
    assert '<script type="module" src="/static/city.bundle.js"></script>' not in html


def test_city_bootstrap_loads_bundle_and_has_visible_runtime_fallbacks():
    bootstrap = (ROOT / "frontend" / "city-bootstrap.js").read_text(encoding="utf-8")
    assert "Do not probe with a throwaway WebGL canvas" in bootstrap
    assert "city.bundle.js" in bootstrap
    assert "Open dashboard" in bootstrap
    assert "unhandledrejection" in bootstrap
    assert "15000" in bootstrap


def test_local_threejs_bundle_is_present():
    bundle = ROOT / "frontend" / "city.bundle.js"
    assert bundle.is_file()
    assert bundle.stat().st_size > 100_000


def test_city_has_game_controls_collision_steps_and_minimap():
    source = (ROOT / "frontend" / "src" / "city.js").read_text(encoding="utf-8")
    bundle = (ROOT / "frontend" / "city.bundle.js").read_text(encoding="utf-8")
    assert 'setPointerCapture(event.pointerId)' in source
    assert 'isTextEntry(document.activeElement)' in source
    assert 'Math.ceil(distance / 0.18)' in source
    assert 'movementForward.set(-Math.sin(yaw), 0, -Math.cos(yaw))' in source
    assert 'movementRight.set(Math.cos(yaw), 0, -Math.sin(yaw))' in source
    assert 'player.position.set(0, 0, 32)' in source
    assert 'const lookAhead = inside ? 2.2 : 24' in source
    assert 'player.position.set(0, 0, 1.6)' in source
    assert 'city-return-town' in source and 'city-dialog-return-town' in source
    assert 'insideBuilding' in bundle and 'interiorObjects' in bundle
    assert 'cityGroup.visible = true' in source
    assert 'ot.position.set(0,0,32)' in bundle
    assert 'World visible' in bundle
    assert 'city-recenter' in bundle
    assert 'city-minimap-panel' in source and 'city-minimap-panel' in bundle
    assert 'ResizeObserver' in bundle
    assert 'function ro(i){su(i.id)}' in bundle
    assert 'The 3D renderer stopped:' in bundle


def test_employee_chat_uses_selected_local_model_and_friendlier_composer():
    source = (ROOT / "frontend" / "src" / "city.js").read_text(encoding="utf-8")
    backend = (ROOT / "backend" / "app" / "main.py").read_text(encoding="utf-8")
    assert 'Talk naturally' in source
    assert 'qwen3.5:0.8b' in (ROOT / 'backend' / 'app' / 'ollama.py').read_text(encoding='utf-8')
    assert 'Thinking…' in source
    assert 'Shift + Enter for a new line' in source
    assert 'sent.model' not in source
    assert 'Finishing the reply through the standard local chat endpoint' in (ROOT / 'backend' / 'app' / 'main.py').read_text(encoding='utf-8')
    assert '/messages/stream' in source
    assert 'text/event-stream' in source


def test_playable_isometric_fallback_uses_click_to_enter_and_real_employee_chat():
    html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
    fallback = (ROOT / "frontend" / "city-visual-fallback.js").read_text(encoding="utf-8")
    assert '/static/city-visual-fallback.js' in html
    for feature in (
        "drawBuilding", "drawTree", "drawEmployee", "pointermove",
        "hitDistrict", "animateCameraTo", "transitionCurtain",
        "amt-department-transition", "/api/city/state", "/messages/stream",
        "requestAnimationFrame(frame)", "CLICK TO ENTER",
    ):
        assert feature in fallback
    assert "window.__AMT_PLAYABLE_TOWN" in fallback
    assert "state.keys.add" not in fallback
    assert "targetX=moving" not in fallback
    assert "W A S D" not in html and "Sprint" not in html


def test_playable_town_has_department_interiors_and_inside_employee_workstations():
    fallback = (ROOT / "frontend" / "city-visual-fallback.js").read_text(encoding="utf-8")
    assert "function drawInterior(d)" in fallback
    assert "function enterBuilding(d)" in fallback
    assert "function exitBuilding()" in fallback
    assert "insideBuilding" in fallback
    assert "drawInteriorDesk" in fallback
    assert "drawInteriorAvatar" in fallback
    assert 'id:"central-bank", title:"Central Bank"' in fallback
    assert "Virtual ledger only" in fallback
    assert "camera-relative" not in fallback  # implemented mathematically, not advertised by a stale comment
    assert "click" in fallback.lower()


def test_department_navigation_uses_camera_glide_then_fade_and_restores_map():
    fallback = (ROOT / "frontend" / "city-visual-fallback.js").read_text(encoding="utf-8")
    assert "duration=880" in fallback
    assert "state.viewCenter={x:mix(origin.x,target.x,e),z:mix(origin.z,target.z,e)}" in fallback
    assert "state.insideBuilding=d.id" in fallback
    assert 'overlay.style.opacity="1"' in fallback
    assert 'viewport.classList.add("department-mode")' in fallback
    assert 'viewport.classList.remove("department-mode")' in fallback
