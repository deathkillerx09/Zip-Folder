from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[2]


def _districts():
    source = (ROOT / "frontend" / "city-visual-fallback.js").read_text(encoding="utf-8")
    matches = re.findall(r'id:"([^"]+)", title:"([^"]+)", x:(-?\d+), z:(-?\d+)', source)
    return [(name, title, int(x), int(z)) for name, title, x, z in matches[:10]]


def _plaque_rectangles(width, height, zoom=6.4):
    districts = _districts()
    candidates = [
        (0, 0), (0, -40), (0, 40), (-52, 0), (52, 0),
        (0, -78), (0, 78), (-52, -40), (52, -40), (-52, 40), (52, 40),
    ]
    occupied = []
    for _name, _title, x, z in districts:
        # Mirrors the isometric projection and screen-space non-overlap placement.
        anchor_x = width * .5 + (x - z) * .707106 * zoom
        anchor_y = height * .51 + (x + z) * .355 * zoom - 12.75 * zoom * .88
        card_w, card_h = 130, 34
        chosen = None
        for ox, oy in candidates:
            left = max(8, min(width - card_w - 8, anchor_x - card_w / 2 + ox))
            top = max(184, min(height - card_h - 56, anchor_y + 18 - card_h / 2 + oy))
            rect = (left, top, card_w, card_h)
            overlaps = any(
                not (
                    rect[0] + rect[2] + 8 < other[0]
                    or other[0] + other[2] + 8 < rect[0]
                    or rect[1] + rect[3] + 7 < other[1]
                    or other[1] + other[3] + 7 < rect[1]
                )
                for other in occupied
            )
            if not overlaps:
                chosen = rect
                break
        assert chosen is not None, f"No non-overlapping plaque slot at {width}x{height}"
        occupied.append(chosen)
    return occupied


def test_department_names_and_enter_actions_share_one_non_overlapping_plaque():
    source = (ROOT / "frontend" / "city-visual-fallback.js").read_text(encoding="utf-8")
    assert "function drawDepartmentPlaques()" in source
    assert "CLICK TO ENTER" in source
    assert "state.districtPlaques.push" in source
    assert 'fillText("OPEN  ↗"' not in source
    assert len(_districts()) == 10


def test_department_plaque_layout_does_not_overlap_on_common_screens():
    for width, height in [(1564, 855), (1280, 700), (1024, 650), (800, 600)]:
        rects = _plaque_rectangles(width, height)
        for index, current in enumerate(rects):
            for other in rects[index + 1:]:
                assert (
                    current[0] + current[2] + 8 < other[0]
                    or other[0] + other[2] + 8 < current[0]
                    or current[1] + current[3] + 7 < other[1]
                    or other[1] + other[3] + 7 < current[1]
                ), f"Department labels overlap at {width}x{height}"


def test_map_hud_has_responsive_grid_and_short_status():
    css = (ROOT / "frontend" / "styles.css").read_text(encoding="utf-8")
    source = (ROOT / "frontend" / "city-visual-fallback.js").read_text(encoding="utf-8")
    assert "grid-template-columns: minmax(220px, 1fr)" in css
    assert "@media (max-width: 760px)" in css
    assert "staff · select a department" in source
