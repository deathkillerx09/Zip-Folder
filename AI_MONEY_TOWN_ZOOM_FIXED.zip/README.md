# AI Money Town — Local-First Business Simulation

A local-first business simulation with a FastAPI API, persistent SQLite storage, eight named AI employees, a clickable department town, custom department workplaces, a business portfolio and revival system, a virtual accounting ledger, and local Ollama conversations.

## Explore the town

The current visible town is an **isometric 2.5D Canvas world**, not yet a full Genshin-style 3D game. WASD movement has been removed. Instead:

1. Click any department building on the town map.
2. The camera smoothly glides and zooms toward the selected building.
3. The screen fades to a cinematic dark transition.
4. The department interior appears and fades back into view.
5. Click an employee at their workstation to open their conversation.
6. Use the **Return to town** button or press **Esc** to leave the department.

The town contains ten themed locations, including the Mayor's Hall, Ideas Workshop, Research Library, Maker Workshop, Creative Studio, Customer Lounge, Sales Arcade, Quality Workshop, Rest Garden, and the Central Bank. Employees are shown at the workstation assigned to their role. The Central Bank is an accounting ledger only; it does not hold or transfer real money.

The original Three.js source and bundle are retained for a later full-3D graphics milestone. The isometric renderer is currently used because the Three.js output was presenting only the clear-colour background on the owner's machine.

## Quick start (Windows 11)

1. Extract the project folder.
2. Double-click **`Start AI Money Town.bat`**.
3. Keep the terminal window open while using the town.
4. Open `http://127.0.0.1:8000` if the browser does not open automatically.

The launcher creates a Python virtual environment if needed, installs the declared Python dependencies, creates a one-time database backup before launch, creates a private local owner token if one does not exist, and starts the server on `127.0.0.1:8000`. Press `Ctrl+C` in the terminal to stop the server.

Employee conversations and autonomous local-model tasks require Ollama to be running on this computer. The app does not use paid AI APIs. The launcher's default lightweight chat model is `qwen3.5:0.8b`; a stronger locally installed model can be selected using `OLLAMA_CHAT_MODEL`. Replies may be slower depending on the model and laptop resources.

## Data and financial boundaries

`data\town.db` stores the town's local records. Keep a backup before replacing or moving project folders. The `.owner-token` file is a local secret and must not be shared.

The Central Bank is a **virtual accounting ledger, not a real bank account**. Pending receipts are not counted as settled revenue; settlements require owner reconciliation and evidence references. There is no payment processor, bank-card connection, deposit or real withdrawal integration. No purchases or transfers are made by the application. The spending limit starts at $0.

All customer simulations, forecasts, morale, XP, and achievements are simulated. Simulated purchases are never real revenue.

## Windows 11 setup

1. Install Python 3.11 or newer from [python.org](https://www.python.org/downloads/windows/) and enable **Add Python to PATH**.
2. Install [Ollama for Windows](https://ollama.com/download) for employee chat and autonomous internal task work. In PowerShell, download a local model once, for example:

   ```powershell
   ollama pull llama3.2
   ```

3. Open PowerShell in this project folder and create the environment:

   ```powershell
   cd C:\Users\Main\Desktop\AI-MONEY-TOWN
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install -r backend\requirements.txt
   ```

4. Configure owner authorization before using approval, financial reconciliation, spending-limit, lifecycle, recognition, or manual Mayor controls. Set a strong private token in the PowerShell window that will run the server:

   ```powershell
   $env:AI_MONEY_TOWN_OWNER_TOKEN = "replace-with-a-long-random-secret"
   ```

   Owner actions are disabled if this value is not configured. The dashboard keeps the token only in the current browser tab. Do not share it. The daily spending limit starts at **$0** and must be explicitly changed by the owner; expenses and reinvestments also require settled business funds and evidence references.

5. Start the server bound to this computer:

   ```powershell
   uvicorn app.main:app --app-dir backend --reload --host 127.0.0.1
   ```

6. Open [http://127.0.0.1:8000](http://127.0.0.1:8000). API documentation is at [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs).

The SQLite database is created at `data\town.db` and persists across restarts. Phase 2 uses additive SQLite migrations; existing Phase 1 task and idea records are retained, and already-approved ideas are brought into the research lifecycle. Set `AI_MONEY_TOWN_DB` to change the database path.

The default Ollama address is `http://127.0.0.1:11434`; `OLLAMA_BASE_URL` may point to another loopback address but never to a remote host. Set `OLLAMA_MODEL` to choose an installed model by its exact Ollama name. If Ollama is unavailable, autonomous tasks stay queued for retry and employee chat reports a service error rather than falling back to a cloud API.

On startup, the Mayor scheduler seeds one first-shift internal task for each of the eight employees (once per database) and recovers interrupted work. The Windows launcher starts the first worker after a short delay and then processes at most one autonomous local-model task per scheduler cycle (default 40 seconds, configurable with `AI_MONEY_TOWN_SCHEDULER_SECONDS`). The scheduler and employee chat share a model lock, with short background model timeouts so an interactive conversation can take priority. Idea generation attempts a batch of up to ten candidates after the initial delay (default 90 seconds) and then hourly while Ollama and local resources are available; this is a target, not a guaranteed output quota. The internal pipeline automatically advances reviewed ideas into research, MVP blueprint preparation, synthetic customer simulation, and an owner launch-readiness checklist. It saves these deliverables as business artifacts, and keeps businesses at `ready_for_approval` until the owner approves any real-world launch. It records CPU/RAM and portfolio reports, detects deteriorating/unprofitable businesses, and assigns a bounded queue of internal tasks. It never publishes marketing, performs purchases, contacts customers, or launches recommended experiments.

The synthetic customer simulator can process up to 1,000,000 generated profiles (default 10,000, configurable with `AI_MONEY_TOWN_SIMULATED_CUSTOMERS`). These are heuristic fictional profiles, not people, research, confirmed demand, or sales. Its $5 / 1,000-visit revenue scenario is stored only as an estimate and is excluded from the actual ledger. The starter Windows launcher keeps quick employee chat and short idea batches on `qwen3.5:0.8b` and prefers the already-installed `qwen3:4b` model for worker research and product planning; if that model is missing, Ollama model selection falls back to an available conversational model.

## Money and approval boundaries

- The virtual ledger is accounting software, **not a bank account**. There is no withdrawal or payment-provider integration.
- Pending receipts are excluded from actual revenue until an owner explicitly reconciles them against an external evidence reference. This is a manual owner assertion, not independent bank verification.
- Reconciliation events are append-only and cannot be edited or deleted. Refunds, fees, expenses, reinvestment, and withdrawal requests are separate ledger records.
- Expenses/reinvestment require both available verified business earnings and a non-zero owner-set daily spending limit. The limit alone does not authorize or perform a purchase.
- Withdrawal requests are recorded as requests only; the disabled integration never reports a transfer as successful.
- No personal investment, loans, subscriptions, paid APIs, or paid model credits are supported.
- Employee morale, XP, reputation, trophies, career levels, and workplace upgrades are virtual motivation statistics; they do not imply sentience or actual emotions.

## Phase 2 areas

- `backend\app\empire.py` — allowed lifecycle transitions, portfolio history, revival pipeline, assignments, and recognition calculations
- `backend\app\finance.py` — evidence-referenced virtual ledger and spending safeguards
- `backend\app\people.py` — employee profiles, contributions, achievements, and communication history
- `backend\app\scheduler.py` — task recovery, CPU/RAM monitoring, hourly idea generation, staged autonomous business incubator, Mayor reports, bounded local Ollama worker
- `backend\app\market_simulation.py` — deterministic synthetic customer-interest and pricing scenario (simulation only)
- `backend\app\resources.py` — local machine resource snapshot
- `frontend\` — overview, Business Empire, revival, treasury, reports, and employee profile UI

## Tests

Frontend bootstrap and gameplay-bundle checks are included with the Python test suite. They verify that the city bundle is loaded with visible error fallbacks, expected control logic is present, and the browser-served bundle contains the gameplay fixes. These checks do not replace a real browser/WebGL visual test.


From the project root, after installing dependencies:

```powershell
python -m pytest backend\tests -q
```

The tests use temporary SQLite databases and a fake local model client; they do not require Ollama or use a network service.

## Current visual and AI limitations

The current Three.js city is a procedural fantasy-town prototype, not a finished Genshin Impact-scale environment. It uses generated geometry and materials; proper high-quality art requires importing authored, textured glTF/GLB assets. See `frontend/assets/3d/README.md` for two optional free CC0 Quaternius packs. They are not bundled into this project and the app does not fetch them at runtime.

The city defaults to Low graphics for Intel Iris Xe/integrated GPUs. WASD and arrow-key movement are relative to the current camera orbit; the player spawns in an open lane rather than against the Central Bank collision box. The browser-served `frontend/city.bundle.js` is kept in sync with these gameplay fixes. Actual WebGL rendering must still be checked in Chrome on the target laptop.

AI employees receive persistent starter tasks when the local scheduler starts. They only complete tasks when Ollama is reachable and a compatible chat model is installed. This app does not run AI while the computer is shut down and does not create a remote cloud AI service.


## Employee names and department interiors

The eight seeded teammates have custom names and plain-language roles: Mayor Wafflebeard (Mayor), Sherlock Beans (Trend Detective), Captain Spreadsheet (Idea Strategist), Gizmo McNoodle (Product Maker), Sir Hype-a-Lot (Marketing Wizard), Cash Moneybags (Banker & Treasurer), Inspector Baguette (Quality Inspector), and Bubbles McChat (Customer Helper). Existing default seed names are upgraded safely; custom names not matching the prior defaults are preserved.

Each employee is placed in a themed interior: Mayor's Hall, Research Library, Ideas Workshop, Maker Workshop, Creative Studio, Central Bank, Quality Workshop, or Customer Lounge. The Sales Arcade and Rest Garden are extra town spaces. The bank room displays the virtual ledger balance, but it does not hold or transfer real money. No card details should be entered into employee chat. A future payout requires an eligible destination account and a properly configured payment provider.

**Visual honesty:** this visible renderer is an isometric 2.5D game view, not full 3D and not Genshin Impact. It now includes custom fantasy-styled department rooms and workstations. Full 3D terrain/GLB character and building assets remain a separate future milestone.

## Custom employee names, rooms, and workstations

The eight town employees use memorable display names and simple roles:

- **Mayor Wafflebeard** — Mayor, stationed at the map-and-planning table in Mayor's Hall.
- **Sherlock Beans** — Trend Detective, stationed at the clue archive in Research Library.
- **Captain Spreadsheet** — Idea Strategist, stationed at the idea board in Ideas Workshop.
- **Gizmo McNoodle** — Product Maker, stationed at the prototype bench in Maker Workshop.
- **Sir Hype-a-Lot** — Marketing Wizard, stationed at the campaign design desk in Creative Studio.
- **Cash Moneybags** — Banker & Treasurer, stationed at the vault-side ledger desk in Central Bank.
- **Inspector Baguette** — Quality Inspector, stationed at the testing bench in Quality Workshop.
- **Bubbles McChat** — Customer Helper, stationed at the support counter in Customer Lounge.

Employees are not drawn standing outside their buildings. Open a department to see its teammate at their individual workstation. Each room has its own visual theme and props: planning map, research shelves, idea wall, maker tools, campaign wall, bank vault and ledger, quality test board, or customer lounge counter. Task labels distinguish **WORKING**, **TASK QUEUED**, and **ON STANDBY** rather than calling every pending task active work.

## Banker and future payouts

Cash Moneybags manages the town's **virtual accounting ledger**: recorded receipts, verified/settled amounts, fees, expenses, and authorised reinvestment. The application does not physically hold funds, connect to a bank, or deposit money to a card. When the owner has an eligible payout account and a supported payment provider is properly configured, a future version can let the owner request a payout with appropriate confirmation and provider verification. Do not enter card numbers, passwords, or banking credentials into employee chat. Until then, balances displayed in the Central Bank are accounting records only, not withdrawable cash.

## Current visual scope

The visible playable view in this build is an **isometric 2.5D Canvas game**, with camera-relative keyboard movement and separate department interiors. It is not yet a full Genshin Impact-style 3D open world. The prior Three.js code remains in the project, but it was not reliably visible on the target integrated-graphics setup; this build uses the isometric view as the reliable playable version. A true 3D upgrade still needs authored, textured GLB/GLTF assets, character animations, terrain, and a verified WebGL rendering pipeline.


## Idea generation target

The local scheduler is configured to aim for **50 distinct idea candidates per hour**, using batches of 10 every 12 minutes. This is a throughput target, not a guarantee: generation pauses when Ollama is unavailable, the model is busy, or the laptop lacks capacity. The app records actual generated candidates only; it never invents activity to fill the target.

Department workspaces show a live side board with current employee assignments and department-specific data. The Central Bank panel shows virtual-ledger figures only; no real bank or card connection is configured.


## Final town-map polish

The department map now uses a spacious two-row town layout and one combined department plaque per building. Each plaque contains the department name and the entry action together, with screen-space collision placement so adjacent labels do not overlap. The top HUD reflows at smaller widths. The live department board remains separate from employee chat.

The idea factory default target is 50 idea candidates per hour (10 per batch, every 12 minutes). This is a target, not a guaranteed rate; local model speed, RAM, queue pressure, valid JSON output and duplicate filtering affect actual throughput.

## Preparing for cloud hosting

A Dockerfile, Docker Compose stack, Caddy HTTPS reverse proxy, persistent data/model volumes, and optional site-wide Basic Auth gate are included. See `CLOUD-DEPLOYMENT-READINESS.md` before deploying.

No cloud server has been provisioned. Do not expose the app publicly until you set the site access credentials and owner token, configure HTTPS/domain, back up the database, and review API access controls. The virtual Central Bank remains an accounting ledger; it cannot hold or transfer real money.


## First startup and what the numbers mean

The included database starts with eight queued onboarding assignments, no business ideas, no businesses, and a $0 virtual balance. On launch, the scheduler starts processing employee assignments with the configured Ollama worker model; the map HUD reports running and queued tasks separately. The idea generator makes its first attempt shortly after startup. If the Ollama model is missing, unreachable, or too slow, work remains queued and the terminal logs explain why. Do not treat queued tasks as completed work.

A zero treasury balance is intentional, not seeded income. Internal research, prototypes, and simulated customer analysis do not create real revenue. The town cannot spend or reinvest until real receipts have been reconciled into the ledger. Public launches, external messages, purchases, and payments remain owner-controlled.
