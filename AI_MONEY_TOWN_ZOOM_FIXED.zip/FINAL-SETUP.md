# AI Money Town — final local setup

## Start the Windows app

1. Extract this ZIP into a new folder.
2. Double-click `Start AI Money Town.bat`.
3. Leave the black terminal window open.
4. Open `http://127.0.0.1:8000` in Chrome.
5. Wait for the scheduler to start the first shift (normally within a few seconds). The city HUD now separates **working** tasks from **queued** tasks; queued tasks are not falsely shown as already running.
6. Click a combined department plaque to enter that workplace. Use **Return to Town** or Escape to leave.

To stop the town, press `Ctrl+C` in the black terminal window.

## What the town does

- Eight named employee profiles and their departments are stored in SQLite. Eight starter assignments are preloaded; the scheduler executes them one at a time using the configured Ollama worker model.
- The department map uses one combined title/entry plaque per building; labels are screen-space placed to avoid overlap.
- Each department has a live information board separate from employee chat.
- The idea generator begins its first attempt shortly after startup and is configured for a target of 50 idea candidates per hour (10 every 12 minutes). Actual results depend on local Ollama speed, RAM, output validity, duplicates and scheduler workload. The target is not a guarantee.
- The workers create research, plans, prototypes/blueprints and simulations. Simulated customers and simulated sales are not real customers or revenue.
- The Banker manages a virtual ledger only. There is no connected bank or card payout integration. A starting balance of $0 is intentional: simulated demand and generated ideas do not create cash. Only owner-reconciled, evidence-backed settled receipts can fund reinvestment.

## Important database note

`data/town.db` is the town's save file. Keep a backup before replacing a project folder. If you have newer records in an older working folder, copy that folder's `data/town.db` into the new project's `data` folder after backing it up.

## Cloud preparation

The included `Dockerfile`, `docker-compose.yml`, `Caddyfile`, and `.env.cloud.example` prepare the app for a private HTTPS cloud deployment. Read `CLOUD-DEPLOYMENT-READINESS.md` before using them.

The cloud setup requires a domain, private access username/password, a separate owner token and a persistent volume. Do not put secrets in chat or source control. Do not select paid plans or enable billing upgrades. The cloud files are prepared but the server is not provisioned yet.
